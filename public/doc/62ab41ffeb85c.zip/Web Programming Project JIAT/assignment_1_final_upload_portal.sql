-- MySQL dump 10.13  Distrib 8.0.27, for macos11 (x86_64)
--
-- Host: localhost    Database: assignment1
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `academic_officer`
--

DROP TABLE IF EXISTS `academic_officer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_officer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(300) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `status_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_academic_officer_status1_idx` (`status_id`),
  CONSTRAINT `fk_academic_officer_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_officer`
--

LOCK TABLES `academic_officer` WRITE;
/*!40000 ALTER TABLE `academic_officer` DISABLE KEYS */;
INSERT INTO `academic_officer` VALUES (1,'Thisitha','Atapattu','tHISITHA123','thisitha2008@gmail.com','Thisithaa',2),(2,'Future','Harp','Future123','futureharp12619@gmail.com','FutureH',1),(9,'Es','This','e123','emailthisitha@gmail.com','ET',1),(10,'Thisitha','Atapattu','qqq','2222@gmail.com','Test123',1);
/*!40000 ALTER TABLE `academic_officer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `academic_officer_account_access_code`
--

DROP TABLE IF EXISTS `academic_officer_account_access_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_officer_account_access_code` (
  `academic_officer_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`academic_officer_id`),
  CONSTRAINT `fk_academic_officer_account_access_code_academic_officer1` FOREIGN KEY (`academic_officer_id`) REFERENCES `academic_officer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_officer_account_access_code`
--

LOCK TABLES `academic_officer_account_access_code` WRITE;
/*!40000 ALTER TABLE `academic_officer_account_access_code` DISABLE KEYS */;
INSERT INTO `academic_officer_account_access_code` VALUES (10,'62aa08dfe861a');
/*!40000 ALTER TABLE `academic_officer_account_access_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `academic_officer_code`
--

DROP TABLE IF EXISTS `academic_officer_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_officer_code` (
  `academic_officer_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`academic_officer_id`),
  CONSTRAINT `fk_academic_officer_code_academic_officer1` FOREIGN KEY (`academic_officer_id`) REFERENCES `academic_officer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_officer_code`
--

LOCK TABLES `academic_officer_code` WRITE;
/*!40000 ALTER TABLE `academic_officer_code` DISABLE KEYS */;
INSERT INTO `academic_officer_code` VALUES (9,'62a58ab66148b');
/*!40000 ALTER TABLE `academic_officer_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `academic_officer_profile_pic`
--

DROP TABLE IF EXISTS `academic_officer_profile_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_officer_profile_pic` (
  `academic_officer_id` int NOT NULL,
  `image_id` int NOT NULL,
  PRIMARY KEY (`academic_officer_id`),
  KEY `fk_academic_officer_profile_pic_image1_idx` (`image_id`),
  CONSTRAINT `fk_academic_officer_profile_pic_academic_officer1` FOREIGN KEY (`academic_officer_id`) REFERENCES `academic_officer` (`id`),
  CONSTRAINT `fk_academic_officer_profile_pic_image1` FOREIGN KEY (`image_id`) REFERENCES `image` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_officer_profile_pic`
--

LOCK TABLES `academic_officer_profile_pic` WRITE;
/*!40000 ALTER TABLE `academic_officer_profile_pic` DISABLE KEYS */;
INSERT INTO `academic_officer_profile_pic` VALUES (9,8);
/*!40000 ALTER TABLE `academic_officer_profile_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(400) COLLATE utf8mb4_bin NOT NULL,
  `status_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_admin_status1_idx` (`status_id`),
  CONSTRAINT `fk_admin_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (2,'Test','Name','Test N','Thisitha123','test@gmail.com',1),(3,'Thisitha','Atapattu','ThisithaA','Thisitha123','test1@gmail.com',1),(8,'Test','Person','TestP','test123','testp@gmail.com',1),(9,'Test','Admin','TestAd','TestAD123','testad@gmail.com',1),(10,'New','Admin','newAdmin','newAd123','newadmin@gmail.com',2),(11,'admin','User','adminUser','Adminthisitha','adminuser@gmail.com',1),(12,'Test','Me','Test','TetUser','testme@gmail.co',1),(13,'Thisitha','Atapattu','Thisitha#','Thisitha123','thisitha2008@gmail.com',1),(14,'Thisitha','Atapattu','Test2008','Test123','test2008@gmail.com',2),(15,'Thisitha','Atapattu','Thisitha123','Test','nkjdnckjd@gmail.com',1);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_code`
--

DROP TABLE IF EXISTS `admin_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_code` (
  `admin_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`admin_id`),
  CONSTRAINT `fk_user_code_admin` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_code`
--

LOCK TABLES `admin_code` WRITE;
/*!40000 ALTER TABLE `admin_code` DISABLE KEYS */;
INSERT INTO `admin_code` VALUES (2,'62a1752d7e2c2'),(3,'62a5522da12ab');
/*!40000 ALTER TABLE `admin_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_profile_pic`
--

DROP TABLE IF EXISTS `admin_profile_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_profile_pic` (
  `admin_id` int NOT NULL,
  `image_id` int NOT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `fk_admin_profile_pic_image1_idx` (`image_id`),
  CONSTRAINT `fk_admin_profile_pic_admin1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`id`),
  CONSTRAINT `fk_admin_profile_pic_image1` FOREIGN KEY (`image_id`) REFERENCES `image` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_profile_pic`
--

LOCK TABLES `admin_profile_pic` WRITE;
/*!40000 ALTER TABLE `admin_profile_pic` DISABLE KEYS */;
INSERT INTO `admin_profile_pic` VALUES (3,6),(2,7);
/*!40000 ALTER TABLE `admin_profile_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `file_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `subject_has_grade_id` int NOT NULL,
  `status_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_assignment_subject_has_grade1_idx` (`subject_has_grade_id`),
  KEY `fk_assignment_status1_idx` (`status_id`),
  CONSTRAINT `fk_assignment_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `fk_assignment_subject_has_grade1` FOREIGN KEY (`subject_has_grade_id`) REFERENCES `subject_has_grade` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment`
--

LOCK TABLES `assignment` WRITE;
/*!40000 ALTER TABLE `assignment` DISABLE KEYS */;
INSERT INTO `assignment` VALUES (1,'Ass1','62a611229bf98.pptx','2022-06-12','2022-06-12',6,2),(2,'ASS2','62a61166913c5.pdf','2022-06-12','2022-06-30',6,2),(3,'ASS3','62a613b1cdb92.pdf','2022-06-11','2022-06-17',6,2),(4,'Ass1','62a8bb3654ba6.pdf','2022-06-14','2022-06-25',6,2),(5,'Assignment 1','62a8bb5698276.pdf','2022-06-14','2022-06-24',6,2),(6,'Assignment 2','62a8bb6de0ec3.pdf','2022-06-14','2022-06-14',6,2),(7,'To Check The Knowledge Of Maps','62a94b047b292.pdf','2022-06-16','2022-06-23',6,2),(8,'hjkh','62a94b26707b2.pptx','2022-06-16','2022-06-22',6,2),(9,'Assignment 1','62a94e25b89b6.pdf','2022-06-13','2022-06-14',6,1),(10,'Assignment 2','62a98f2c5ea4c.pdf','2022-06-14','2022-06-14',6,1),(11,'Assignment 3','62a9d564f4222.pptx','2022-06-15','2022-06-15',6,1),(12,'Mental Health','62aa3744b3ee8.pdf','2022-06-16','2022-06-18',7,1),(13,'Mental Health','62aa379c8412e.pdf','2022-06-14','2022-06-15',12,1),(14,'Directed Numbers','62aa3b612d98e.pdf','2022-06-16','2022-06-25',1,1),(15,'ss','62aafedce6b9a.pdf','2022-06-16','2022-06-26',1,1),(17,'Directed Numbers','62ab0bb6b8391.pdf','2022-06-16','2022-06-19',11,1);
/*!40000 ALTER TABLE `assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_has_student`
--

DROP TABLE IF EXISTS `assignment_has_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment_has_student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assignment_id` int NOT NULL,
  `student_id` int NOT NULL,
  `file_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_student_has_assignment_assignment1_idx` (`assignment_id`),
  KEY `fk_assignment_has_student_student1_idx` (`student_id`),
  CONSTRAINT `fk_assignment_has_student_student1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`),
  CONSTRAINT `fk_student_has_assignment_assignment1` FOREIGN KEY (`assignment_id`) REFERENCES `assignment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_has_student`
--

LOCK TABLES `assignment_has_student` WRITE;
/*!40000 ALTER TABLE `assignment_has_student` DISABLE KEYS */;
INSERT INTO `assignment_has_student` VALUES (4,10,12,'62a9b1b4ce0ea.pdf','2022-06-15 15:47:24'),(5,11,12,'62aa17bec2764.pdf','2022-06-15 23:02:46'),(6,13,12,'62ab0a8026ea7.zip','2022-06-16 16:18:32');
/*!40000 ALTER TABLE `assignment_has_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_marks`
--

DROP TABLE IF EXISTS `assignment_marks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment_marks` (
  `assignment_has_student_id` int NOT NULL,
  `mark` double NOT NULL,
  `status_id` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`assignment_has_student_id`),
  KEY `fk_assignment_marks_status1_idx` (`status_id`),
  CONSTRAINT `fk_assignment_marks_assignment_has_student1` FOREIGN KEY (`assignment_has_student_id`) REFERENCES `assignment_has_student` (`id`),
  CONSTRAINT `fk_assignment_marks_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_marks`
--

LOCK TABLES `assignment_marks` WRITE;
/*!40000 ALTER TABLE `assignment_marks` DISABLE KEYS */;
INSERT INTO `assignment_marks` VALUES (4,92,1),(5,85,1),(6,80,1);
/*!40000 ALTER TABLE `assignment_marks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `category_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment_payments`
--

DROP TABLE IF EXISTS `enrollment_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollment_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL,
  `student_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_student_payments_student1_idx` (`student_id`),
  CONSTRAINT `fk_student_payments_student1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment_payments`
--

LOCK TABLES `enrollment_payments` WRITE;
/*!40000 ALTER TABLE `enrollment_payments` DISABLE KEYS */;
INSERT INTO `enrollment_payments` VALUES (1,'2013-10-22 10:11:00',13),(15,'2022-06-16 08:22:06',12),(16,'2022-06-16 08:24:32',12),(17,'2022-06-16 08:25:04',12),(18,'2022-06-16 08:30:36',12),(19,'2022-06-16 09:01:26',13),(22,'2022-06-16 13:17:45',11);
/*!40000 ALTER TABLE `enrollment_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade`
--

DROP TABLE IF EXISTS `grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade`
--

LOCK TABLES `grade` WRITE;
/*!40000 ALTER TABLE `grade` DISABLE KEYS */;
INSERT INTO `grade` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13);
/*!40000 ALTER TABLE `grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `image` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image_type_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_image_image_type1_idx` (`image_type_id`),
  CONSTRAINT `fk_image_image_type1` FOREIGN KEY (`image_type_id`) REFERENCES `image_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
INSERT INTO `image` VALUES (6,4,'62a5c831c6f1f'),(7,5,'62a31ec28e129'),(8,4,'62a6b083eea76'),(9,4,'62a5b929df458'),(10,4,'62a6a6627de85');
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image_type`
--

DROP TABLE IF EXISTS `image_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `image_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image_type`
--

LOCK TABLES `image_type` WRITE;
/*!40000 ALTER TABLE `image_type` DISABLE KEYS */;
INSERT INTO `image_type` VALUES (3,'png'),(4,'jpg'),(5,'svg'),(6,'jpeg'),(7,'gif');
/*!40000 ALTER TABLE `image_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_note`
--

DROP TABLE IF EXISTS `lesson_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lesson_note` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(300) COLLATE utf8mb4_bin NOT NULL,
  `file_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `date_time_added` datetime NOT NULL,
  `subject_has_grade_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lesson_notes_subject_has_grade1_idx` (`subject_has_grade_id`),
  CONSTRAINT `fk_lesson_notes_subject_has_grade1` FOREIGN KEY (`subject_has_grade_id`) REFERENCES `subject_has_grade` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lesson_note`
--

LOCK TABLES `lesson_note` WRITE;
/*!40000 ALTER TABLE `lesson_note` DISABLE KEYS */;
INSERT INTO `lesson_note` VALUES (2,' Maps','62aa2c69d0c0c.pdf','2022-06-16 00:30:57',6),(3,'Villages','62aa2c7785663.pptx','2022-06-16 00:31:11',6),(4,'Cities','62aa2ccb31d6e.pdf','2022-06-16 00:32:35',6),(5,'Houses','62aa2cf320554.pdf','2022-06-16 00:33:15',6);
/*!40000 ALTER TABLE `lesson_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(15) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,'Active'),(2,'Blocked');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(400) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `student_grading_id` int NOT NULL,
  `status_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_student_status1_idx` (`status_id`),
  KEY `fk_student_student_grading1_idx` (`student_grading_id`),
  CONSTRAINT `fk_student_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `fk_student_student_grading1` FOREIGN KEY (`student_grading_id`) REFERENCES `student_grading` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (11,'Future','Harp','futureharp12619@gmail.com','Future123','future#',11,1),(12,'Thisitha','Atapattu','thisitha2008@gmail.com','thisitha123','Thisitha',12,1),(13,'Mail','T','emailthisitha@gmail.com','EmailThisita','Mailt',13,1),(14,'Thisitha','Atapattu','test@gmail.com','Test123','Test',14,1),(15,'Thisitha','Atapattu','skjhhkj@gmail.com','TTT','Test',15,1);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_account_access_code`
--

DROP TABLE IF EXISTS `student_account_access_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_account_access_code` (
  `student_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`student_id`),
  CONSTRAINT `fk_student_account_access_code_student1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_account_access_code`
--

LOCK TABLES `student_account_access_code` WRITE;
/*!40000 ALTER TABLE `student_account_access_code` DISABLE KEYS */;
INSERT INTO `student_account_access_code` VALUES (14,'62aa07b521fa7'),(15,'62aa0980eb4c1');
/*!40000 ALTER TABLE `student_account_access_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_code`
--

DROP TABLE IF EXISTS `student_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_code` (
  `student_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`student_id`),
  CONSTRAINT `fk_student_code_student1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_code`
--

LOCK TABLES `student_code` WRITE;
/*!40000 ALTER TABLE `student_code` DISABLE KEYS */;
INSERT INTO `student_code` VALUES (11,'62aabd745cece'),(12,'62a854692837d'),(13,'62a5ad9ea5155');
/*!40000 ALTER TABLE `student_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_grading`
--

DROP TABLE IF EXISTS `student_grading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_grading` (
  `id` int NOT NULL AUTO_INCREMENT,
  `grade_id` int NOT NULL,
  `graded_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_student_grades_grade1_idx` (`grade_id`),
  CONSTRAINT `fk_student_grades_grade1` FOREIGN KEY (`grade_id`) REFERENCES `grade` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_grading`
--

LOCK TABLES `student_grading` WRITE;
/*!40000 ALTER TABLE `student_grading` DISABLE KEYS */;
INSERT INTO `student_grading` VALUES (11,5,'2014-06-13 07:59:08'),(12,8,'2022-05-10 01:30:56'),(13,9,'2022-05-14 16:33:59'),(14,2,'2022-06-15 21:54:21'),(15,5,'2014-06-15 22:02:00');
/*!40000 ALTER TABLE `student_grading` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_profile_pic`
--

DROP TABLE IF EXISTS `student_profile_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_profile_pic` (
  `student_id` int NOT NULL,
  `image_id` int NOT NULL,
  PRIMARY KEY (`student_id`),
  KEY `fk_student_profile_pic_image1_idx` (`image_id`),
  CONSTRAINT `fk_student_profile_pic_image1` FOREIGN KEY (`image_id`) REFERENCES `image` (`id`),
  CONSTRAINT `fk_student_profile_pic_student1` FOREIGN KEY (`student_id`) REFERENCES `student` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_profile_pic`
--

LOCK TABLES `student_profile_pic` WRITE;
/*!40000 ALTER TABLE `student_profile_pic` DISABLE KEYS */;
INSERT INTO `student_profile_pic` VALUES (13,9);
/*!40000 ALTER TABLE `student_profile_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES (1,'Mathematics'),(2,'Science'),(3,'Geography'),(4,'Life Competencies and Citizenship Education'),(5,'History'),(15,'Health & Physical Education');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_has_grade`
--

DROP TABLE IF EXISTS `subject_has_grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_has_grade` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject_id` int NOT NULL,
  `grade_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_subject_has_grade_subject1_idx` (`subject_id`),
  KEY `fk_subject_has_grade_grade1_idx` (`grade_id`),
  CONSTRAINT `fk_subject_has_grade_grade1` FOREIGN KEY (`grade_id`) REFERENCES `grade` (`id`),
  CONSTRAINT `fk_subject_has_grade_subject1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_has_grade`
--

LOCK TABLES `subject_has_grade` WRITE;
/*!40000 ALTER TABLE `subject_has_grade` DISABLE KEYS */;
INSERT INTO `subject_has_grade` VALUES (1,1,9),(2,1,1),(3,1,3),(4,5,6),(5,4,13),(6,3,8),(7,15,6),(8,1,2),(9,4,12),(10,2,8),(11,1,8),(12,15,8),(13,5,8);
/*!40000 ALTER TABLE `subject_has_grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(300) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `subject_has_grade_id` int NOT NULL,
  `status_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_teacher_status1_idx` (`status_id`),
  KEY `fk_teacher_subject_has_grade1_idx` (`subject_has_grade_id`),
  CONSTRAINT `fk_teacher_status1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`),
  CONSTRAINT `fk_teacher_subject_has_grade1` FOREIGN KEY (`subject_has_grade_id`) REFERENCES `subject_has_grade` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher`
--

LOCK TABLES `teacher` WRITE;
/*!40000 ALTER TABLE `teacher` DISABLE KEYS */;
INSERT INTO `teacher` VALUES (3,'Thisitha','Atapattu','Teacher123','thisitha2008@gmail.com','teach',12,1),(4,'Thisitha','Atapattu','Future','futureharp12619@gmail.com','Futurejune',11,1),(5,'Thisitha','E','Ethisitha','emailthisitha@gmail.com','Et123',12,1),(6,'Thisitha','Atapattu','Test4','kskcsjkchjh@gmail.com','Test123',11,1);
/*!40000 ALTER TABLE `teacher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_account_access_code`
--

DROP TABLE IF EXISTS `teacher_account_access_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_account_access_code` (
  `teacher_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`teacher_id`),
  CONSTRAINT `fk_teacher_account_access_code_teacher1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_account_access_code`
--

LOCK TABLES `teacher_account_access_code` WRITE;
/*!40000 ALTER TABLE `teacher_account_access_code` DISABLE KEYS */;
INSERT INTO `teacher_account_access_code` VALUES (6,'62aa084c3f830');
/*!40000 ALTER TABLE `teacher_account_access_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_code`
--

DROP TABLE IF EXISTS `teacher_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_code` (
  `teacher_id` int NOT NULL,
  `code` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`teacher_id`),
  CONSTRAINT `fk_teacher_code_teacher1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_code`
--

LOCK TABLES `teacher_code` WRITE;
/*!40000 ALTER TABLE `teacher_code` DISABLE KEYS */;
INSERT INTO `teacher_code` VALUES (3,'62aa3b3ecffdd'),(4,'62ab0b95353d3'),(5,'62a58f4b0124f');
/*!40000 ALTER TABLE `teacher_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_profile_pic`
--

DROP TABLE IF EXISTS `teacher_profile_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_profile_pic` (
  `teacher_id` int NOT NULL,
  `image_id` int NOT NULL,
  PRIMARY KEY (`teacher_id`),
  KEY `fk_teacher_profile_pic_image1_idx` (`image_id`),
  CONSTRAINT `fk_teacher_profile_pic_image1` FOREIGN KEY (`image_id`) REFERENCES `image` (`id`),
  CONSTRAINT `fk_teacher_profile_pic_teacher1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_profile_pic`
--

LOCK TABLES `teacher_profile_pic` WRITE;
/*!40000 ALTER TABLE `teacher_profile_pic` DISABLE KEYS */;
INSERT INTO `teacher_profile_pic` VALUES (5,10);
/*!40000 ALTER TABLE `teacher_profile_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'assignment1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-16 19:42:21
