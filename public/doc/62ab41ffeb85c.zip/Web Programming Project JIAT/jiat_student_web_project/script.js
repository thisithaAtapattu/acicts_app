function logInAdmin() {

    //Getting username & password fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password to the form
    form.append("username", username.value);
    form.append("password", password.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;



            if (response != "success") {


                swal({
                    title: response,

                    icon: "warning",
                    button: "OK",
                    dangerMode: true,
                })



            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "admin_login_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}





function notDeveloped() {


    alert("This function was not developed due to having less time.");



}



function logOutAdmin() {

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {


            location.reload();


        }


    };


    //Gets ready to send the request
    request.open("POST", "logout_admin.php", true);
    //Sends the request
    request.send();






}



function previewProfileAdmin() {

    //filechooser taken by Id
    var file_chooser = document.getElementById("profile_pic");

    //Image previewing img tag taken by Id
    var perview_img = document.getElementById("img_pro_prev");



    //Once a file is selected 
    file_chooser.onchange = function() {

        //getting the file name
        var filename = $(document.getElementById("profile_pic")).val().replace(/.*(\/|\\)/, '');

        //if the file name is not empty
        if (filename != "") {





            var file = this.files[0];

            var file_type = file.type;

            var file_type_sub = file_type.substr(0, 5);

            if (file_type_sub == "image") {


                swal({
                        title: "Are you sure?",
                        text: "That you want to add a new profile picture?",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                        buttons: ["No", "Yes"],
                    })
                    .then((willDelete) => {
                        if (willDelete) {



                            var form = new FormData();
                            //Appends the 1st file  of the file selector as 0 to the form since the list of selected images is an array 
                            form.append("profile_pic", file_chooser.files[0]);

                            //Ajax Object to send the request asynchronously
                            var request = new XMLHttpRequest();

                            //There are 4 ready states and on each change of ready state this event works
                            request.onreadystatechange = function() {



                                //Checks if the ready state is 4 since it is the response ready state
                                if (request.readyState == 4) {

                                    var response = request.responseText; //gets the response text



                                    if (response == "success") { //if the reponse text is "success"



                                        var url = window.URL.createObjectURL(file); //creates temporory url for the image

                                        perview_img.src = url; //add the temperory url to image preview

                                        document.getElementById("profile_pic_selector_button").innerHTML = "Update Profile Picture"; //Changes the Upload Profile Picture to Update profile picture in the Update Profile Picture label

                                    }











                                }


                            };


                            //Gets ready to send the request
                            request.open("POST", "upload_admin_profile_pic.php", true);
                            //Sends the request with the parameters in the form
                            request.send(form);






                        }
                    });


            }




        }






    }







}

function update_profile_admin() {

    //Taken first name, last name,email,  username by Id
    var first_name = document.getElementById("first_name_update");
    var last_name = document.getElementById("last_name_update");
    var username = document.getElementById("username_update");
    var email = document.getElementById("email_update");


    var form = new FormData(); //FormData object
    //Appends first name, last name, email, username to the FormData object
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("username", username.value);
    form.append("email", email.value)

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText; //gets the response text

            if (response == "Please enter the first name." || response == "Please enter the last name." || response == "Please enter the username." || response == "Please enter the email." || response == "Invalid email format!") { //if there are erros in the validations


                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else { //if not

                Toastify({
                    text: "Profile Successfully Updated!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

                document.getElementById("name_viewer").innerHTML = JSON.parse(response).full_name; //add the newly update name through json to the name viewer


            }






        }


    };


    //Gets ready to send the request
    request.open("POST", "update_profile_admin.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}

function goToManageAmin() {


    window.location = "manage-administration";


}

function goToAmin() {


    window.location = "admin";


}

function addNewAdmin() {

    //taken the fileds to enter data by id
    var first_name = document.getElementById("first_name");
    var last_name = document.getElementById("last_name");
    var email = document.getElementById("email");
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm_password");

    var form = new FormData(); //FormData Object
    //appended all values from fields to the form
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("email", email.value);
    form.append("username", username.value);
    form.append("password", password.value);
    form.append("confirm_password", confirm_password.value);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;

            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {

                document.getElementById("first_name").value = "";
                document.getElementById("last_name").value = "";
                document.getElementById("email").value = "";
                document.getElementById("username").value = "";
                document.getElementById("password").value = "";
                document.getElementById("confirm_password").value = "";

                loadAdminToTable();


                Toastify({
                    text: "Admin successfully added!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

            }










        }


    };


    //Gets ready to send the request
    request.open("POST", "add_admin_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}

function changeAdminStatus(adminId) {

    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("adminId", adminId);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;



            if (response == "You aren't allowed to change your own account's status." || response == "Admin not found.") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {


                if (response == "Blocked") {

                    document.getElementById("AdminstatusChangeButton" + adminId).className = "btn btn-success d-grid";
                    document.getElementById("AdminstatusChangeButton" + adminId).innerHTML = "Activate";


                } else {



                    document.getElementById("AdminstatusChangeButton" + adminId).className = "btn btn-danger d-grid";
                    document.getElementById("AdminstatusChangeButton" + adminId).innerHTML = "Block";






                }


                document.getElementById("statusColumn" + adminId).innerHTML = response;



            }




        }




    };
    //Gets ready to send the request
    request.open("POST", "change_admin_status.php", true);
    //Sends the request with the parameters in the form
    request.send(form);

}


function loadAdminToTable() {

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("admin_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_admins.php", true);
    //Sends the request with the parameters in the form
    request.send();


}




function searchAdmins() {

    var form = new FormData(); //FormData object
    form.append("searchAdmin", document.getElementById("searchAdmin").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("admin_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_admins.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}



function checkStatusAdmin() {



    setInterval(function() {




        var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
        //There are 4 ready states and on each change of ready state this event works
        request.onreadystatechange = function() {

            if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

                var response = request.responseText;

                if (response == "Blocked" || response == "Admin signed out") {

                    location.reload();


                }






            }



        };

        //Gets ready to send the request
        request.open("POST", "check_admin_status.php", true);
        //Sends the request with the parameters in the form
        request.send();





    }, 1000);





}

function goToManageStudents() {

    window.location = "manage-students"; //redirects to manage-students page 

}


function addNewStudent() {

    var first_name = document.getElementById("first_name");
    var last_name = document.getElementById("last_name");
    var email = document.getElementById("email");
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm_password");
    var grade = document.getElementById("grade");

    var form = new FormData(); //FormData object
    //appends the data to the form
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("email", email.value);
    form.append("username", username.value);
    form.append("password", password.value);
    form.append("confirm_password", confirm_password.value);
    form.append("grade", grade.value);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;

            document.getElementById("send_verification_loader").classList.add("d-none");


            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {

                document.getElementById("first_name").value = "";
                document.getElementById("last_name").value = "";
                document.getElementById("email").value = "";
                document.getElementById("username").value = "";
                document.getElementById("password").value = "";
                document.getElementById("confirm_password").value = "";
                document.getElementById("grade").value = "";

                loadStudentToTable();



                Toastify({
                    text: "Student successfully added & Invitation was sent!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

            }












        } else {
            document.getElementById("send_verification_loader").classList.remove("d-none");


        }



    };

    //Gets ready to send the request
    request.open("POST", "add_student_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}



function changeStudentStatus(studentId) {

    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("studentId", studentId);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;


            if (response == "Student not found." || response == "This student is not verified.") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {


                if (response == "Blocked") {

                    document.getElementById("StudentstatusChangeButton" + studentId).className = "btn btn-success d-grid";
                    document.getElementById("StudentstatusChangeButton" + studentId).innerHTML = "Activate";


                } else {



                    document.getElementById("StudentstatusChangeButton" + studentId).className = "btn btn-danger d-grid";
                    document.getElementById("StudentstatusChangeButton" + studentId).innerHTML = "Block";






                }


                document.getElementById("statusColumn" + studentId).innerHTML = response;



            }




        }




    };
    //Gets ready to send the request
    request.open("POST", "change_student_status.php", true);
    //Sends the request with the parameters in the form
    request.send(form);

}



function searchStudents() {

    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("searchStudent", document.getElementById("searchStudent").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("student_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_students.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}

function goToManageSyllabus() {


    window.location = "manage-syllabus"; //Redirects to manage syllabus page


}


function addSubject() {

    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("subject_name", document.getElementById("subject_name").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;

            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {

                document.getElementById("subject_name").value = "";

                loadSubjectsToTable();



                Toastify({
                    text: "Subject successfully added!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

            }







        }



    };

    //Gets ready to send the request
    request.open("POST", "add_subject.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}



function loadSubjectsToTable() {

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("subject_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_subjects.php", true);
    //Sends the request
    request.send();


}



function addMapping() {

    var subject = document.getElementById("subject");
    var grade = document.getElementById("grade");

    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("subject", subject.value);
    form.append("grade", grade.value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;

            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {

                document.getElementById("subject").value = "";
                document.getElementById("grade").value = "";

                loadSubjectsHasGradeToTable();



                Toastify({
                    text: "Mapping successfully added!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

            }







        }



    };

    //Gets ready to send the request
    request.open("POST", "add_subject_grade_mapping.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}




function loadSubjectsHasGradeToTable() {

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("subject_has_grade_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_subject_has_grade.php", true);
    //Sends the request
    request.send();


}

function goToManageTeachers() {

    window.location = "manage-teachers";

}

var gradeChangeModal;


function openGradeChangeModal(studentId) {

    document.getElementById("grade").value = "";

    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("studentId", studentId);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;


            if (response != "Student not found!") {

                var studentJson = JSON.parse(response);

                document.getElementById("changeGradeModalLabel").innerHTML = studentJson.name;
                document.getElementById("gradeChangeButton").onclick = function() {

                    changeGrade(studentId);



                };

                document.getElementById("passGradeButton").onclick = function() {


                    passGrade(studentId);



                };


                var changeGradeModal = document.getElementById("changeGradeModal");
                gradeChangeModal = new bootstrap.Modal(changeGradeModal);
                gradeChangeModal.show();


            } else {



                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            }









        }



    };

    //Gets ready to send the request
    request.open("POST", "get_grade_change_data.php", true);
    //Sends the request with the parameters in the form
    request.send(form);






}

function changeGrade(studentId) {


    swal({
            title: "Are you sure?",
            text: "That you want to change this student's grade?",
            icon: "warning",
            buttons: true,
            dangerMode: true,
            buttons: ["No", "Yes"],
        })
        .then((willDelete) => {
            if (willDelete) {

                var form = new FormData(); //FormData object
                //appends the values to the form
                form.append("studentId", studentId);
                form.append("gradeId", document.getElementById("grade").value);

                var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
                //There are 4 ready states and on each change of ready state this event works
                request.onreadystatechange = function() {

                    if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


                        var response = request.responseText;


                        if (response == "Student not found!" || response == "Please select a grade." || response == "Grade not found!") {





                            Toastify({
                                text: response,
                                className: "info",
                                style: {
                                    background: "#f14668",
                                }
                            }).showToast();


                        } else {

                            document.getElementById("studentGradeView" + studentId).innerHTML = response;
                            document.getElementById("grade").value = "";

                            Toastify({
                                text: "Grade successfully edited!",
                                className: "info",
                                style: {
                                    background: "#48c78e",
                                }
                            }).showToast();


                            gradeChangeModal.hide();

                        }







                    }



                };

                //Gets ready to send the request
                request.open("POST", "change_grade_student.php", true);
                //Sends the request
                request.send(form);


            }
        });



}

function passGrade(studentId) {


    var form = new FormData(); //FormData object
    //appends the values to the form

    form.append("studentId", studentId);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;


            if (response == "Student not found!" || response == "Grade 13 students can't be passed further.") {


                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {

                var studentJson = JSON.parse(response);



                swal({
                        title: "Are you sure?",
                        text: "That you want to pass " + studentJson.student_name + " from grade " + studentJson.grade + " to " + studentJson.new_grade + ".",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                        buttons: ["No", "Yes"],
                    })
                    .then((willDelete) => {
                        if (willDelete) {

                            var form = new FormData(); //FormData object
                            //appends the values to the form

                            form.append("studentId", studentId);

                            var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
                            //There are 4 ready states and on each change of ready state this event works
                            request.onreadystatechange = function() {

                                if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


                                    var response = request.responseText;




                                    if (response == "Student not found!" || response == "Grade 13 students can't be passed further.") {



                                        Toastify({
                                            text: response,
                                            className: "info",
                                            style: {
                                                background: "#f14668",
                                            }
                                        }).showToast();


                                    } else {

                                        document.getElementById("studentGradeView" + studentId).innerHTML = response;

                                        Toastify({
                                            text: "Student successfully passed to grade " + studentJson.new_grade + ".",
                                            className: "info",
                                            style: {
                                                background: "#48c78e",
                                            }
                                        }).showToast();


                                        gradeChangeModal.hide();

                                    }







                                }



                            };

                            //Gets ready to send the request
                            request.open("POST", "pass_student.php", true);
                            //Sends the request
                            request.send(form);


                        }
                    });



            }


        }



    };

    //Gets ready to send the request
    request.open("POST", "get_details_to_pass_grade.php", true);
    //Sends the request
    request.send(form);










}

function addNewTeacher() {


    var first_name = document.getElementById("first_name");
    var last_name = document.getElementById("last_name");
    var email = document.getElementById("email");
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm_password");
    var subject_has_grade = document.getElementById("subject_has_grade");

    var form = new FormData(); //FormData object
    //appends the data to the form
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("email", email.value);
    form.append("username", username.value);
    form.append("password", password.value);
    form.append("confirm_password", confirm_password.value);
    form.append("subject_has_grade", subject_has_grade.value);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;

            document.getElementById("send_verification_loader").classList.add("d-none");


            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {

                document.getElementById("first_name").value = "";
                document.getElementById("last_name").value = "";
                document.getElementById("email").value = "";
                document.getElementById("username").value = "";
                document.getElementById("password").value = "";
                document.getElementById("confirm_password").value = "";
                document.getElementById("subject_has_grade").value = "";




                Toastify({
                    text: "Teacher successfully added & Invitation was sent!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

            }












        } else {
            document.getElementById("send_verification_loader").classList.remove("d-none");


        }



    };

    //Gets ready to send the request
    request.open("POST", "add_teacher_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}


function changeTeacherStatus(teacherId) {


    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("teacherId", teacherId);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;



            if (response == "Teacher not found." || response == "This teacher is not verified.") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {


                if (response == "Blocked") {

                    document.getElementById("teacherstatusChangeButton" + teacherId).className = "btn btn-success d-grid";
                    document.getElementById("teacherstatusChangeButton" + teacherId).innerHTML = "Activate";


                } else {



                    document.getElementById("teacherstatusChangeButton" + teacherId).className = "btn btn-danger d-grid";
                    document.getElementById("teacherstatusChangeButton" + teacherId).innerHTML = "Block";






                }


                document.getElementById("statusColumn" + teacherId).innerHTML = response;



            }




        }




    };
    //Gets ready to send the request
    request.open("POST", "change_teacher_status.php", true);
    //Sends the request with the parameters in the form
    request.send(form);



}


function changeTeacherGrade(teacherId) {


    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("teacherId", teacherId);
    form.append("subject_has_grade", document.getElementById("subject_has_grade_individual_teacher" + teacherId).value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state



            var response = request.responseText;

            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {


                Toastify({
                    text: "Teacher's subject area successfully changed.",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

            }








        }



    };

    //Gets ready to send the request
    request.open("POST", "change_teacher_grade.php", true);
    //Sends the request with the parameters in the form
    request.send(form);





}



function loadTeacherToTable() {

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("teacher_loading_area").innerHTML = request.responseText;







        }



    };

    //Gets ready to send the request
    request.open("POST", "load_teachers.php", true);
    //Sends the request with the parameters in the form
    request.send();


}


function searchTeachers() {

    var form = new FormData(); //FormData object
    form.append("searchTeacher", document.getElementById("searchTeacher").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("teacher_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_teachers.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}

function goToManageAcademicOfficers() {


    window.location = "manage-academic-officers"; //redirects to manage academic officers page


}

function addNewAcademicOfficer() {

    //taken the fileds to enter data by id
    var first_name = document.getElementById("first_name");
    var last_name = document.getElementById("last_name");
    var email = document.getElementById("email");
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var confirm_password = document.getElementById("confirm_password");

    var form = new FormData(); //FormData Object
    //appended all values from fields to the form
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("email", email.value);
    form.append("username", username.value);
    form.append("password", password.value);
    form.append("confirm_password", confirm_password.value);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            document.getElementById("send_verification_loader").classList.add("d-none");

            var response = request.responseText;

            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {

                document.getElementById("first_name").value = "";
                document.getElementById("last_name").value = "";
                document.getElementById("email").value = "";
                document.getElementById("username").value = "";
                document.getElementById("password").value = "";
                document.getElementById("confirm_password").value = "";




                Toastify({
                    text: "Academic Officer successfully added & Invitation was sent!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

            }










        } else {
            document.getElementById("send_verification_loader").classList.remove("d-none");


        }


    };


    //Gets ready to send the request
    request.open("POST", "add_academic_officer_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);

}

function changeAcademicOfficerStatus(academicOfficerId) {


    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("academicOfficerId", academicOfficerId);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;


            if (response == "This Academic Officer is not verified." || response == "Academic Officer not found.") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {


                if (response == "Blocked") {

                    document.getElementById("academic_officerstatusChangeButton" + academicOfficerId).className = "btn btn-success d-grid";
                    document.getElementById("academic_officerstatusChangeButton" + academicOfficerId).innerHTML = "Activate";


                } else {



                    document.getElementById("academic_officerstatusChangeButton" + academicOfficerId).className = "btn btn-danger d-grid";
                    document.getElementById("academic_officerstatusChangeButton" + academicOfficerId).innerHTML = "Block";






                }


                document.getElementById("statusColumn" + academicOfficerId).innerHTML = response;



            }




        }




    };
    //Gets ready to send the request
    request.open("POST", "change_academic_officer_status.php", true);
    //Sends the request with the parameters in the form
    request.send(form);



}

function searchAcademicOfficer() {

    var form = new FormData(); //FormData object
    form.append("searchacAdemicOfficer", document.getElementById("searchacAdemicOfficer").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("academic_officer_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_academic_officers.php", true);
    //Sends the request with the parameters in the form
    request.send(form);



}

function verifyLogInAcademicOfficer() {



    //Getting username & password & verification code fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var verification_code = document.getElementById("verification_code");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password and verfication code to the form
    form.append("username", username.value);
    form.append("password", password.value);
    form.append("verification_code", verification_code.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;



            if (response != "success") {


                swal({
                    title: response,

                    icon: "warning",
                    button: "OK",
                    dangerMode: true,
                })



            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "academic_officer_verify_login.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}




function logInAcademicOfficer() {

    //Getting username & password fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password to the form
    form.append("username", username.value);
    form.append("password", password.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;



            if (response != "success") {


                swal({
                    title: response,

                    icon: "warning",
                    button: "OK",
                    dangerMode: true,
                })



            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "academic_officer_login_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}

function verifyLogInTeacher() {

    //Getting username & password & verification code fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var verification_code = document.getElementById("verification_code");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password and verfication code to the form
    form.append("username", username.value);
    form.append("password", password.value);
    form.append("verification_code", verification_code.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;



            if (response != "success") {


                swal({
                    title: response,

                    icon: "warning",
                    button: "OK",
                    dangerMode: true,
                })



            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "teacher_verify_login.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}

function logInTeacher() {


    //Getting username & password fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password to the form
    form.append("username", username.value);
    form.append("password", password.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;



            if (response != "success") {


                swal({
                    title: response,

                    icon: "warning",
                    button: "OK",
                    dangerMode: true,
                })



            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "teacher_login_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}

function verifyLogInStudent() {


    //Getting username & password & verification code fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var verification_code = document.getElementById("verification_code");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password and verfication code to the form
    form.append("username", username.value);
    form.append("password", password.value);
    form.append("verification_code", verification_code.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;



            if (response != "success") {


                swal({
                    title: response,

                    icon: "warning",
                    button: "OK",
                    dangerMode: true,
                })



            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "student_verify_login.php", true);
    //Sends the request with the parameters in the form
    request.send(form);

}

var paymentModal;

function logInStudent() {


    document.getElementById("paypal-button-container").innerHTML = "";

    //Getting username & password fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password to the form
    form.append("username", username.value);
    form.append("password", password.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;


            // alert(response);




            if (response != "success") {


                if (response == "success-payment-must") {
                    document.getElementById("log_continue").classList.remove("d-none");
                    document.getElementById("payment_message_viewer").innerHTML = "You're using the 1 month free trial version. Make a payment to keep your account activated throughout your new grade.";
                    paypal.Buttons({
                        createOrder: function(data, actions) {
                            // This function sets up the details of the transaction, including the amount and line item details.
                            return actions.order.create({
                                purchase_units: [{
                                    amount: {
                                        value: '1.39'
                                    }
                                }]
                            });
                        },
                        onApprove: function(data, actions) {
                            // This function captures the funds from the transaction.
                            return actions.order.capture().then(function(details) {
                                // This function shows a transaction success message to your buyer.

                                var request = new XMLHttpRequest();

                                //There are 4 ready states and on each change of ready state this event works
                                request.onreadystatechange = function() {



                                    //Checks if the ready state is 4 since it is the response ready state
                                    if (request.readyState == 4) {




                                        var response = request.responseText;

                                        swal({
                                            title: "Payement Successfully Completed!",

                                            icon: "success",
                                            button: "OK",
                                        }).then((willDelete) => {
                                            if (willDelete) {




                                                studentLogInFinal();



                                            }
                                        });


                                        paymentModal.hide();






                                    }


                                };


                                //Gets ready to send the request
                                request.open("POST", "make_payment_student.php", true);
                                //Sends the request with the parameters in the form
                                request.send(form);


                            });
                        }
                    }).render('#paypal-button-container');




                    var paymentMod = document.getElementById("paymentModal");
                    paymentModal = new bootstrap.Modal(paymentMod);
                    paymentModal.show();


                } else if (response == "trial is over") {

                    document.getElementById("log_continue").classList.add("d-none");
                    document.getElementById("payment_message_viewer").innerHTML = "Your 1 month free trial period is over. Please make a payment to access your account for your current grade.";

                    paypal.Buttons({
                        createOrder: function(data, actions) {
                            // This function sets up the details of the transaction, including the amount and line item details.
                            return actions.order.create({
                                purchase_units: [{
                                    amount: {
                                        value: '1.39'
                                    }
                                }]
                            });
                        },
                        onApprove: function(data, actions) {
                            // This function captures the funds from the transaction.
                            return actions.order.capture().then(function(details) {
                                // This function shows a transaction success message to your buyer.

                                var request = new XMLHttpRequest();

                                //There are 4 ready states and on each change of ready state this event works
                                request.onreadystatechange = function() {



                                    //Checks if the ready state is 4 since it is the response ready state
                                    if (request.readyState == 4) {




                                        var response = request.responseText;

                                        swal({
                                            title: "Payement Successfully Completed!",

                                            icon: "success",
                                            button: "OK",
                                        }).then((willDelete) => {
                                            if (willDelete) {




                                                studentLogInFinal();



                                            }
                                        });


                                        paymentModal.hide();






                                    }


                                };


                                //Gets ready to send the request
                                request.open("POST", "make_payment_student.php", true);
                                //Sends the request with the parameters in the form
                                request.send(form);


                            });
                        }
                    }).render('#paypal-button-container');




                    var paymentMod = document.getElementById("paymentModal");
                    paymentModal = new bootstrap.Modal(paymentMod);
                    paymentModal.show();




                } else {

                    swal({
                        title: response,

                        icon: "warning",
                        button: "OK",
                        dangerMode: true,
                    })
                }


            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "student_login_process.php", true);
    //Sends the request with the parameters in the form
    request.send(form);



}


function studentLogInFinal() {

    //Getting username & password fields by Id
    var username = document.getElementById("username");
    var password = document.getElementById("password");

    // Getting the remember me checkbox by Id
    var remember = document.getElementById("remember");




    var form = new FormData();
    //Appends username and password to the form
    form.append("username", username.value);
    form.append("password", password.value);
    //Appends the boolean value of the checkbox if checked or not to the form
    form.append("remember", remember.checked);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText;


            // alert(response);




            if (response != "success") {



                swal({
                    title: response,

                    icon: "warning",
                    button: "OK",
                    dangerMode: true,
                })



            } else {


                location.reload();



            }








        }


    };


    //Gets ready to send the request
    request.open("POST", "student_login_process_final.php", true);
    //Sends the request with the parameters in the form
    request.send(form);





}




function previewProfileAcademicOfficer() {

    //filechooser taken by Id
    var file_chooser = document.getElementById("profile_pic");

    //Image previewing img tag taken by Id
    var perview_img = document.getElementById("img_pro_prev");



    //Once a file is selected 
    file_chooser.onchange = function() {

        //getting the file name
        var filename = $(document.getElementById("profile_pic")).val().replace(/.*(\/|\\)/, '');

        //if the file name is not empty
        if (filename != "") {





            var file = this.files[0];

            var file_type = file.type;

            var file_type_sub = file_type.substr(0, 5);

            if (file_type_sub == "image") {


                swal({
                        title: "Are you sure?",
                        text: "That you want to add a new profile picture?",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                        buttons: ["No", "Yes"],
                    })
                    .then((willDelete) => {
                        if (willDelete) {



                            var form = new FormData();
                            //Appends the 1st file  of the file selector as 0 to the form since the list of selected images is an array 
                            form.append("profile_pic", file_chooser.files[0]);

                            //Ajax Object to send the request asynchronously
                            var request = new XMLHttpRequest();

                            //There are 4 ready states and on each change of ready state this event works
                            request.onreadystatechange = function() {



                                //Checks if the ready state is 4 since it is the response ready state
                                if (request.readyState == 4) {

                                    var response = request.responseText; //gets the response text



                                    if (response == "success") { //if the reponse text is "success"



                                        var url = window.URL.createObjectURL(file); //creates temporory url for the image

                                        perview_img.src = url; //add the temperory url to image preview

                                        document.getElementById("profile_pic_selector_button").innerHTML = "Update Profile Picture"; //Changes the Upload Profile Picture to Update profile picture in the Update Profile Picture label

                                    }











                                }


                            };


                            //Gets ready to send the request
                            request.open("POST", "upload_academic_officer_profile_pic.php", true);
                            //Sends the request with the parameters in the form
                            request.send(form);






                        }
                    });


            }




        }






    }







}


function logOutAcademicOfficer() {

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {


            location.reload();


        }


    };


    //Gets ready to send the request
    request.open("POST", "logout_academic_officer.php", true);
    //Sends the request
    request.send();



}

function goToAcademicOfficer() {


    window.location = "academic-officer-login";


}

function checkStatusAcademicOfficer() {

    setInterval(function() {




        var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
        //There are 4 ready states and on each change of ready state this event works
        request.onreadystatechange = function() {

            if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

                var response = request.responseText;

                if (response == "Blocked" || response == "Signed out") {

                    location.reload();


                }






            }



        };

        //Gets ready to send the request
        request.open("POST", "check_academic_officer_status.php", true);
        //Sends the request with the parameters in the form
        request.send();





    }, 1000);





}

function update_profile_academic_officer() {


    //Taken first name, last name,email,  username by Id
    var first_name = document.getElementById("first_name_update");
    var last_name = document.getElementById("last_name_update");
    var username = document.getElementById("username_update");
    var email = document.getElementById("email_update");


    var form = new FormData(); //FormData object
    //Appends first name, last name, email, username to the FormData object
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("username", username.value);
    form.append("email", email.value)

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText; //gets the response text

            if (response == "Please enter the first name." || response == "Please enter the last name." || response == "Please enter the username." || response == "Please enter the email." || response == "Invalid email format!") { //if there are erros in the validations


                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else { //if not

                Toastify({
                    text: "Profile Successfully Updated!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

                document.getElementById("name_viewer").innerHTML = JSON.parse(response).full_name; //add the newly update name through json to the name viewer


            }






        }


    };


    //Gets ready to send the request
    request.open("POST", "update_profile_academic_officer.php", true);
    //Sends the request with the parameters in the form
    request.send(form);



}

function goToAddStudents() {


    window.location = "add-students";


}

function goToAcademicOfficer() {



    window.location = "academic-officer";



}


function loadStudentToTable() {

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("student_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_students.php", true);
    //Sends the request with the parameters in the form
    request.send();


}

function searchStudentsAcademic() {

    var form = new FormData(); //FormData object
    //appends the values to the form
    form.append("searchStudent", document.getElementById("searchStudent").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("student_loading_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_students_academic.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}

function previewProfileStudent() {

    //filechooser taken by Id
    var file_chooser = document.getElementById("profile_pic");

    //Image previewing img tag taken by Id
    var perview_img = document.getElementById("img_pro_prev");



    //Once a file is selected 
    file_chooser.onchange = function() {

        //getting the file name
        var filename = $(document.getElementById("profile_pic")).val().replace(/.*(\/|\\)/, '');

        //if the file name is not empty
        if (filename != "") {





            var file = this.files[0];

            var file_type = file.type;

            var file_type_sub = file_type.substr(0, 5);

            if (file_type_sub == "image") {


                swal({
                        title: "Are you sure?",
                        text: "That you want to add a new profile picture?",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                        buttons: ["No", "Yes"],
                    })
                    .then((willDelete) => {
                        if (willDelete) {



                            var form = new FormData();
                            //Appends the 1st file  of the file selector as 0 to the form since the list of selected images is an array 
                            form.append("profile_pic", file_chooser.files[0]);

                            //Ajax Object to send the request asynchronously
                            var request = new XMLHttpRequest();

                            //There are 4 ready states and on each change of ready state this event works
                            request.onreadystatechange = function() {



                                //Checks if the ready state is 4 since it is the response ready state
                                if (request.readyState == 4) {

                                    var response = request.responseText; //gets the response text



                                    if (response == "success") { //if the reponse text is "success"



                                        var url = window.URL.createObjectURL(file); //creates temporory url for the image

                                        perview_img.src = url; //add the temperory url to image preview

                                        document.getElementById("profile_pic_selector_button").innerHTML = "Update Profile Picture"; //Changes the Upload Profile Picture to Update profile picture in the Update Profile Picture label

                                    }











                                }


                            };


                            //Gets ready to send the request
                            request.open("POST", "upload_student_profile_pic.php", true);
                            //Sends the request with the parameters in the form
                            request.send(form);






                        }
                    });


            }




        }






    }








}

function logOutStudent() {


    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {


            location.reload();


        }


    };


    //Gets ready to send the request
    request.open("POST", "logout_student.php", true);
    //Sends the request
    request.send();






}

function update_profile_student() {

    //Taken first name, last name,email,  username by Id
    var first_name = document.getElementById("first_name_update");
    var last_name = document.getElementById("last_name_update");
    var username = document.getElementById("username_update");
    var email = document.getElementById("email_update");


    var form = new FormData(); //FormData object
    //Appends first name, last name, email, username to the FormData object
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("username", username.value);
    form.append("email", email.value)

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText; //gets the response text

            if (response == "Please enter the first name." || response == "Please enter the last name." || response == "Please enter the username." || response == "Please enter the email." || response == "Invalid email format!") { //if there are erros in the validations


                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else { //if not

                Toastify({
                    text: "Profile Successfully Updated!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

                document.getElementById("name_viewer").innerHTML = JSON.parse(response).full_name; //add the newly update name through json to the name viewer


            }






        }


    };


    //Gets ready to send the request
    request.open("POST", "update_profile_student.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}

function checkStatusStudent() {


    setInterval(function() {




        var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
        //There are 4 ready states and on each change of ready state this event works
        request.onreadystatechange = function() {

            if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

                var response = request.responseText;


                if (response == "Blocked" || response == "Signed out") {

                    location.reload();


                }






            }



        };

        //Gets ready to send the request
        request.open("POST", "check_student_status.php", true);
        //Sends the request with the parameters in the form
        request.send();





    }, 1000);







}

function previewProfileTeacher() {


    //filechooser taken by Id
    var file_chooser = document.getElementById("profile_pic");

    //Image previewing img tag taken by Id
    var perview_img = document.getElementById("img_pro_prev");



    //Once a file is selected 
    file_chooser.onchange = function() {

        //getting the file name
        var filename = $(document.getElementById("profile_pic")).val().replace(/.*(\/|\\)/, '');

        //if the file name is not empty
        if (filename != "") {





            var file = this.files[0];

            var file_type = file.type;

            var file_type_sub = file_type.substr(0, 5);

            if (file_type_sub == "image") {


                swal({
                        title: "Are you sure?",
                        text: "That you want to add a new profile picture?",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                        buttons: ["No", "Yes"],
                    })
                    .then((willDelete) => {
                        if (willDelete) {



                            var form = new FormData();
                            //Appends the 1st file  of the file selector as 0 to the form since the list of selected images is an array 
                            form.append("profile_pic", file_chooser.files[0]);

                            //Ajax Object to send the request asynchronously
                            var request = new XMLHttpRequest();

                            //There are 4 ready states and on each change of ready state this event works
                            request.onreadystatechange = function() {



                                //Checks if the ready state is 4 since it is the response ready state
                                if (request.readyState == 4) {

                                    var response = request.responseText; //gets the response text



                                    if (response == "success") { //if the reponse text is "success"



                                        var url = window.URL.createObjectURL(file); //creates temporory url for the image

                                        perview_img.src = url; //add the temperory url to image preview

                                        document.getElementById("profile_pic_selector_button").innerHTML = "Update Profile Picture"; //Changes the Upload Profile Picture to Update profile picture in the Update Profile Picture label

                                    }











                                }


                            };


                            //Gets ready to send the request
                            request.open("POST", "upload_teacher_profile_pic.php", true);
                            //Sends the request with the parameters in the form
                            request.send(form);






                        }
                    });


            }




        }






    }






}

function logOutTeacher() {


    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {


            location.reload();


        }


    };


    //Gets ready to send the request
    request.open("POST", "logout_teacher.php", true);
    //Sends the request
    request.send();





}

function update_profile_teacher() {

    //Taken first name, last name,email,  username by Id
    var first_name = document.getElementById("first_name_update");
    var last_name = document.getElementById("last_name_update");
    var username = document.getElementById("username_update");
    var email = document.getElementById("email_update");


    var form = new FormData(); //FormData object
    //Appends first name, last name, email, username to the FormData object
    form.append("first_name", first_name.value);
    form.append("last_name", last_name.value);
    form.append("username", username.value);
    form.append("email", email.value)

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText; //gets the response text

            if (response == "Please enter the first name." || response == "Please enter the last name." || response == "Please enter the username." || response == "Please enter the email." || response == "Invalid email format!") { //if there are erros in the validations


                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else { //if not

                Toastify({
                    text: "Profile Successfully Updated!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

                document.getElementById("name_viewer").innerHTML = JSON.parse(response).full_name; //add the newly update name through json to the name viewer


            }






        }


    };


    //Gets ready to send the request
    request.open("POST", "update_profile_teacher.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}


function checkStatusTeacher() {




    setInterval(function() {




        var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
        //There are 4 ready states and on each change of ready state this event works
        request.onreadystatechange = function() {

            if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

                var response = request.responseText;

                if (response == "Blocked" || response == "Signed out") {

                    location.reload();


                }






            }



        };

        //Gets ready to send the request
        request.open("POST", "check_teacher_status.php", true);
        //Sends the request with the parameters in the form
        request.send();





    }, 1000);





}


function goToAddLessonNotes() {

    window.location = "add-lesson-notes";

}

function goToTeacher() {


    window.location = "teacher";


}

function showNameOnSelectorNoteUpload() {

    var file_btn = document.getElementById("file_btn");

    var filename = $(document.getElementById("file_chooser")).val().replace(/.*(\/|\\)/, '');








    if (filename == "") {





        file_btn.innerHTML = "Select File";

    } else {


        if (filename.length <= 17) {

            file_btn.innerHTML = filename;

        } else {



            file_btn.innerHTML = filename.substr(0, 22) + "...";;


        }

    }



}


function addLessonNote() {


    var title = document.getElementById("title");
    var file_chooser = document.getElementById("file_chooser");


    var form = new FormData();
    //Appends the data to the form
    form.append("title", title.value);
    form.append("file_chooser", file_chooser.files[0]);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText; //gets the response text


            if (response == "success") { //if the reponse text is "success"

                Toastify({
                    text: "Lesson note successfully added!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

                loadLessonNotes();

                document.getElementById("file_chooser").value = "";
                document.getElementById("file_btn").innerHTML = "Select File";
                document.getElementById("title").value = "";

            } else {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();



            }











        }


    };


    //Gets ready to send the request
    request.open("POST", "upload_lesson_note.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}



function loadLessonNotes() {


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("lecture_note_load_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_lesson_notes.php", true);
    //Sends the request
    request.send();




}

function goToAddAssignments() {


    window.location = "add-assignments";


}


function addAssignment() {




    var title = document.getElementById("title");
    var start_date = document.getElementById("start_date");
    var end_date = document.getElementById("end_date");
    var file_chooser = document.getElementById("file_chooser");


    var form = new FormData();
    //Appends the data to the form
    form.append("title", title.value);
    form.append("start_date", start_date.value);
    form.append("end_date", end_date.value);
    form.append("file_chooser", file_chooser.files[0]);

    //Ajax Object to send the request asynchronously
    var request = new XMLHttpRequest();

    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {



        //Checks if the ready state is 4 since it is the response ready state
        if (request.readyState == 4) {

            var response = request.responseText; //gets the response text


            if (response == "success") { //if the reponse text is "success"

                loadAssignments();

                Toastify({
                    text: "Assignment successfully added!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();

                loadLessonNotes();

                document.getElementById("file_chooser").value = "";
                document.getElementById("file_btn").innerHTML = "Select File";
                document.getElementById("title").value = "";
                document.getElementById("start_date").value = "";
                document.getElementById("end_date").value = "";

            } else {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();



            }











        }


    };


    //Gets ready to send the request
    request.open("POST", "upload_assignment.php", true);
    //Sends the request with the parameters in the form
    request.send(form);










}

function loadAssignments() {

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("assignment_load_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_assignments.php", true);
    //Sends the request
    request.send();




}

function goToViewLessonNotes() {

    window.location = "view-lesson-notes";

}

function goToStudent() {

    window.location = "student";


}

var deadlineChangeModal;

function openDeadlineUpdateModal(assignmentId) {

    document.getElementById("assignment_deadline_update").value = "";



    var form = new FormData();
    form.append("assignmentId", assignmentId);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;





            if (response == "Invalid assignment!") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {



                var jsonDetails = JSON.parse(response);

                document.getElementById("assignmentDeadlineChangeModalLabel").innerHTML = "Change Assignment End Date of \"" + jsonDetails.title + "\"";

                document.getElementById("updateDeadlineButton").onclick = function() {


                    changeAssDeadline(jsonDetails.id);



                };

                var changeAssignmentDeadlineModal = document.getElementById("changeAssignmentDeadlineModal");
                deadlineChangeModal = new bootstrap.Modal(changeAssignmentDeadlineModal);
                deadlineChangeModal.show();



            }




        }



    };

    //Gets ready to send the request
    request.open("POST", "get_ass_date_update_details.php", true);
    //Sends the request with the parameters in the form
    request.send(form);







}





function changeAssDeadline(assignmentId) {

    var form = new FormData();
    form.append("assignmentId", assignmentId);
    form.append("deadlineDate", document.getElementById("assignment_deadline_update").value);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;



            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {


                deadlineChangeModal.hide();

                document.getElementById("end_date" + assignmentId).innerHTML = document.getElementById("assignment_deadline_update").value;


                document.getElementById("assignment_deadline_update").value = "";




                Toastify({
                    text: "Assignment deadline successfully changed!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();



            }






        }



    };

    //Gets ready to send the request
    request.open("POST", "change_ass_deadline.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}


function deleteAssignment(assignmentId) {

    var form = new FormData();
    form.append("assignmentId", assignmentId);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;



            if (response == "Invalid assignment!") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {



                var jsonDetails = JSON.parse(response);


                swal({
                        title: "Are you sure?",
                        text: "That you want to delete the assignment \"" + jsonDetails.title + "\"?",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                        buttons: ["No", "Yes"],
                    })
                    .then((willDelete) => {
                        if (willDelete) {


                            deleteCompletelyAssignment(jsonDetails.id);






                        }
                    });






            }




        }



    };

    //Gets ready to send the request
    request.open("POST", "get_ass_date_update_details.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}


function deleteCompletelyAssignment(assignmentId) {


    var form = new FormData();
    form.append("assignmentId", assignmentId);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;



            if (response != "success") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {


                loadAssignments();



                Toastify({
                    text: "Assignment deleted successfully!",
                    className: "info",
                    style: {
                        background: "#48c78e",
                    }
                }).showToast();



            }




        }



    };

    //Gets ready to send the request
    request.open("POST", "delete_assignment.php", true);
    //Sends the request with the parameters in the form
    request.send(form);



}

function searchAssignment() {

    var form = new FormData(); //FormData object
    form.append("searchAssignment", document.getElementById("searchAssignment").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("assignment_load_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_assignment.php", true);
    //Sends the request with the parameters in the form
    request.send(form);

}

function deleteLessonNote(lessonNoteId) {



    // alert();


    var form = new FormData();
    form.append("lessonNoteId", lessonNoteId);


    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

            var response = request.responseText;



            if (response == "Invalid lesson note!") {

                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();


            } else {



                var jsonDetails = JSON.parse(response);


                swal({
                        title: "Are you sure?",
                        text: "That you want to delete the lesson note \"" + jsonDetails.title + "\"?",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                        buttons: ["No", "Yes"],
                    })
                    .then((willDelete) => {
                        if (willDelete) {


                            var form = new FormData();
                            form.append("lessonNoteId", jsonDetails.id);


                            var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
                            //There are 4 ready states and on each change of ready state this event works
                            request.onreadystatechange = function() {

                                if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

                                    var response = request.responseText;

                                    if (response != "success") {

                                        Toastify({
                                            text: response,
                                            className: "info",
                                            style: {
                                                background: "#f14668",
                                            }
                                        }).showToast();


                                    } else {


                                        loadLessonNotes();



                                        Toastify({
                                            text: "Lesson note deleted successfully!",
                                            className: "info",
                                            style: {
                                                background: "#48c78e",
                                            }
                                        }).showToast();



                                    }




                                }



                            };

                            //Gets ready to send the request
                            request.open("POST", "delete_lesson_note.php", true);
                            //Sends the request with the parameters in the form
                            request.send(form);





                        }
                    });






            }




        }



    };

    //Gets ready to send the request
    request.open("POST", "get_lesson_note_details.php", true);
    //Sends the request with the parameters in the form
    request.send(form);



}



function uploadAssignment(assignmentId) {


    var btn_txt = document.getElementById("file_btn" + assignmentId).innerHTML;


    var file_btn = document.getElementById("file_btn" + assignmentId);

    var filename = $(document.getElementById("file_chooser" + assignmentId)).val().replace(/.*(\/|\\)/, '');












    if (filename == "") {





        file_btn.innerHTML = "Upload";

    } else {


        if (filename.length <= 17) {

            file_btn.innerHTML = filename;

        } else {



            file_btn.innerHTML = filename.substr(0, 22) + "...";;


        }



        var form = new FormData();
        form.append("assignmentId", assignmentId);


        var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
        //There are 4 ready states and on each change of ready state this event works
        request.onreadystatechange = function() {

            if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state

                var response = request.responseText;



                if (response == "Invalid assignment!") {

                    Toastify({
                        text: response,
                        className: "info",
                        style: {
                            background: "#f14668",
                        }
                    }).showToast();


                } else {



                    var jsonDetails = JSON.parse(response);




                    swal({
                            title: "Are you sure?",
                            text: "That you want to upload \"" + filename + "\" as the assignment \"" + jsonDetails.title + "\"?",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                            buttons: ["No", "Yes"],
                        })
                        .then((willDelete) => {
                            if (willDelete) {


                                var file_chooser = document.getElementById("file_chooser" + assignmentId);


                                var form = new FormData();
                                //Appends the data to the form
                                form.append("assignmentId", assignmentId);
                                form.append("file_chooser", file_chooser.files[0]);

                                //Ajax Object to send the request asynchronously
                                var request = new XMLHttpRequest();

                                //There are 4 ready states and on each change of ready state this event works
                                request.onreadystatechange = function() {



                                    //Checks if the ready state is 4 since it is the response ready state
                                    if (request.readyState == 4) {

                                        var response = request.responseText; //gets the response text


                                        if (response == "success") { //if the reponse text is "success"


                                            Toastify({
                                                text: "Assignment successfully uploaded!",
                                                className: "info",
                                                style: {
                                                    background: "#48c78e",
                                                }
                                            }).showToast();


                                            document.getElementById("file_btn" + assignmentId).innerHTML = "Re-Upload";
                                            document.getElementById("file_chooser").value = "";



                                        } else {

                                            Toastify({
                                                text: response,
                                                className: "info",
                                                style: {
                                                    background: "#f14668",
                                                }
                                            }).showToast();



                                        }











                                    }


                                };


                                //Gets ready to send the request
                                request.open("POST", "upload_assignment_student.php", true);
                                //Sends the request with the parameters in the form
                                request.send(form);










                            } else {


                                document.getElementById("file_chooser" + assignmentId).value = "";
                                document.getElementById("file_btn" + assignmentId).innerHTML = btn_txt;


                            }
                        });






                }




            }



        };

        //Gets ready to send the request
        request.open("POST", "get_ass_upload_details_student.php", true);
        //Sends the request with the parameters in the form
        request.send(form);








    }




}

function goToAssignments() {

    window.location = "assignments";


}

function goToAddAssignmentMarksTeacher() {


    window.location = "add-assignment-marks-teacher";


}

var addMarkModal;

function markAssignment(assignment_has_student_id) {


    document.getElementById("assignment_mark").value = "";


    var form = new FormData(); //FormData object
    form.append("assignment_has_student_id", assignment_has_student_id);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;

            // alert(response);

            if (response == "Invalid assignment!") {


                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();




            } else {

                var detailJson = JSON.parse(response);

                document.getElementById("assignment_marks_upload").innerHTML = "Add Marks Of " + detailJson.first_name + " " + detailJson.last_name + " for assignment \"" + detailJson.title + "\".";

                var add_ass_marks_model = document.getElementById("add_ass_marks_model");
                addMarkModal = new bootstrap.Modal(add_ass_marks_model);
                addMarkModal.show();

                document.getElementById("addMarkButton").onclick = function() {

                    swal({
                            title: "Are you sure that you want to upload the marks?",
                            text: "You can't edit the marks after a single upload.",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                            buttons: ["No", "Yes"],
                        })
                        .then((willDelete) => {
                            if (willDelete) {


                                var assignment_mark = document.getElementById("assignment_mark");

                                var form = new FormData(); //FormData object
                                form.append("assignment_has_student_id", assignment_has_student_id);
                                form.append("assignment_mark", assignment_mark.value);
                                form.append("assignment_has_student_id", detailJson.assignment_has_student_id);

                                var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
                                //There are 4 ready states and on each change of ready state this event works
                                request.onreadystatechange = function() {

                                    if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


                                        var response = request.responseText;

                                        if (response == "success") { //if the reponse text is "success"

                                            loadAssignmentsTeachers();
                                            document.getElementById("assignment_mark").value = "";

                                            addMarkModal.hide();



                                            Toastify({
                                                text: "Assignment mark successfully uploaded!",
                                                className: "info",
                                                style: {
                                                    background: "#48c78e",
                                                }
                                            }).showToast();




                                        } else {

                                            Toastify({
                                                text: response,
                                                className: "info",
                                                style: {
                                                    background: "#f14668",
                                                }
                                            }).showToast();



                                        }





                                    }



                                };

                                //Gets ready to send the request
                                request.open("POST", "add_ass_mark_teacher.php", true);
                                //Sends the request with the parameters in the form
                                request.send(form);








                            }
                        });





                };

            }




        }



    };

    //Gets ready to send the request
    request.open("POST", "get_ass_has_student_data.php", true);
    //Sends the request with the parameters in the form
    request.send(form);

}

function loadAssignmentsTeachers() {




    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("assignment_load_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_assignment_marks_teacher.php", true);
    //Sends the request
    request.send();



}

function goToMarkManagement() {


    window.location = "mark-management";


}

var releaseMarkModal;

function releaseAssignmentMark(assignment_has_student_id) {

    document.getElementById("assignment_mark").value = "";


    var form = new FormData(); //FormData object
    form.append("assignment_has_student_id", assignment_has_student_id);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            var response = request.responseText;

            // alert(response);

            if (response == "Invalid assignment!") {


                Toastify({
                    text: response,
                    className: "info",
                    style: {
                        background: "#f14668",
                    }
                }).showToast();




            } else {

                var detailJson = JSON.parse(response);

                document.getElementById("assignment_mark").value = detailJson.mark;

                document.getElementById("assignment_marks_upload").innerHTML = "Release Marks Of " + detailJson.first_name + " " + detailJson.last_name + " for assignment \"" + detailJson.title + "\".";

                var add_ass_marks_model = document.getElementById("add_ass_marks_model");
                releaseMarkModal = new bootstrap.Modal(add_ass_marks_model);
                releaseMarkModal.show();

                document.getElementById("addMarkButton").onclick = function() {

                    swal({
                            title: "Are you sure that you want to release the marks?",
                            text: "You can't edit the marks after a single release to student.",
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                            buttons: ["No", "Yes"],
                        })
                        .then((willDelete) => {
                            if (willDelete) {


                                var assignment_mark = document.getElementById("assignment_mark");

                                var form = new FormData(); //FormData object
                                form.append("assignment_has_student_id", assignment_has_student_id);
                                form.append("assignment_mark", assignment_mark.value);
                                form.append("assignment_has_student_id", detailJson.assignment_has_student_id);

                                var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
                                //There are 4 ready states and on each change of ready state this event works
                                request.onreadystatechange = function() {

                                    if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


                                        var response = request.responseText;

                                        if (response == "success") { //if the reponse text is "success"

                                            loadAssignmentsAcOfficers();
                                            document.getElementById("assignment_mark").value = "";

                                            releaseMarkModal.hide();



                                            Toastify({
                                                text: "Assignment mark successfully released to the student!",
                                                className: "info",
                                                style: {
                                                    background: "#48c78e",
                                                }
                                            }).showToast();




                                        } else {

                                            Toastify({
                                                text: response,
                                                className: "info",
                                                style: {
                                                    background: "#f14668",
                                                }
                                            }).showToast();



                                        }





                                    }



                                };

                                //Gets ready to send the request
                                request.open("POST", "release_ass_mark.php", true);
                                //Sends the request with the parameters in the form
                                request.send(form);








                            }
                        });





                };

            }




        }



    };

    //Gets ready to send the request
    request.open("POST", "get_ass_has_student_data_release.php", true);
    //Sends the request with the parameters in the form
    request.send(form);


}

function loadAssignmentsAcOfficers() {




    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("assignment_load_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "load_assignment_marks_ac_officer.php", true);
    //Sends the request
    request.send();



}

function goToCheckResults() {


    window.location = "check-results"


}

function searchLessonNote() {

    var form = new FormData(); //FormData object
    form.append("searchLessonNote", document.getElementById("searchLessonNote").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("lecture_note_load_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_lesson_notes.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}

function searchResults() {


    var form = new FormData(); //FormData object
    form.append("searchResults", document.getElementById("searchResults").value);

    var request = new XMLHttpRequest(); //Ajax Object to send the request asynchronously
    //There are 4 ready states and on each change of ready state this event works
    request.onreadystatechange = function() {

        if (request.readyState == 4) { //Checks if the ready state is 4 since it is the response ready state


            document.getElementById("results_load_area").innerHTML = request.responseText;






        }



    };

    //Gets ready to send the request
    request.open("POST", "search_results.php", true);
    //Sends the request with the parameters in the form
    request.send(form);




}