<?php
session_start();
require "connection.php";
if(isset($_SESSION["teacher"])){

    $teacher_details = $_SESSION["teacher"];

    $assignmentId=addslashes($_POST["assignmentId"]);
    $deadlineDate=addslashes($_POST["deadlineDate"]);

    $date=new DateTime();
    $timeZone= new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time=$date->format("Y-m-d H:i:s");

    $current_year=$date->format("Y");

    $current_date=$date->format("Y-m-d");

    if(empty($deadlineDate)){


        echo "Please select the deadline.";


    }  else{

  
    



    $assignment_rs=connect::executer("SELECT * FROM `assignment` WHERE `id`='".$assignmentId."' AND `subject_has_grade_id`='". $teacher_details["subject_has_grade_id"]."' AND `status_id`='1';");

    if($assignment_rs->num_rows==1){

        $assignment_fetch=$assignment_rs->fetch_assoc();

        if(explode("-",$deadlineDate)<explode("-", $assignment_fetch["start_date"])){


            echo "The deadline can't be before the starting date.";


        }else{

            connect::executer("UPDATE `assignment` SET `end_date`='".$deadlineDate."' WHERE `id`='".$assignmentId."';");

            echo "success";


        }

      

    
          


    }else{

       echo "Invalid assignment!";


    }

}

}




?>