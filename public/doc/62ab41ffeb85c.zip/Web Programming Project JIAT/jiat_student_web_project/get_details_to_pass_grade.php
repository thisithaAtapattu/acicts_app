<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["admin"])) { //checkes if the session is set to show the content

    $admin_details = $_SESSION["admin"]; //gets the admin details from the session

    //addslashes function was used in case if the values has quotes
    $studentId=addslashes($_POST["studentId"]);


    $student_rs=connect::executer("SELECT *  FROM `student` INNER JOIN `student_grading` ON `student`.`student_grading_id`=`student_grading`.`id` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` WHERE `student`.`id`='".$studentId."';");

   $studentJson;

    if($student_rs->num_rows==1){

        $student_fetch=$student_rs->fetch_assoc();

        if($student_fetch["name"]!=13){

        $studentJson["student_name"]=$student_fetch["first_name"]." ".$student_fetch["last_name"];

        $studentJson["grade"]=$student_fetch["name"];

        $studentJson["graded_date_time"]=$student_fetch["graded_date_time"];

        $studentJson["new_grade"]=$student_fetch["name"]+1;

        echo json_encode($studentJson);

    }else{

        echo "Grade 13 students can't be passed further.";

    }

    }else{

       echo "Student not found!";

    }
   


}
?>