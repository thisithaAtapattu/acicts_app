<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["student"])) { //checkes if the session is set to show the content

    $student_details = $_SESSION["student"]; //gets the student details from the session


    $date = new DateTime();
    $timeZone = new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time = $date->format("Y-m-d H:i:s");

    $current_year = $date->format("Y");

    $current_date = $date->format("Y-m-d");


?>
    <!DOCTYPE html>
    <html>

    <head>


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ministry of Education</title>
        <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
        <link rel="stylesheet" href="bootstrap.css" />

        <link rel="stylesheet" href="style.css" /><!-- My Css File -->
        <link rel="stylesheet" href="font/bootstrap-icons.css">

        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

        <link rel="stylesheet" href="bulma.css" />


    </head>

    <body>



        <div class="container-fluid ">

            <div class="row">

                <div class="col-12">

                    <div class="row">



                        <div class="col-md-4 pb-5" style="background-color: hsl(0, 0%, 96%)	;">

                            <!-- Profile section with logout -->

                            <div class="row ">









                                <div class="col-12 d-flex flex-column align-items-center mt-2">





                                    <div class="row ">

                                        <?php

                                        $profile_pic_result = connect::executer("SELECT CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img` FROM `student_profile_pic` INNER JOIN `image` ON `student_profile_pic`.`image_id`=`image`.`id` INNER JOIN`image_type` ON  `image`.`image_type_id`=`image_type`.`id` WHERE `student_profile_pic`.`student_id`='" . addslashes($student_details["id"]) . "';"); //searches for the profile picture in the database

                                        if ($profile_pic_result->num_rows == 1) { //if a profile picture exsists


                                            $profile_pic_fetch = $profile_pic_result->fetch_assoc(); //covert's the profile picture result set to an associative array

                                        ?>

                                            <img src="<?php echo "profiles/" . $profile_pic_fetch["profile_img"]; //shows the profile picture 
                                                        ?>" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php

                                        } else { //if a profile picture does not exsist
                                        ?>

                                            <!-- Shows the default profile picture -->
                                            <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php



                                        }
                                        ?>

                                    </div>




                                </div>













                                <div class="col-6 offset-3 mt-2">

                                    <div class="row">

                                        <input type="file" id="profile_pic" class="d-none" />




                                    </div>


                                </div>






                            </div>



                            <div class="row">


                                <div class="col-12 text-center">


                                    <div class="row">

                                        <p class=" fw-bold" id="name_viewer"><?php echo $student_details["first_name"] . " " . $student_details["last_name"] //display the first and last name of the user taken by the session; 
                                                                                ?></p>




                                        <div>

                                            <h6 class=" fw-bold has-text-link	" style="font-size:10px;">STUDENT</h6>


                                        </div>







                                    </div>




                                </div>


                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-5 offset-5 mt-1">


                                            <div class="row">

                                                <button class="btn btn-danger col-5" onclick="logOutStudent();">Log out</button>

                                            </div>



                                        </div>





                                    </div>



                                </div>





                            </div>

                            <!-- Profile section with logout -->


                            <hr class="col-12 bg-dark" />

                            <!-- Navigation section -->

                            <div class="row px-5">


                                <div class="col-12 set-border-dash pt-2 pb-2" onclick="goToStudent();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-circle"></i> Update Profile</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToViewLessonNotes();">


                                    <div class="row">

                                        <p class=" fw-bold   has-text-grey-lighter"><i class="bi bi-book"></i></i> View Lesson Notes</p>












                                    </div>




                                </div>






                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1">


                                    <div class="row">

                                        <p class=" fw-bold has-text-info "><i class="bi bi-newspaper"></i> Assignments</p>












                                    </div>




                                </div>












                            </div>


                            <!-- Navigation section -->




                        </div>



                        <!-- Assignments section -->

                        <div class="col-md-6 ">


                            <div class="row edu-background-dashboard ms-2">




                            </div>

                            <div class=" row mt-5">

                                <div class="offset-md-2 ">

                                    <?php

                                    $student_grading_rs = connect::executer("SELECT * FROM `student_grading` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` WHERE `student_grading`.`id`='" . $student_details["student_grading_id"] . "';");

                                    $student_grading_fetch = $student_grading_rs->fetch_assoc();




                                    $sub_has_grade_rs = connect::executer("SELECT `subject_has_grade`.`id`,`subject`.`name` FROM `subject_has_grade` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` WHERE `subject_has_grade`.`grade_id`='" . $student_grading_fetch["grade_id"] . "';");


                                    while ($sub_has_grade_fetch = $sub_has_grade_rs->fetch_assoc()) {



                                        $color_array = array("colour1" => "button is-info", "colour2" => "button is-success", "colour3" => "button is-warning", "colour4" => "button is-link", "colour5" => "button is-primary", "colour6" => "button is-danger");

                                        shuffle($color_array);


                                    ?>

                                        <p>
                                        <div class="button is-link d-grid mt-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample<?php echo $sub_has_grade_fetch["id"]; ?>" aria-expanded="false" aria-controls="collapseExample<?php echo $sub_has_grade_fetch["id"]; ?>">
                                            <?php echo $sub_has_grade_fetch["name"]; ?>
                                        </div>
                                        </p>
                                        <div class="collapse mt-2 overflow-scroll" id="collapseExample<?php echo $sub_has_grade_fetch["id"]; ?>">
                                            <div class="">
                                                <table class="table overflow-scroll">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">Title</th>
                                                            <th scope="col">Download Assignment</th>
                                                            <th scope="col">Upload Assignment</th>
                                                            <th scope="col"></th>
                                                            <th scope="col">Start Date</th>
                                                            <th scope="col">End Date</th>
                                                            <th scope="col" class="text-center">Marks</th>
                                                            <th scope="col" class="text-center"></th>


                                                        </tr>
                                                    </thead>
                                                    <tbody id="assignment_load_area">

                                                        <?php



                                                        $assignment_rs = connect::executer("SELECT `assignment`.`id` AS `assignment_id`,`assignment`.`title`,`assignment`.`file_name`,`assignment`.`start_date`,`assignment`.`end_date`,`subject`.`name` AS `subject_name`,`grade`.`name` AS `grade_name` FROM `assignment` INNER JOIN `subject_has_grade` ON `assignment`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` WHERE `subject_has_grade`.`id`='" . $sub_has_grade_fetch["id"] . "' AND `assignment`.`end_date` LIKE '" . $current_year . "%' AND `assignment`.`status_id`='1' ORDER BY  `assignment`.`start_date` ASC;");


                                                        while ($assignment_fetch = $assignment_rs->fetch_assoc()) {

                                                        ?>
                                                            <tr>
                                                                <td><?php echo $assignment_fetch["title"]; ?></td>
                                                                <?php
                                                                $assignment_has_student_rs = connect::executer("SELECT * FROM `assignment_has_student` WHERE `assignment_id`='" . $assignment_fetch['assignment_id'] . "' AND `student_id`='" . $student_details["id"] . "';");
                                                                if (explode("-", $current_date) <=  explode("-", $assignment_fetch["end_date"])) {
                                                                ?>

                                                                    <td><a class="button is-danger is-light" download="" href="<?php echo "doc/" . $assignment_fetch["file_name"]; ?>">Download Assignment</a></td>
                                                                <?php
                                                                } else {
                                                                ?>
                                                                    <td colspan="2" class="text-center">
                                                                        <?php

                                                                        if ($assignment_has_student_rs->num_rows == 0) {
                                                                        ?>

                                                                            <span class="badge bg-danger col-6">NOT SUBMITTED</span>
                                                                        <?php
                                                                        } else {
                                                                        ?>
                                                                            <span class="badge col-6" style="background-color: hsl(171, 100%, 41%)	;">SUBMITTED</span>

                                                                        <?php
                                                                        }
                                                                        ?>
                                                                    </td>
                                                                <?php
                                                                }

                                                                $assignment_has_student_rs = connect::executer("SELECT * FROM `assignment_has_student` WHERE `assignment_id`='" . $assignment_fetch["assignment_id"] . "' AND `student_id`='" . $student_details["id"] . "';");

                                                                // if($assignment_has_student_rs->num_rows==1||explode("-", $current_date) <=  explode("-", $assignment_fetch["end_date"])){}
                                                                ?>
                                                                <td>
                                                                    <input type="file" id="file_chooser<?php echo $assignment_fetch["assignment_id"]; ?>" class="d-none" onchange="uploadAssignment(<?php echo $assignment_fetch['assignment_id']; ?>);" />

                                                                    <?php


                                                                    if (explode("-", $current_date) <=  explode("-", $assignment_fetch["end_date"])) {
                                                                        if ($assignment_has_student_rs->num_rows == 0) {

                                                                    ?>
                                                                            <label class="button is-info is-light d-grid" for="file_chooser<?php echo $assignment_fetch["assignment_id"]; ?>" id="file_btn<?php echo $assignment_fetch["assignment_id"]; ?>">Upload</label>
                                                                        <?php
                                                                        } else {
                                                                        ?>
                                                                            <label class="button is-info is-light d-grid" for="file_chooser<?php echo $assignment_fetch["assignment_id"]; ?>" id="file_btn<?php echo $assignment_fetch["assignment_id"]; ?>">Re-Upload</label>

                                                                    <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </td>
                                                                <?php
                                                                ?>
                                                                <?php
                                                                if (explode("-", $current_date) <=  explode("-", $assignment_fetch["end_date"])) {
                                                                ?>
                                                                    <td></td>
                                                                <?php
                                                                }

                                                                ?> <td><?php echo $assignment_fetch["start_date"]; ?></td>
                                                                <td><?php echo $assignment_fetch["end_date"]; ?></td>
                                                                <td>
                                                                    <?php
                                                                    // if (explode("-", $current_date) >  explode("-", $assignment_fetch["end_date"])) {
                                                                    ?>
                                                                        <span class="badge bg-info text-dark col-12 text-white">

                                                                            <?php
                                                                            if (explode("-", $current_date) >  explode("-", $assignment_fetch["end_date"])) {
                                                                                if ($assignment_has_student_rs->num_rows == 0) {

                                                                            ?>
                                                                                    N/A <?php
                                                                                    } else {
                                                                                        $assignment_has_student_fetch = $assignment_has_student_rs->fetch_assoc();
                                                                                        $assignment_marks_result = connect::executer("SELECT * FROM `assignment_marks` WHERE `assignment_has_student_id`='" . $assignment_has_student_fetch["id"] . "' AND `status_id`='1';");

                                                                                        if ($assignment_marks_result->num_rows == 0) {
                                                                                        ?>
                                                                                        PENDING
                                                                                <?php
                                                                                        } else {

                                                                                            echo $assignment_marks_result->fetch_assoc()["mark"];
                                                                                        }
                                                                                    }
                                                                                } else {
        
                                                                                ?>
                                                                               UNDONE
                                                                            <?php


                                                                                }
                                                                            ?>

                                                                        </span>
                                                                    <?php
                                                                    // }
                                                                    ?>


                                                                    <?php
                                                                    if (explode("-", $current_date) <=  explode("-", $assignment_fetch["end_date"])) {
                                                                    ?>
                                                                <td></td>
                                                            <?php
                                                                    }

                                                            ?>


                                                            </td>




                                                            </tr>
                                                        <?php
                                                        }
                                                        ?>

                                                    </tbody>
                                                </table>

                                            </div>
                                        </div>

                                    <?php
                                    }
                                    ?>




                                </div>

                            </div>








                        </div>




                        <!-- Assignments section -->





                    </div>


                </div>




            </div>








        </div>






        <!-- Toastify JS file -->

        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script> <!-- My js file -->
        <script>
            checkStatusStudent(); //this function checks the status of the student and logs out the student if the student is blocked
        </script>
        <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script> <!-- JQuery js file -->
        <script src="jquery-3.6.0.min.js"></script> <!-- JQuery js file -->
        <script src="sweetalert.min.js"></script><!-- SweetAlert js file -->
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script><!-- Toastify JS file -->
    </body>









    </html>
<?php

} else { //if the session is not set


?>
    <script>
        window.location = "student-login";
    </script>
<?php


}

?>