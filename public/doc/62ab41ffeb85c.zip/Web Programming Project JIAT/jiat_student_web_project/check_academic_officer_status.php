<?php
session_start();
require "connection.php";
if(isset($_SESSION["academic_officer"])){





    if(connect::executer("SELECT * FROM `academic_officer` WHERE `id`='".$_SESSION["academic_officer"]["id"]."' AND `status_id`='2';")->num_rows==1){
    
    
       

        unset($_SESSION["academic_officer"]);

        echo "Blocked";

    
    }

}else{

echo "Signed out";


}



?>