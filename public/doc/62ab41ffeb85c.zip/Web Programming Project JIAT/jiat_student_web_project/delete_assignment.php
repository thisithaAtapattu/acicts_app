<?php
session_start();
require "connection.php";
if(isset($_SESSION["teacher"])){

    $teacher_details = $_SESSION["teacher"];

    $assignmentId=addslashes($_POST["assignmentId"]);

    $assignment_rs=connect::executer("SELECT * FROM `assignment` WHERE `id`='".$assignmentId."' AND `subject_has_grade_id`='". $teacher_details["subject_has_grade_id"]."' AND `status_id`='1';");

    if($assignment_rs->num_rows==1){

      


     connect::executer("UPDATE `assignment` SET `status_id`='2' WHERE `id`='".$assignmentId."';");
     unlink("doc/".$assignment_rs->fetch_assoc()["file_name"]);
       
     echo "success";
          


    }else{

       echo "Invalid assignment!";


    }



}




?>