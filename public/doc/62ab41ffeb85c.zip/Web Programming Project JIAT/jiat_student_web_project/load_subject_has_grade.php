<?php
session_start();
require "connection.php";
if (isset($_SESSION["admin"])) {


    $subject_has_grade_rs = connect::executer("SELECT `subject`.`name` AS `subject_name`,`grade`.`name` AS `grade_name` FROM `subject_has_grade` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` ORDER BY `grade`.`name` ASC;");

    while ($subject_has_grade_fetch = $subject_has_grade_rs->fetch_assoc()) {
?>

        <tr>
            <td class="col"><?php echo "Grade " . $subject_has_grade_fetch["grade_name"]; ?></td>
            <td><?php echo $subject_has_grade_fetch["subject_name"]; ?></td>
        </tr>
<?php
    }
}
?>