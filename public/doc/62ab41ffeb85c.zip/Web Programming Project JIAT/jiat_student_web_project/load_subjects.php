<?php
session_start();
require "connection.php";
if (isset($_SESSION["admin"])) {



    $subject_rs = connect::executer("SELECT * FROM `subject`;");

    for ($subject_count = 1; $subject_count <= $subject_rs->num_rows; $subject_count++) {
?>

        <tr>
            <td class="col"><?php echo $subject_count; ?></td>
            <td><?php echo $subject_rs->fetch_assoc()["name"]; ?></td>
        </tr>
<?php
    }
}
?>