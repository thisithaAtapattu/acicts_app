<?php
session_start();
require "connection.php";

if(isset($_SESSION["student"])){

  $date = new DateTime();
    $timeZone = new DateTimeZone("Asia/Colombo");
  $date->setTimezone($timeZone);
  $current_date_time = $date->format("Y-m-d H:i:s");

  $current_year = $date->format("Y");

  $current_date = $date->format("Y-m-d");

  $student_details = $_SESSION["student"];

  $assignmentId=addslashes($_POST["assignmentId"]);

  $student_grading_rs = connect::executer("SELECT * FROM `student_grading` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` WHERE `student_grading`.`id`='" . $student_details["student_grading_id"] . "';");

  $student_grading_fetch = $student_grading_rs->fetch_assoc();

  $assignment_rs=connect::executer("SELECT * FROM `assignment`  WHERE `assignment`.`id`='".$assignmentId."' AND `status_id`='1' AND `assignment`.`subject_has_grade_id` IN (SELECT `subject_has_grade`.`id` FROM `subject_has_grade` WHERE `grade_id`='".  $student_grading_fetch["grade_id"]."');");

  $assignment_fetch=$assignment_rs->fetch_assoc();
  
  

  if (explode("-", $current_date) <=  explode("-", $assignment_fetch["end_date"])) {


    if($assignment_rs->num_rows==1){

  
     
        if(isset($_FILES["file_chooser"])){
       
      
            $file=$_FILES["file_chooser"];
        
            $file_name=$file["name"];
        
            $exploded_file_name=explode(".",$file_name);
        
            if($exploded_file_name[sizeof( $exploded_file_name)-1]=="pdf"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="docx"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="zip"){
     
     
              $file_name_upload=uniqid().".".$exploded_file_name[sizeof( $exploded_file_name)-1];
     
              move_uploaded_file($file["tmp_name"],"doc/".$file_name_upload);
     
     
             $assignment_has_student_rs=connect::executer("SELECT * FROM `assignment_has_student` WHERE `assignment_id`='".$assignmentId."' AND `student_id`='".$student_details["id"]."';");
              
              if($assignment_has_student_rs->num_rows==0){

                 connect::executer("INSERT INTO `assignment_has_student`(`assignment_id`,`student_id`,`file_name`,`date_time`) VALUES ('".$assignmentId."','".$student_details["id"]."','".$file_name_upload."','".$current_date_time."');");

                echo "success";

              }else  if($assignment_has_student_rs->num_rows==1){

               $assignment_has_student_fetch= $assignment_has_student_rs->fetch_assoc();

               connect::executer("UPDATE `assignment_has_student` SET `file_name`='".$file_name_upload."',`date_time`='".$current_date_time."' WHERE `id`='".$assignment_has_student_fetch["id"]."';");
                unlink("doc/".$assignment_has_student_fetch["file_name"]);

               echo "success";

             }


     
     
     
            }else{
     
     
                echo "The file must be a pdf file, zip file or a docx file.";
              
     
     
            }
     
         }else{
     
           echo "Please select a file.";
         
     
         }
            
    
    
      }else{
    
         echo "Invalid assignment!";
    
      }
    
    


  }else{

       echo "The deadline of this assignment has already passed.";


  }
  

}


?>