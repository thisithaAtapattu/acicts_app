<?php
session_start();
require "connection.php";
use PHPMailer\PHPMailer\PHPMailer; 
if(isset($_SESSION["academic_officer"])){//checks if the academic_officer is signed in

  $academic_officer_details = $_SESSION["academic_officer"];

  $first_name=addslashes($_POST["first_name"]);
  $last_name=addslashes($_POST["last_name"]);
  $email=addslashes($_POST["email"]);
  $username=addslashes($_POST["username"]);
  $password=addslashes($_POST["password"]);
  $confirm_password=addslashes($_POST["confirm_password"]);
  $grade=addslashes($_POST["grade"]);

  $date=new DateTime();
  $timeZone= new DateTimeZone("Asia/Colombo");
  $date->setTimezone($timeZone);
  $current_date_time=$date->format("Y-m-d H:i:s");


    $root = $_SERVER['WEB_ROOT'] = str_replace($_SERVER['SCRIPT_NAME'],'',$_SERVER['SCRIPT_FILENAME']);

    $host = $_SERVER['HTTP_HOST'];
    $protocol=$_SERVER['PROTOCOL'] = isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS']) ? 'https' : 'http';

    $actual_link = $protocol.'://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);

  if($first_name==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$first_name))) == 0){

    echo "Please enter the first name.";
 
 
 }else if($last_name==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$last_name))) == 0){
 
     echo "Please enter the last name.";
  
  
 }else if($email==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$email))) == 0){
 
    echo "Please enter the email.";
 
 
}else if (!filter_var($email,FILTER_VALIDATE_EMAIL)){//if the email is in the correct format


    echo "Invalid email format!";


}else{

    $student_rs=connect::executer("SELECT * FROM `student` WHERE `email`='".$email."';");
   



    if($student_rs->num_rows==1){

        echo "A student with this email already exists.";



    }else{

        $student_rs_username=connect::executer("SELECT * FROM `student` WHERE `username`='".$username."';");


        if($student_rs_username->num_rows==0){

           
    
        if($username==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$username))) == 0){

            echo "Please enter the username.";

        }else{

            if($password==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$password))) == 0){

                echo "Please enter the password.";
                
            }else if($confirm_password==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$confirm_password))) == 0){
        
                echo "Please confirm the password.";
                
            }else if($password!=$confirm_password){
        
                echo "The passwords does not match.";
        
            }else if(empty($grade)){
        
                echo "Please select the grade.";
        
            }else{
                if($password!=$username){
            
        
               $grade_rs=connect::executer("SELECT * FROM `grade` WHERE `id`='".$grade."';");

               $verification_code=uniqid();
               $login_link=$actual_link."/student-login?login_status=verification";
               $login_link_2=$actual_link."/student-login";
        
               if($grade_rs->num_rows==1){
        
        
        
                
        require 'Exception.php'; 
        require 'PHPMailer.php'; 
        require 'SMTP.php'; 
         
        $mail = new PHPMailer; 
        $mail->IsSMTP();
        $mail->Host = 'smtp.gmail.com'; 
        $mail->SMTPAuth = true; 
        $mail->Username = 'thisitha2008@gmail.com'; 
        $mail->Password = 'zdtcckaaqqagafrn';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('futureharp12619@gmail.com', 'Ministry of Education'); 
        $mail->addReplyTo('futureharp12619@gmail.com', 'Ministry of Education'); 
        $mail->addAddress($email); 
        $mail->isHTML(true); 
        $mail->Subject = 'Ministry of Education Student Invitation'; 
        $bodyContent = '<div style="height:auto;padding:50px 50px 50px 50px;background-color:#edeff1"> <br>
        <center><img src="https://upload.wikimedia.org/wikipedia/commons/5/5f/Emblem_of_Sri_Lanka.svg" style="width:50px;"/><h1>Ministry of Education </h1></center><br>       <center>  <div style="width:500px;height:auto;margin-top:0px;padding-bottom:80px;font-size:14px;background-color:white;text-align:center">
        <br><br><center>    <h2>You were invited as a student.</h2><br>
        <br>
        <span style="">Username : </span>
        <span >'.$username.'</span>
        <br>
        <span style="">Password : </span>
        <span >'.$password.'</span>
        <br>
        <span style="">Verification Code : </span>
        <span >'.$verification_code.'</span>
        <br>
        <br>
        <span style="">First log in link : </span>
        <a href="'.$login_link.'" style="text-align:center;color:hsl(217, 71%, 53%)	;" >
        Click to Log In</a>
        <br>
        <span style="">Link after first log in : </span>
<a href="'.$login_link_2.'" style="text-align:center;color:hsl(217, 71%, 53%)	;" >
Click to Log In</a>
        </center>
        </div>
        </center>
        </div>'; 
        $mail->Body    = $bodyContent; 
        
        
        if($mail->send()) { 


            connect::executer("INSERT INTO `student_grading`(`grade_id`,`graded_date_time`) VALUES ('".$grade."','".$current_date_time."');");
        
            $student_grading_id=connect::$dbms->insert_id;
    
            connect::executer("INSERT INTO `student`(`first_name`,`last_name`,`email`,`username`,`password`,`student_grading_id`) VALUES ('".$first_name."','".$last_name."','".$email."','".$username."','".$password."','".$student_grading_id."');");
    
            $student_id=connect::$dbms->insert_id;
    
           
    
           
    
            connect::executer("INSERT INTO `student_account_access_code`(`student_id`,`code`) VALUES ('".$student_id."','".addslashes($verification_code)."');");
            
            echo "success"; 
        }else{
            echo 'Student registration was not successfull due to an e-mail error.'; 


        }
        
        
               }else{
        
                echo "Invalid grade!";
        
               }

            }else{
                
                echo "The password can't be same as the username.";


}
        
            }
        

        }
       

    
    
    }else if($student_rs_username->num_rows==1){

      echo "A student with this username already exists.";

        
    }

  


    }



}
    

}
