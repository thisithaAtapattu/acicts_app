<?php
session_start();
require "connection.php";
if(isset($_SESSION["teacher"])){

    $teacher_details = $_SESSION["teacher"];

    $assignmentId=addslashes($_POST["assignmentId"]);

    $assignment_rs=connect::executer("SELECT * FROM `assignment` WHERE `id`='".$assignmentId."' AND `subject_has_grade_id`='". $teacher_details["subject_has_grade_id"]."' AND `status_id`='1';");

    if($assignment_rs->num_rows==1){

        $assignment_fetch=$assignment_rs->fetch_assoc();

        $assignment_data;

        $assignment_data["id"]= $assignment_fetch["id"];
        $assignment_data["title"]=$assignment_fetch["title"];

        echo json_encode($assignment_data);



    }else{

       echo "Invalid assignment!";


    }



}




?>