<?php


 

   class Index{


     
       


            
    public static function getLink(){

               //    Web Root
    //    Usage: include("$root/includes/something.inc.php");
    $root = $_SERVER['WEB_ROOT'] = str_replace($_SERVER['SCRIPT_NAME'],'',$_SERVER['SCRIPT_FILENAME']);

    //    Host & Protocol
    //    Usage: $url = "$protocol://$host/images/something.jpg";
        $host = $_SERVER['HTTP_HOST'];
        $protocol=$_SERVER['PROTOCOL'] = isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS']) ? 'https' : 'http';

        

   $actual_link = $protocol.'://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
   $newVerificationlink=$actual_link;




        return  $newVerificationlink;






    }








   }



?>