<?php
session_start();
require "connection.php";
if(isset($_SESSION["academic_officer"])){

  $academic_officer_details = $_SESSION["academic_officer"];

  $assignment_mark=addslashes($_POST["assignment_mark"]);

  

  $assignment_has_student_id=addslashes($_POST["assignment_has_student_id"]);
   

  if($assignment_mark==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$assignment_mark))) == 0){

      echo "Please enter the assignment mark.";


  }else if($assignment_mark>100){

      echo "The assignment mark can't be more than 100.";

  }else if($assignment_mark<1){

    echo "The assignment mark can't less than 0.";

}else{

    $date = new DateTime();
    $timeZone = new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time = $date->format("Y-m-d H:i:s");

    $current_year = $date->format("Y");

    $current_date = $date->format("Y-m-d");

    $assignment_rs = connect::executer("SELECT `assignment_has_student`.`id` AS `assignment_has_student_id`,`assignment`.`title`,`assignment`.`file_name` AS `assignment_file_name`,`assignment`.`start_date`,`assignment`.`end_date`,`assignment_has_student`.`file_name` AS `student_file_name`,`student`.`first_name`,`student`.`last_name`,`subject`.`name` AS `subject_name`, `grade`.`name` AS `grade_name`,`student`.`email`,`assignment_marks`.`mark` FROM `assignment_has_student` INNER JOIN `assignment` ON `assignment_has_student`.`assignment_id`=`assignment`.`id` INNER JOIN `student` ON `assignment_has_student`.`student_id`=`student`.`id` INNER JOIN `subject_has_grade` ON `assignment`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` LEFT JOIN `assignment_marks` ON `assignment_marks`.`assignment_has_student_id`=`assignment_has_student`.`id` WHERE   `assignment`.`end_date`<'".$current_date."' AND `assignment_has_student`.`id`='".  $assignment_has_student_id."' AND `assignment_marks`.`status_id`='2' ORDER BY `assignment`.`start_date` DESC;");

    if($assignment_rs->num_rows==1){

        $assignment_fetch=$assignment_rs->fetch_assoc();

        if($assignment_fetch["mark"]!=""&&$assignment_fetch["mark"]!=null){



              connect::executer("UPDATE `assignment_marks` SET `mark`='".$assignment_mark."',`status_id`='1' WHERE `assignment_has_student_id`='".$assignment_has_student_id."';");



             echo "success";
              
         


        }else{

            echo "Invalid assignment!";


        }

       



    }else{

       echo "Invalid assignment!";


    }

  }

}







?>