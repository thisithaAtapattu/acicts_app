<?php
session_start();
require "connection.php";
if(isset($_SESSION["student"])){


    $assignmentId=addslashes($_POST["assignmentId"]);

    $date = new DateTime();
    $timeZone = new DateTimeZone("Asia/Colombo");
  $date->setTimezone($timeZone);
  $current_date_time = $date->format("Y-m-d H:i:s");

  $current_year = $date->format("Y");

  $current_date = $date->format("Y-m-d");

  $student_details = $_SESSION["student"];



  $student_grading_rs = connect::executer("SELECT * FROM `student_grading` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` WHERE `student_grading`.`id`='" . $student_details["student_grading_id"] . "';");

  $student_grading_fetch = $student_grading_rs->fetch_assoc();

  $assignment_rs=connect::executer("SELECT * FROM `assignment`  WHERE `assignment`.`id`='".$assignmentId."' AND `status_id`='1' AND `assignment`.`subject_has_grade_id` IN (SELECT `subject_has_grade`.`id` FROM `subject_has_grade` WHERE `grade_id`='".  $student_grading_fetch["grade_id"]."');");


    if($assignment_rs->num_rows==1){
        $assignment_fetch=$assignment_rs->fetch_assoc();

        $assignment_data;

        $assignment_data["id"]= $assignment_fetch["id"];
        $assignment_data["title"]=$assignment_fetch["title"];

        echo json_encode($assignment_data);



    }else{

       echo "Invalid assignment!";


    }



}




?>