<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


$first_name=$_POST["first_name"];

if(isset($_SESSION["admin"])){//checks if the admin is singed in

    $admin_details = $_SESSION["admin"];

    //assigned variables to the parameters 
    $first_name=addslashes($_POST["first_name"]);
    $last_name=addslashes($_POST["last_name"]);
    $email=addslashes($_POST["email"]);
    $username=addslashes($_POST["username"]);
    $password=addslashes($_POST["password"]);
    $confirm_password=addslashes($_POST["confirm_password"]);

    if($first_name==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$first_name))) == 0){

        echo "Please enter the first name.";
     
     
     }else if($last_name==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$last_name))) == 0){
     
         echo "Please enter the last name.";
      
      
     }else if($email==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$email))) == 0){
     
        echo "Please enter the email.";
     
     
    }else if (!filter_var($email,FILTER_VALIDATE_EMAIL)){//if the email is in the correct format


        echo "Invalid email format!";


    }else{

        
        $result_set=connect::executer("SELECT * FROM `admin` WHERE `email`='".$email."';");
        


    if($result_set->num_rows==1){

            echo "An admin with this email already exists.";
      

    }else{

        


        if($username==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$username))) == 0){
     
            echo "Please enter the username.";
         
         
        }else {

            $rs_username=connect::executer("SELECT * FROM `admin` WHERE `username`='".$username."';");

             if($rs_username->num_rows==0){


               

                if($password==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$password))) == 0){
         
                    echo "Please enter the password.";
                 
                 
                }else if($confirm_password==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$confirm_password))) == 0){
                 
                    echo "Please confirm the password.";
                 
                 
                }else if($password!=$confirm_password){
                 
                    echo "The passwords does not match.";
                 
                 
                }else{

                    if($password!=$username){

                        connect::executer("INSERT INTO `admin`(`first_name`,`last_name`,`username`,`email`,`password`) VALUES ('".$first_name."','".$last_name."','".$username."','".$email."','".$password."');");
        
                  
                        echo "success";


                    }else{

                       echo "The password can't be same as the username.";


                    }
        
        
                    
        
        
                }
        
        
            }else if($rs_username->num_rows==1){


                echo "An admin with this username already exists.";
                

            }




        } 

     } 


    }



   
}

?>