<?php
session_start();
require "connection.php";
if(isset($_SESSION["admin"])){

    $subject_name=addslashes($_POST["subject_name"]);

    if($subject_name==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$subject_name))) == 0){
    
        echo "Please enter the subject name.";
    
        
    }else{

     
        $subject_rs=connect::executer("SELECT * FROM `subject` WHERE `name`='".$subject_name."';");


        if($subject_rs->num_rows==0){

           connect::executer("INSERT INTO `subject`(`name`) VALUES ('".$subject_name."');");


           echo "success";


        }else if($subject_rs->num_rows==1){


            echo "This subject already exists.";
        }


    }


}





?>