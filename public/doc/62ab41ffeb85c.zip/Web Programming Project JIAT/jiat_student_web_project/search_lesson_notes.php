<?php
session_start();
require "connection.php";
if (isset($_SESSION["teacher"])) {

    $teacher_details = $_SESSION["teacher"];

    $searchLessonNote=strtolower(addslashes($_POST["searchLessonNote"]));

    $lesson_note_rs = connect::executer("SELECT `lesson_note`.`id` AS `lesson_note_id`,`lesson_note`.`title`,`lesson_note`.`file_name`,`lesson_note`.`date_time_added`,`subject`.`name` AS `subject_name`,`grade`.`name` AS `grade_name` FROM `lesson_note` INNER JOIN `subject_has_grade` ON `lesson_note`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` WHERE `subject_has_grade`.`id`='" . $teacher_details["subject_has_grade_id"] . "'  AND  LOWER(`lesson_note`.`title`) LIKE '%".$searchLessonNote."%' ORDER BY `lesson_note`.`date_time_added` DESC;");


    while ($lesson_note_fetch = $lesson_note_rs->fetch_assoc()) {
    ?>
        <tr>


            <td><?php echo $lesson_note_fetch["title"]; ?></td>
            <td><a class="button is-danger is-light" download="" href="<?php echo "doc/" . $lesson_note_fetch["file_name"]; ?>">Download Note</a></td>
            <td><?php echo "Grade " . $lesson_note_fetch["grade_name"] . " " . $lesson_note_fetch["subject_name"]; ?></td>
            <td><?php echo $lesson_note_fetch["date_time_added"]; ?></td>
            <td><button class="btn btn-danger" onclick="deleteLessonNote(<?php echo $lesson_note_fetch['lesson_note_id']; ?>);">Delete</button></td>




        </tr>
    <?php
    }
}




?>