<?php
//The function bellow creates a new session if there's no session & uses the current session
session_start();

//Required the connection file with the database connection
require "connection.php";


//All three values taken as post since request was sent from cleint side as post
//addslashes function was used in case if the values has quotes
$username=addslashes($_POST["username"]);
$password=addslashes($_POST["password"]);
$remember=addslashes($_POST["remember"]);


//The empty function was not used here since it considers the value 0 also as empty

//If the values is empty or has only spaces this gets true
if($username==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$username))) == 0){

   echo "Please enter the username.";


}else if($password==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$password))) == 0){

    echo "Please enter the password.";
 
 
}else{


    // Search for the admin in the database
    $user_result=connect::executer("SELECT * FROM `admin` WHERE `username`='".$username."' AND `password`='".$password."' AND `status_id`='1';");


     if($user_result->num_rows==1){//if admin exsists


    $user_fetch=$user_result->fetch_assoc();//converts the result set to associative array


       

    if($remember=="true"){//if remember checkbox is checked

         
    $user_code=uniqid();//first assign $user_code variable to a newly genarated user code

    $code_result=connect::executer("SELECT * FROM `admin_code` WHERE `admin_id`='".$user_fetch["id"]."';");//Search for the admin code in the database

     if($code_result->num_rows==0){//if code not exsist



       connect::executer("INSERT INTO `admin_code`(`admin_id`,`code`) VALUES ('".$user_fetch["id"]."','".$user_code."');");//insert a new code




   



    }else if($code_result->num_rows==1) {//if code exsist

     $user_code=$code_result->fetch_assoc()["code"];//assignes the $user_code variable to the exsisting code


    }


         setcookie("remember_cookie",$user_code,time()+(60*60*24*365*1000)); //set a cookie with the unique code as the data        


    }else{//if the remember checkbox is not checked

         
        setcookie("remember_cookie","",time());

     
    }

    $_SESSION["admin"]=$user_fetch;//assigns user details to the session named admin

       echo "success";//if logging in success
       

     }else{//if user not found

          echo "Account not found!";


     }




}
 











?>