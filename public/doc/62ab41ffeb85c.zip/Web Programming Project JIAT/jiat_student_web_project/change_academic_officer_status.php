<?php
session_start();
require "connection.php";
if(isset($_SESSION["admin"])){



  $academicOfficerId=addslashes($_POST["academicOfficerId"]);




    $academic_officer_rs=connect::executer("SELECT * FROM `academic_officer` WHERE `id`='".$academicOfficerId."';");


    if($academic_officer_rs->num_rows==1){


        $academic_officer_fetch=$academic_officer_rs->fetch_assoc();


        if(connect::executer("SELECT * FROM `academic_officer_account_access_code` WHERE `academic_officer_id`='".$academicOfficerId."';")->num_rows==0){

        

        if($academic_officer_fetch["status_id"]==1){

            connect::executer("UPDATE `academic_officer` SET `status_id`='2' WHERE `id`='".$academicOfficerId."';");

            echo "Blocked";

        }else{

            connect::executer("UPDATE `academic_officer` SET `status_id`='1' WHERE `id`='".$academicOfficerId."';");

            echo "Active";


        }

        }else{

           echo "This Academic Officer is not verified.";

        }



    }else{


        echo "Academic Officer not found.";


    }

  

  


}



?>