<?php
session_start();
require "connection.php";
if(isset($_SESSION["admin"])){

    $teacherId=addslashes($_POST["teacherId"]);
    $subject_has_grade=addslashes($_POST["subject_has_grade"]);

   if(!empty($subject_has_grade)){


    $teacher_rs=connect::executer("SELECT * FROM `teacher` WHERE `id`='".$teacherId."';");
    $subject_has_grade_rs=connect::executer("SELECT * FROM `subject_has_grade` WHERE `id`='".$subject_has_grade."';");



    if($teacher_rs->num_rows !=1){

        echo "Invalid teacher!";

        
    }else if($subject_has_grade_rs->num_rows !=1){

        echo "Invalid subject area!";

        
    }else{

      connect::executer("UPDATE `teacher` SET `subject_has_grade_id`='".$subject_has_grade."' WHERE `id`='".$teacherId."';");


      echo "success";


    }
  }else{

     echo "Please select a subject area to update the subject area.";

  }

}



?>