<?php
session_start();
require "connection.php";
if(isset($_SESSION["student"])){

    $date=new DateTime();
    $timeZone= new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time=$date->format("Y-m-d H:i:s");



    if(connect::executer("SELECT * FROM `student` WHERE `id`='".$_SESSION["student"]["id"]."' AND `status_id`='2';")->num_rows==1){
    
    
       

        unset($_SESSION["student"]);

        echo "Blocked";

    
    }else{

        $student_grading_rs=connect::executer("SELECT * FROM `student_grading` WHERE `id`='".$_SESSION["student"]["id"]."';");


        $student_grading_fetch=$student_grading_rs->fetch_assoc();


    $eronollment_pay_rs=connect::executer("SELECT * FROM `enrollment_payments` WHERE `student_id`='".$_SESSION["student"]["id"]."';");

    

    if($eronollment_pay_rs->num_rows==0){

     
         

      $start_date = new DateTime($student_grading_fetch["graded_date_time"]);
      $since_start = $start_date->diff(new DateTime($current_date_time));




      if($since_start->days<30){


         echo "success-payment-must";

         
       



      }else{


       
        unset($_SESSION["student"]);

        echo "Blocked";


      }



                  

    }else{


   

  
   
     
         

      $start_date = new DateTime($student_grading_fetch["graded_date_time"]);
      $since_start = $start_date->diff(new DateTime($current_date_time));


 


      if($since_start->days<30){


         $en_pay_rs=connect::executer("SELECT * FROM `enrollment_payments` WHERE `student_id`='".$_SESSION["student"]["id"]."' ORDER BY `date_time` DESC LIMIT 1 OFFSET 0;");

         $en_pay_fetch= $en_pay_rs->fetch_assoc();


   


   

          $total_date_explode=explode("-",explode(" ",$en_pay_fetch["date_time"])[0]);

          $total_time_explode=explode(":",explode(" ",$en_pay_fetch["date_time"])[1]);

          $total_payment_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];

          $total_date_explode=explode("-",explode(" ",$student_grading_fetch["graded_date_time"])[0]);

          $total_time_explode=explode(":",explode(" ",$student_grading_fetch["graded_date_time"])[1]);

          $total_grade_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];

         
          if($total_payment_datetime_explode<$total_grade_datetime_explode){

     
                  
 
         echo "success-payment-must";
     



          }else if($total_payment_datetime_explode>=$total_grade_datetime_explode){


    
           
                  echo "success";
              

            
          }


          


         
       



      }else{

         $en_pay_rs=connect::executer("SELECT * FROM `enrollment_payments` WHERE `student_id`='".$_SESSION["student"]["id"]."' ORDER BY `date_time` DESC LIMIT 1 OFFSET 0;");

         $en_pay_fetch= $en_pay_rs->fetch_assoc();



         $total_date_explode=explode("-",explode(" ",$en_pay_fetch["date_time"])[0]);

         $total_time_explode=explode(":",explode(" ",$en_pay_fetch["date_time"])[1]);

         $total_payment_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];

         $total_date_explode=explode("-",explode(" ",$student_grading_fetch["graded_date_time"])[0]);

         $total_time_explode=explode(":",explode(" ",$student_grading_fetch["graded_date_time"])[1]);

         $total_grade_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];


         
         if($total_payment_datetime_explode<$total_grade_datetime_explode){

     
           
          
          
          
              
        unset($_SESSION["student"]);

        echo "Blocked";

                 
        
        
        
                  }else if($total_payment_datetime_explode>=$total_grade_datetime_explode){
        

                   
                          echo "success";
                  
        
                    
                  }
        

      


      }




    }

        
}


}else{

echo "Signed out";


}



?>