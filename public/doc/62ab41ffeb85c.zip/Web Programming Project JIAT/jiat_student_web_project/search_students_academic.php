<?php
session_start();
require "connection.php";

if (isset($_SESSION["academic_officer"])) {


    $searchStudent = strtolower(addslashes($_POST["searchStudent"]));

    $student_rs = connect::executer("SELECT  `student`.`id` AS `student_id`,`student`.`first_name`,`student`.`last_name`,`student`.`email`,`student`.`status_id`,`status`.`type`,`student`.`username`,`student_account_access_code`.`student_id` AS `student_access_id`,CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img`,`grade`.`name` AS `grade_name`,`student_grading`.`graded_date_time` FROM `student` INNER JOIN `status` ON `student`.`status_id`=`status`.`id` INNER JOIN `student_grading` ON `student`.`student_grading_id`=`student_grading`.`id` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` LEFT JOIN `student_account_access_code` ON `student_account_access_code`.`student_id`=`student`.`id` LEFT JOIN `student_profile_pic` ON `student_profile_pic`.`student_id`=`student`.`id` LEFT JOIN `image` ON `student_profile_pic`.`image_id`=`image`.`id` LEFT JOIN `image_type` ON `image`.`image_type_id`=`image_type`.`id` WHERE LOWER(CONCAT(`student`.`first_name`,' ',`student`.`last_name`)) LIKE '%" . $searchStudent . "%' OR LOWER(`student`.`email`) LIKE '%" . $searchStudent . "%'  ORDER BY `student`.`id` ASC;");


    while ($student_fetch = $student_rs->fetch_assoc()) {

?>
        <tr>
            <td> <?php


                    if ($student_fetch["profile_img"] != "" && $student_fetch["profile_img"] != null) { //if a profile picture exsists



                    ?>

                    <img src="<?php echo "profiles/" . $student_fetch["profile_img"]; //shows the profile picture 
                                ?>" class="rounded-circle" id="img_pro_prev" style="width: 50px;height: 50px;" />

                <?php

                    } else { //if a profile picture does not exsist
                ?>

                    <!-- Shows the default profile picture -->
                    <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 50px;height: 50px;" />

                <?php



                    }
                ?>
            </td>

            <td><?php echo $student_fetch["first_name"]; ?></td>
            <td><?php echo $student_fetch["last_name"]; ?></td>
            <td><?php echo $student_fetch["email"]; ?></td>
            <td><?php echo $student_fetch["username"]; ?></td>
            <td><?php echo $student_fetch["grade_name"]; ?></td>


        </tr>
<?php

    }
}
?>