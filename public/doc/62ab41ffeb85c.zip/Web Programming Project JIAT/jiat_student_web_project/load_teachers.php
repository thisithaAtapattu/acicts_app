<?php
session_start();
require "connection.php";
if (isset($_SESSION["admin"])) {


    $teacher_rs = connect::executer("SELECT  `teacher`.`id` AS `teacher_id`,`teacher`.`first_name`,`teacher`.`last_name`,`teacher`.`email`,`teacher`.`status_id`,`status`.`type`,`teacher`.`username`,`teacher_account_access_code`.`teacher_id` AS `teacher_access_id`,CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img`,`grade`.`name` AS `grade_name`,`subject`.`name` AS `subject_name`,`subject_has_grade`.`id` AS `subject_has_grade_id` FROM `teacher` INNER JOIN `status` ON `teacher`.`status_id`=`status`.`id` INNER JOIN `subject_has_grade` ON `teacher`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` LEFT JOIN `teacher_account_access_code` ON `teacher_account_access_code`.`teacher_id`=`teacher`.`id` LEFT JOIN `teacher_profile_pic` ON `teacher_profile_pic`.`teacher_id`=`teacher`.`id` LEFT JOIN `image` ON `teacher_profile_pic`.`teacher_id`=`teacher`.`id` LEFT JOIN `image_type` ON `image`.`image_type_id`=`image_type`.`id` ORDER BY `teacher`.`id` ASC;");


    while ($teacher_fetch = $teacher_rs->fetch_assoc()) {


        if ($teacher_fetch["teacher_access_id"] == "" || $teacher_fetch["teacher_access_id"] == null) {

    ?>
            <tr>
                <td> <?php


                        if ($teacher_fetch["profile_img"] != "" && $teacher_fetch["profile_img"] != null) { //if a profile picture exsists



                        ?>

                        <img src="<?php echo "profiles/" . $teacher_fetch["profile_img"]; //shows the profile picture 
                                    ?>" class="rounded-circle" id="img_pro_prev" style="width: 50px;height: 50px;" />

                    <?php

                        } else { //if a profile picture does not exsist
                    ?>

                        <!-- Shows the default profile picture -->
                        <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 50px;height: 50px;" />

                    <?php



                        }
                    ?>
                </td>

                <td><?php echo $teacher_fetch["first_name"]; ?></td>
                <td><?php echo $teacher_fetch["last_name"]; ?></td>
                <td><?php echo $teacher_fetch["email"]; ?></td>
                <td><?php echo $teacher_fetch["username"]; ?></td>
                <td>
                    <div class="select is-info d-grid">
                        <select id="subject_has_grade_individual_teacher<?php echo $teacher_fetch['teacher_id'] ?>" onchange="changeTeacherGrade(<?php echo $teacher_fetch['teacher_id'] ?>);">
                            <option value="">Select Subject Area</option>
                            <?php
                            $subject_has_grade_rs = connect::executer("SELECT `subject`.`name` AS `subject_name`,`grade`.`name` AS `grade_name`,`subject_has_grade`.`id` FROM `subject_has_grade` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` ORDER BY `grade`.`name` ASC;");

                            while ($subject_has_grade_fetch = $subject_has_grade_rs->fetch_assoc()) {

                            ?>
                                <option value="<?php echo $subject_has_grade_fetch["id"]; ?>" <?php

                                     if($teacher_fetch["subject_has_grade_id"]==$subject_has_grade_fetch["id"]){

                                         ?>
                                           selected=""
                                         <?php

                                     }

                                                                                                ?>><?php echo "Grade " . $subject_has_grade_fetch["grade_name"] . " " . $subject_has_grade_fetch["subject_name"]; ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </div>
                </td>

                <td id="statusColumn<?php echo $teacher_fetch['teacher_id']; ?>"><?php echo $teacher_fetch["type"]; ?></td>

                <td>
                    <?php




                    if ($teacher_fetch["status_id"] == 1) {
                    ?>

                        <button class="btn btn-danger d-grid" onclick="changeTeacherStatus(<?php echo $teacher_fetch['teacher_id']; ?>);" id="teacherstatusChangeButton<?php echo $teacher_fetch['teacher_id']; ?>">Block</button>
                    <?php
                    } else {
                    ?>
                        <button class="btn btn-success d-grid" onclick="changeTeacherStatus(<?php echo $teacher_fetch['teacher_id']; ?>);" id="teacherstatusChangeButton<?php echo $teacher_fetch['teacher_id']; ?>">Activate</button>
                    <?php


                    }

                    ?>


                </td>

            </tr>
    <?php
        }
    }


}
?>