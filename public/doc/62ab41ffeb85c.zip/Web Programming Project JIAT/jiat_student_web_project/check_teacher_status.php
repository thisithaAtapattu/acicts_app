<?php
session_start();
require "connection.php";
if(isset($_SESSION["teacher"])){





    if(connect::executer("SELECT * FROM `teacher` WHERE `id`='".$_SESSION["teacher"]["id"]."' AND `status_id`='2';")->num_rows==1){
    
    
       

        unset($_SESSION["teacher"]);

        echo "Blocked";

    
    }

}else{

echo "Signed out";


}



?>