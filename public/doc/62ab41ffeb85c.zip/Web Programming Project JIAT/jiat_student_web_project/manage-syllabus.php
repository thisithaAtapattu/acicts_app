<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["admin"])) { //checkes if the session is set to show the content

    $admin_details = $_SESSION["admin"]; //gets the admin details from the session

?>
    <!DOCTYPE html>
    <html>

    <head>


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ministry of Education</title>
        <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
        <link rel="stylesheet" href="bootstrap.css" />

        <link rel="stylesheet" href="style.css" />
        <link rel="stylesheet" href="font/bootstrap-icons.css">

        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

        <link rel="stylesheet" href="bulma.css" />


    </head>

    <body>



        <div class="container-fluid ">

            <div class="row">

                <div class="col-12">

                    <div class="row">



                        <div class="col-md-4 pb-5" style="background-color: hsl(0, 0%, 96%)	;">

                            <!-- Profile section with logout -->

                            <div class="row ">









                                <div class="col-12 d-flex flex-column align-items-center mt-2">


                                    <div class="row  ">
                                        <?php

                                        $profile_pic_result = connect::executer("SELECT CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img` FROM `admin_profile_pic` INNER JOIN `image` ON `admin_profile_pic`.`image_id`=`image`.`id` INNER JOIN`image_type` ON  `image`.`image_type_id`=`image_type`.`id` WHERE `admin_profile_pic`.`admin_id`='" . addslashes($admin_details["id"]) . "';"); //searches for the profile picture in the database

                                        if ($profile_pic_result->num_rows == 1) { //if a profile picture exsists


                                            $profile_pic_fetch = $profile_pic_result->fetch_assoc(); //covert's the profile picture result set to an associative array

                                        ?>

                                            <img src="<?php echo "profiles/" . $profile_pic_fetch["profile_img"]; //shows the profile picture 
                                                        ?>" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php

                                        } else { //if a profile picture does not exsist
                                        ?>

                                            <!-- Shows the default profile picture -->
                                            <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php



                                        }
                                        ?>

                                    </div>




                                </div>


















                            </div>



                            <div class="row">


                                <div class="col-12 text-center">


                                    <div class="row">

                                        <p class=" fw-bold" id="name_viewer"><?php echo $admin_details["first_name"] . " " . $admin_details["last_name"] //display the first and last name of the user taken by the session; 
                                                                                ?></p>




                                        <div>

                                            <h6 class=" fw-bold has-text-link	" style="font-size:10px;">ADMIN</h6>


                                        </div>







                                    </div>




                                </div>


                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-5 offset-5 mt-1">


                                            <div class="row">

                                                <button class="btn btn-danger col-5" onclick="logOutAdmin();">Log out</button>

                                            </div>



                                        </div>





                                    </div>



                                </div>





                            </div>

                            <!-- Profile section with logout -->


                            <hr class="col-12 bg-dark" />

                            <!-- Navigation section -->

                            <div class="row px-5">


                                <div class="col-12 set-border-dash pt-2 pb-2" onclick="goToAmin();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-circle"></i> Update Profile</p>





                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToCheckResults();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-newspaper"></i> Check Results</p>









                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageAmin();">


                                    <div class="row">

                                        <p class=" fw-bold  has-text-grey-lighter"><i class="bi bi-person-square"></i> Manage Administration</p>












                                    </div>




                                </div>



                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageStudents();">


                                    <div class="row">

                                        <p class=" fw-bold  has-text-grey-lighter"><i class="bi bi-person-lines-fill"></i> Manage Students</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageTeachers();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-workspace"></i> Manage Teachers</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageAcademicOfficers();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-video2"></i> Manage Academic Officers</p>












                                    </div>




                                </div>



                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1">


                                    <div class="row">

                                        <p class=" fw-bold has-text-info"><i class="bi bi-body-text"></i> Manage Syllabus</p>












                                    </div>




                                </div>






                            </div>


                            <!-- Navigation section -->




                        </div>





                        <div class="col-md-6 ">


                            <div class="row edu-background-dashboard ms-2">




                            </div>

                            <div class=" row">




                                <div class="offset-md-2 ">

                                    <div class="row">

                                        <h1 class="fs-1 fw-bold has-text-info text-center">Add New Subject</h1>


                                    </div>



                                    <div class="row mt-5 ms-md-3">

                                        <div class="col-12 ">



                                            <input class="input is-info mt-5" type="text" placeholder="Subject Name" id="subject_name">







                                        </div>



                                        <div class="col-12">

                                            <button class="button is-info mt-5 d-grid col-12" onclick="addSubject();">Add Subject</button>


                                        </div>

                                    </div>








                                </div>








                            </div>



                            <div class=" row">




                                <div class="offset-md-2 ">



                                    <div class="row overflow-scroll scroll-app mt-5">


                                        <table class="table mt-3">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Subject Name</th>
                                                </tr>
                                            </thead>
                                            <tbody id="subject_loading_area">

                                                <?php
                                                $subject_rs = connect::executer("SELECT * FROM `subject`;");

                                                for ($subject_count = 1; $subject_count <= $subject_rs->num_rows; $subject_count++) {
                                                ?>

                                                    <tr>
                                                        <td class="col"><?php echo $subject_count; ?></td>
                                                        <td><?php echo $subject_rs->fetch_assoc()["name"]; ?></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>

                                            </tbody>
                                        </table>








                                    </div>














                                </div>









                            </div>





                        </div>

                        <div class="col-md-4">

                            <div class="row">

                                <div class="mt-2 ">

                                    <div class="row">

                                        <h1 class="fs-1 fw-bold has-text-info text-center">Grade & Subject Mapping</h1>

                                    </div>


                                    <div class="row">


                                        <div class="col-12 overflow-scroll">





                                            <div class="select is-info mt-5 d-grid">
                                                <select id="subject">
                                                    <option value="">Select Subject</option>
                                                    <?php
                                                    $subjectRs = connect::executer("SELECT * FROM `subject`;");

                                                    while ($subjectFetch = $subjectRs->fetch_assoc()) {
                                                    ?>
                                                        <option value="<?php echo $subjectFetch["id"]; ?>"><?php echo $subjectFetch["name"]; ?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>



















                                        </div>


                                        <div class="col-12">





                                            <div class="select is-info mt-5 d-grid">
                                                <select id="grade">
                                                    <option value="">Select Grade</option>
                                                    <?php
                                                    $gradeRs = connect::executer("SELECT * FROM `grade`;");

                                                    while ($gradeFetch = $gradeRs->fetch_assoc()) {
                                                    ?>
                                                        <option value="<?php echo $gradeFetch["id"]; ?>"><?php echo $gradeFetch["name"]; ?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>












                                        </div>





                                    </div>

                                    <div class="row mt-5 ">



                                        <div class="col-12">

                                            <button class="button is-info mt-5 d-grid col-12" onclick="addMapping();">Add Mapping</button>


                                        </div>

                                    </div>








                                </div>


                            </div>




                        </div>

                        <div class="col-md-6 mt-3">


                            <div class="row mt-5">


                                <div class="offset-md-2 ">






                                    <div class="row overflow-scroll scroll-app mt-5">


                                        <table class="table mt-5">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Grade</th>
                                                    <th scope="col">Subject Name</th>
                                                </tr>
                                            </thead>
                                            <tbody id="subject_has_grade_loading_area">


                                                <?php
                                                $subject_has_grade_rs = connect::executer("SELECT `subject`.`name` AS `subject_name`,`grade`.`name` AS `grade_name` FROM `subject_has_grade` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` ORDER BY `grade`.`name` ASC;");

                                                while ($subject_has_grade_fetch = $subject_has_grade_rs->fetch_assoc()) {
                                                ?>

                                                    <tr>
                                                        <td class="col"><?php echo "Grade " . $subject_has_grade_fetch["grade_name"]; ?></td>
                                                        <td><?php echo $subject_has_grade_fetch["subject_name"]; ?></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>

                                            </tbody>
                                        </table>








                                    </div>




                                </div>




                            </div>


                        </div>


                    </div>




                </div>








            </div>









            <script src="script.js"></script> <!-- My js file -->
            <script>
                checkStatusAdmin(); //this function checks the status of the admin and logs out the admin if the admin is blocked
            </script>
            <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script> <!-- JQuery js file -->
            <script src="jquery-3.6.0.min.js"></script> <!-- JQuery js file -->
            <script src="sweetalert.min.js"></script><!-- SweetAlert js file -->
            <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script><!-- Toastify JS file -->
    </body>









    </html>
<?php

} else { //if the session is not set


?>
    <script>
        window.location = "admin-login";
    </script>
<?php


}

?>