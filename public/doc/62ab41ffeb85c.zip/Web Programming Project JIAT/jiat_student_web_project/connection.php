<?php

class connect{


public static $dbms;





public static function dbConnection(){


    if(!isset(connect::$dbms)){//checks if $dbms variable is set before since the target here is to reduce the amount of database connections
       connect::$dbms= new mysqli("127.0.0.1","root","thisitha#8002*","assignment1","3306");
    }

}

public static function executer($Que){//gets the query which was passed through thr function 


    connect::dbConnection();//calls this function to create the connection if not  created

   $resultset= connect::$dbms->query($Que);//executes query

   
   return $resultset;//returns the resultset

}




}
?>