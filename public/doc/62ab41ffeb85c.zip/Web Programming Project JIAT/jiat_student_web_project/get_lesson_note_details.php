<?php
session_start();
require "connection.php";
if(isset($_SESSION["teacher"])){

    $teacher_details = $_SESSION["teacher"];


    $lessonNoteId=addslashes($_POST["lessonNoteId"]);

    $lesson_note_rs=connect::executer("SELECT * FROM `lesson_note` WHERE `id`='".$lessonNoteId."';");


    if($lesson_note_rs->num_rows==1){

        $lesson_note_fetch=$lesson_note_rs->fetch_assoc();

        $jsonArray;

        $jsonArray["id"]=$lesson_note_fetch["id"];
        $jsonArray["title"]=$lesson_note_fetch["title"];

        echo json_encode($jsonArray);



    }else{

       echo "Invalid lesson note!";


    }

}





?>