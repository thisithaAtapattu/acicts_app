<?php
session_start();
require "connection.php";


if(isset($_SESSION["teacher"])){

    $date=new DateTime();
    $timeZone= new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time=$date->format("Y-m-d H:i:s");
    
    $current_year=$date->format("Y");

    $current_date=$date->format("Y-m-d");

    $teacher_details=$_SESSION["teacher"];



    $title=addslashes($_POST["title"]);
    $start_date=addslashes($_POST["start_date"]);
    $end_date=addslashes($_POST["end_date"]);

    if($title==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$title))) == 0){

        echo "Please enter the assignment title.";

    }else if(empty($start_date)){

        echo "Please select the start date.";


    }else if(explode("-",$start_date)<explode("-",$current_date)){

        echo "The assignment start date must be today or after today.";


    }else if(empty($end_date)){

        echo "Please select the end date.";


    }else if(explode("-",$end_date)<explode("-",$current_date)){

        echo "The assignment end date must be today or after today.";


    }else if(explode("-",$start_date)>explode("-",$end_date)){

        echo "The start date can't be after the end date.";


    }else{


    if(isset($_FILES["file_chooser"])){
   
  
       $file=$_FILES["file_chooser"];
   
       $file_name=$file["name"];
   
       $exploded_file_name=explode(".",$file_name);
   
       if($exploded_file_name[sizeof( $exploded_file_name)-1]=="pdf"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="docx"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="zip"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="pptx"){


         $file_name_upload=uniqid().".".$exploded_file_name[sizeof( $exploded_file_name)-1];

         move_uploaded_file($file["tmp_name"],"doc/".$file_name_upload);


          connect::executer("INSERT INTO `assignment`(`title`,`file_name`,`start_date`,`end_date`,`subject_has_grade_id`) VALUES ('".$title."','".$file_name_upload."','".$start_date."','".$end_date."','".$teacher_details["subject_has_grade_id"]."');");

         
          echo "success";



       }else{


           echo "The file must be a pdf file, zip file, docx file, or a pptx file.";
         


       }

    }else{

      echo "Please select a file.";
    

    }
  }
}

?>