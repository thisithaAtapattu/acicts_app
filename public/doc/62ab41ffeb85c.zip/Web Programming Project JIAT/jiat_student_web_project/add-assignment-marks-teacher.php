<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["teacher"])) { //checkes if the session is set to show the content

    $teacher_details = $_SESSION["teacher"]; //gets the teacher details from the session


    $date = new DateTime();
    $timeZone = new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time = $date->format("Y-m-d H:i:s");

    $current_year = $date->format("Y");

    $current_date = $date->format("Y-m-d");

?>
    <!DOCTYPE html>
    <html>

    <head>


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ministry of Education</title>
        <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
        <link rel="stylesheet" href="bootstrap.css" />

        <link rel="stylesheet" href="style.css" /><!-- My Css File -->
        <link rel="stylesheet" href="font/bootstrap-icons.css">

        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

        <link rel="stylesheet" href="bulma.css" />

        <style>
            #PopupModel {
                width: 60%;
            }

            .modal {}

            .vertical-alignment-helper {
                display: table;
                height: 100%;
                width: 100%;
            }

            .vertical-align-center {
                /*/To center vertically*/
                display: table-cell;
                vertical-align: middle;
            }

            .modal-content {
                /*Bootstrap sets the size of the modal in the modal-dialog class, we need to inherit it*/
                width: inherit;
                height: inherit;
                /*To center horizontally*/

            }
        </style>


    </head>

    <body>



        <div class="container-fluid ">

            <div class="row">

                <div class="col-12">

                    <div class="row">



                        <div class="col-md-4 pb-5" style="background-color: hsl(0, 0%, 96%)	;">

                            <!-- Profile section with logout -->

                            <div class="row ">









                                <div class="col-12 d-flex flex-column align-items-center mt-2">





                                    <div class="row ">

                                        <?php

                                        $profile_pic_result = connect::executer("SELECT CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img` FROM `teacher_profile_pic` INNER JOIN `image` ON `teacher_profile_pic`.`image_id`=`image`.`id` INNER JOIN`image_type` ON  `image`.`image_type_id`=`image_type`.`id` WHERE `teacher_profile_pic`.`teacher_id`='" . addslashes($teacher_details["id"]) . "';"); //searches for the profile picture in the database

                                        if ($profile_pic_result->num_rows == 1) { //if a profile picture exsists


                                            $profile_pic_fetch = $profile_pic_result->fetch_assoc(); //covert's the profile picture result set to an associative array

                                        ?>

                                            <img src="<?php echo "profiles/" . $profile_pic_fetch["profile_img"]; //shows the profile picture 
                                                        ?>" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php

                                        } else { //if a profile picture does not exsist
                                        ?>

                                            <!-- Shows the default profile picture -->
                                            <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php



                                        }
                                        ?>

                                    </div>




                                </div>













                                <div class="col-6 offset-3 mt-2">

                                    <div class="row">

                                        <input type="file" id="profile_pic" class="d-none" />




                                    </div>


                                </div>






                            </div>



                            <div class="row">


                                <div class="col-12 text-center">


                                    <div class="row">

                                        <p class=" fw-bold" id="name_viewer"><?php echo $teacher_details["first_name"] . " " . $teacher_details["last_name"] //display the first and last name of the user taken by the session; 
                                                                                ?></p>




                                        <div>

                                            <h6 class=" fw-bold has-text-link	" style="font-size:10px;">TEACHER</h6>


                                        </div>







                                    </div>




                                </div>


                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-5 offset-5 mt-1">


                                            <div class="row">

                                                <button class="btn btn-danger col-5" onclick="logOutTeacher();">Log out</button>

                                            </div>



                                        </div>





                                    </div>



                                </div>





                            </div>

                            <!-- Profile section with logout -->


                            <hr class="col-12 bg-dark" />

                            <!-- Navigation section -->

                            <div class="row px-5">


                                <div class="col-12 set-border-dash pt-2 pb-2" onclick="goToTeacher();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-circle"></i> Update Profile</p>












                                    </div>




                                </div>



                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1">


                                    <div class="row">

                                        <p class=" fw-bold  has-text-info"><i class="bi bi-newspaper"></i> Mark Management</p>












                                    </div>




                                </div>

                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToAddLessonNotes();">


                                    <div class="row">

                                        <p class=" fw-bold  has-text-grey-lighter"><i class="bi bi-book"></i></i> Add Lesson Notes</p>












                                    </div>




                                </div>







                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToAddAssignments();">


                                    <div class="row">

                                        <p class=" fw-bold  has-text-grey-lighter"><i class="bi bi-newspaper"></i> Add Assignments</p>












                                    </div>




                                </div>












                            </div>


                            <!-- Navigation section -->




                        </div>



                        <!-- Update profile section -->


                        <div class="col-md-8 ">

                            <div class="row edu-background-dashboard ms-2">




                            </div>


                            <div class=" row">

                                <div class="col-12 col-md-12 mt-5">





                                </div>


                                <div class="col-md-12 mt-5  ">







                                    <div class="col-12 mt-3">
                                        <div class="row overflow-scroll">


                                            <table class="table overflow-scroll">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Student First Name</th>
                                                        <th scope="col">Student Last Name</th>
                                                        <th scope="col">Student Email</th>
                                                        <th scope="col">Assignment Title</th>
                                                        <th scope="col">Subject Area</th>
                                                        <th scope="col">Download Assignment</th>
                                                        <th scope="col">Download Student Answer Sheet</th>
                                                   
                                                        <th scope="col">Start Date</th>
                                                        <th scope="col">End Date</th>
                                                        <th scope="col">Add Marks</th>


                                                    </tr>
                                                </thead>
                                                <tbody id="assignment_load_area">
                                                    <?php

                                                    $assignment_rs = connect::executer("SELECT `assignment_has_student`.`id` AS `assignment_has_student_id`,`assignment`.`title`,`assignment`.`file_name` AS `assignment_file_name`,`assignment`.`start_date`,`assignment`.`end_date`,`assignment_has_student`.`file_name` AS `student_file_name`,`student`.`first_name`,`student`.`last_name`,`subject`.`name` AS `subject_name`, `grade`.`name` AS `grade_name`,`student`.`email`,`assignment_marks`.`mark` FROM `assignment_has_student` INNER JOIN `assignment` ON `assignment_has_student`.`assignment_id`=`assignment`.`id` INNER JOIN `student` ON `assignment_has_student`.`student_id`=`student`.`id` INNER JOIN `subject_has_grade` ON `assignment`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` LEFT JOIN `assignment_marks` ON `assignment_marks`.`assignment_has_student_id`=`assignment_has_student`.`id` WHERE `subject_has_grade`.`id`='" . $teacher_details["subject_has_grade_id"] . "' AND `assignment`.`end_date`<'".$current_date."' ORDER BY `assignment`.`start_date` DESC;");

                                                    while ($assignment_fetch = $assignment_rs->fetch_assoc()) {


                                                        if($assignment_fetch["mark"]==""||$assignment_fetch["mark"]==null){
                                                    ?>
                                                        <tr>

                                                         <td><?php echo $assignment_fetch["first_name"]  ?></td>
                                                         <td><?php echo $assignment_fetch["last_name"]  ?></td>
                                                         <td><?php echo $assignment_fetch["email"]  ?></td>
                                                         <td><?php echo $assignment_fetch["title"]  ?></td>
                                                         <td><?php echo "Grade ".$assignment_fetch["grade_name"]." ".$assignment_fetch["subject_name"]  ?></td>
                                                         <td><a class="button is-danger is-light" download="" href="<?php echo "doc/" . $assignment_fetch["assignment_file_name"]; ?>">Download Assignment</a></td>
                                                         <td><a class="button is-danger is-light" download="" href="<?php echo "doc/" . $assignment_fetch["student_file_name"]; ?>">Download Answer Sheet</a></td>
                                                         <td><?php echo $assignment_fetch["start_date"]  ?></td>
                                                         <td><?php echo $assignment_fetch["end_date"]  ?></td>
                                                         <td><button class="btn btn-success" onclick="markAssignment(<?php echo $assignment_fetch['assignment_has_student_id']; ?>);">Add Mark</button></td>



                                                        </tr>

                                                    <?php
                                                      }
                                                    }

                                                    ?>

                                                </tbody>
                                            </table>




                                        </div>




                                    </div>



                                </div>






                            </div>








                        </div>






                    </div>


                </div>

                <!-- Button trigger modal -->

                <!-- Modal -->
                <div class="modal fade" id="add_ass_marks_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 10000;">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="assignment_marks_upload">Add Marks Of</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                            

                                <input class="input is-info " type="number" placeholder="Marks" id="assignment_mark" min="0"/>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="addMarkButton">Add Mark</button>
                            </div>
                        </div>
                    </div>
                </div>


            </div>








        </div>








        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script> <!-- My js file -->
        <script>
            checkStatusTeacher(); //this function checks the status of the teacher and logs out the teacher if the teacher is blocked
        </script>
        <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script> <!-- JQuery js file -->
        <script src="jquery-3.6.0.min.js"></script> <!-- JQuery js file -->
        <script src="sweetalert.min.js"></script><!-- SweetAlert js file -->
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script><!-- Toastify JS file -->
    </body>









    </html>
<?php

} else { //if the session is not set


?>
    <script>
        window.location = "teacher-login";
    </script>
<?php


}

?>