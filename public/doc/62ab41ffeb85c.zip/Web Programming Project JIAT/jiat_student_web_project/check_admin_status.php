<?php
session_start();
require "connection.php";
if(isset($_SESSION["admin"])){





    if(connect::executer("SELECT * FROM `admin` WHERE `id`='".$_SESSION["admin"]["id"]."' AND `status_id`='2';")->num_rows==1){
    
    
       

        unset($_SESSION["admin"]);

        echo "Blocked";

    
    }

}else{

echo "Admin signed out";


}



?>