<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is


//Required the connection file with the database connection
require "connection.php";


if(isset($_SESSION["student"])){//checks if the student is singed in


    $student_details=$_SESSION["student"];//gets the student details from the session


if(isset($_FILES["profile_pic"])){//if the profile picture is set


   $profile_pic = $_FILES["profile_pic"];//gets the  profile picture




  if(substr($profile_pic["type"],0,5)=="image"){//checks if he uploaded file is an image



           $image_code=uniqid();//genarates unique id and assignes to $image_code variable


           $exploded_file_name=explode(".",$profile_pic["name"]);//explodes the name of the uploaded file by the pointes where dots are

         $image_type=$exploded_file_name[sizeof($exploded_file_name)-1];//gets the last values divided from the dot which is the image file extension


           $type_result=connect::executer("SELECT * FROM `image_type` WHERE `type`='".addslashes($image_type)."';");//checks if the image extension exsists in the database

           $image_extension_id="";

           if($type_result->num_rows==1){//if the image extension exsists

              $image_extension_id=$type_result->fetch_assoc()["id"];//assignes the exsists image extension id to the $image_extension_id variable

           }else{//if the image extension does not exsist

                 connect::executer("INSERT INTO `image_type`(`type`) VALUES ('".addslashes($image_type)."');");//inserts the image extension to the database


                 $image_extension_id=connect::$dbms->insert_id;//assignes the last inserted image extension's id to the $image_extension_id variable



           }
            


          


           $profile_pic_result=connect::executer("SELECT * FROM `student_profile_pic` INNER JOIN `image` ON `student_profile_pic`.`image_id`=`image`.`id` INNER JOIN `image_type` ON  `image`.`image_type_id`=`image_type`.`id` WHERE `student_profile_pic`.`student_id`='".addslashes($student_details["id"])."';");//checks if the student currently has a profile picture

           if($profile_pic_result->num_rows==1){//if the student has a profile picture


                   $profile_pic_fetch=$profile_pic_result->fetch_assoc();//converts the result set to associative array

                   connect::executer("UPDATE `image` SET `image_type_id`='".addslashes($image_extension_id)."',`code`='".addslashes($image_code)."' WHERE `id`='".$profile_pic_fetch["image_id"]."';");

                   unlink("profiles/".$profile_pic_fetch["code"].".".$profile_pic_fetch["type"]);//deletes the previous profile picture

                   move_uploaded_file($profile_pic["tmp_name"],"profiles/".$image_code.".".$image_type);//moves the profile picture from the temperory location to the actual location

           }else{//if the student has no profile picture
              
                   connect::executer("INSERT INTO `image`(`image_type_id`,`code`) VALUES ('".addslashes($image_extension_id)."','".addslashes($image_code)."');");

                  $imageId=connect::$dbms->insert_id;


                   connect::executer("INSERT INTO `student_profile_pic`(`student_id`,`image_id`) VALUES ('".addslashes($student_details["id"])."','".addslashes($imageId)."');");//inserts a new profile picture


                   move_uploaded_file($profile_pic["tmp_name"],"profiles/".$image_code.".".$image_type);//moves the profile picture from the temperory location to the actual location


           }



        echo "success";
    
      
     


   }


}


}


?>