<?php
session_start();
require "connection.php";

if (isset($_SESSION["admin"])) {
    $admin_details = $_SESSION["admin"];

    $searchAdmin = strtolower(addslashes($_POST["searchAdmin"]));



    $admin_rs = connect::executer("SELECT `admin`.`id` AS `admin_id`,`admin`.`first_name`,`admin`.`last_name`,`admin`.`email`,`admin`.`status_id`,`status`.`type`,`admin`.`username`,CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_image` FROM `admin` INNER JOIN `status` ON `admin`.`status_id`=`status`.`id` LEFT JOIN `admin_profile_pic` ON `admin_profile_pic`.`admin_id`=`admin`.`id` LEFT JOIN `image` ON `admin_profile_pic`.`image_id`=`image`.`id` LEFT JOIN `image_type` ON `image`.`image_type_id`=`image_type`.`id` WHERE LOWER(CONCAT(`admin`.`first_name`,' ',`admin`.`last_name`)) LIKE '%" . $searchAdmin . "%' OR LOWER(`admin`.`email`) LIKE '%" . $searchAdmin . "%'  ORDER BY `admin`.`id` ASC;");


    while ($admin_fetch = $admin_rs->fetch_assoc()) {
?>
        <tr>
            <td>

                <?php

                if ($admin_fetch["profile_image"] != "" && $admin_fetch["profile_image"] != null) { //if a profile picture exsists



                ?>

                    <img src="<?php echo "profiles/" . $admin_fetch["profile_image"]; //shows the profile picture 
                                ?>" class="rounded-circle" id="img_pro_prev" style="width: 50px;height: 50px;" />

                <?php

                } else { //if a profile picture does not exsist
                ?>

                    <!-- Shows the default profile picture -->
                    <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 50px;height: 50px;" />

                <?php



                }
                ?>
            </td>

            <td><?php echo $admin_fetch["first_name"]; ?></td>
            <td><?php echo $admin_fetch["last_name"]; ?></td>
            <td><?php echo $admin_fetch["email"]; ?></td>
            <td><?php echo $admin_fetch["username"]; ?></td>
            <td id="statusColumn<?php echo $admin_fetch['admin_id']; ?>"><?php echo $admin_fetch["type"]; ?></td>

            <td>
                <?php


                if ($admin_fetch['admin_id'] != $admin_details["id"]) {

                    if ($admin_fetch["status_id"] == 1) {
                ?>

                        <button class="btn btn-danger d-grid" onclick="changeAdminStatus(<?php echo $admin_fetch['admin_id']; ?>);" id="AdminstatusChangeButton<?php echo $admin_fetch['admin_id']; ?>">Block</button>
                    <?php
                    } else {
                    ?>
                        <button class="btn btn-success d-grid" onclick="changeAdminStatus(<?php echo $admin_fetch['admin_id']; ?>);" id="AdminstatusChangeButton<?php echo $admin_fetch['admin_id']; ?>">Activate</button>
                    <?php


                    }
                } else {

                    ?>


                    <button type="button" class="btn btn-primary position-relative">
                        My Account
                        <span class="position-absolute top-0 start-100 translate-middle p-2 bg-danger border border-light rounded-circle">
                            <span class="visually-hidden">New alerts</span>
                        </span>
                    </button>

                <?php

                }
                ?>




            </td>

        </tr>
<?php
    }
}
?>