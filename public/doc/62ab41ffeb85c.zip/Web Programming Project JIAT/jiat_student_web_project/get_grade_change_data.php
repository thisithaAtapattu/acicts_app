<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["admin"])) { //checkes if the session is set to show the content

    $admin_details = $_SESSION["admin"]; //gets the admin details from the session

    //addslashes function was used in case if the values has quotes
    $studentId=addslashes($_POST["studentId"]);


    $student_rs=connect::executer("SELECT * FROM `student` WHERE `id`='".$studentId."';");

    

    if($student_rs->num_rows==1){

        $student_fetch=$student_rs->fetch_assoc();

        $student_json;

        $student_json["name"]=$student_fetch["first_name"]." ".$student_fetch["last_name"];

        echo json_encode($student_json);
        


    }else{

        echo "Student not found!";


    }
    


}
?>