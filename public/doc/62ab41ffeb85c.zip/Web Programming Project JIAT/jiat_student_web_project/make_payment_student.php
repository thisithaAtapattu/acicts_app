<?php
session_start();
require "connection.php";

$date=new DateTime();
$timeZone= new DateTimeZone("Asia/Colombo");
$date->setTimezone($timeZone);
$current_date_time=$date->format("Y-m-d H:i:s");

if(isset($_SESSION["paying_student_id"])){


    connect::executer("INSERT INTO `enrollment_payments`(`date_time`,`student_id`) VALUES ('".$current_date_time."','".$_SESSION["paying_student_id"]."');");


    $_SESSION["isAccassible"]=true;
        

}




?>