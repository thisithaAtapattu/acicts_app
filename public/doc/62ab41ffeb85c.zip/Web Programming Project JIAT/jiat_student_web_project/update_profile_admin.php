<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if(isset($_SESSION["admin"])){//checks if the admin is singed in

    $admin_details = $_SESSION["admin"];

    // gets the first name, last name ,email and username sent by by the post method
    $first_name=addslashes($_POST["first_name"]);
    $last_name=addslashes($_POST["last_name"]);
    $email=addslashes($_POST["email"]);
    $username=addslashes($_POST["username"]);
    //The empty function was not used here since it considers the value 0 also as empty

    //If the values is empty or has only spaces this gets true

    if($first_name==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$first_name))) == 0){

        echo "Please enter the first name.";
     
     
     }else if($last_name==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$last_name))) == 0){
     
         echo "Please enter the last name.";
      
      
     }else if($email==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$email))) == 0){
     
        echo "Please enter the email.";
     
     
    }else if (!filter_var($email,FILTER_VALIDATE_EMAIL)){//if the email is in the correct format


        echo "Invalid email format!";


    }else if($username==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$username))) == 0){
     
        echo "Please enter the username.";
     
     
    }else{   //If the values is empty or has only spaces this gets false

        
   

        // echo sizeof($email_explode_at);


        connect::executer("UPDATE `admin` SET `first_name`='".$first_name."',`last_name`='".$last_name."',`username`='".$username."',`email`='".$email."' WHERE `id`='".$admin_details["id"]."';");//updates the databse with the updated data

        $_SESSION["admin"]=connect::executer("SELECT * FROM `admin` WHERE `id`='".$admin_details["id"]."';")->fetch_assoc();//reassignes the admin name with the newly updated data

        $json_details["full_name"]=$_SESSION["admin"]["first_name"]." ".$_SESSION["admin"]["last_name"];//assignes the newly updated first & last names to the array

        echo json_encode($json_details);//encodes the array as JSON
   

    }


}
?>