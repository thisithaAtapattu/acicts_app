<?php
session_start();//The function bellow creates a new session if there's no session & gets the current session if there is

unset($_SESSION["teacher"]);//unsets the values of the teacher key of the associative array assigned to $_SESSION variable


?>