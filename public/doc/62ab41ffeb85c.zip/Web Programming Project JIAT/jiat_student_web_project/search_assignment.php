<?php
session_start();
require "connection.php";

if (isset($_SESSION["teacher"])) {
    $teacher_details = $_SESSION["teacher"];

    $searchAssignment = strtolower(addslashes($_POST["searchAssignment"]));

 


    $assignment_rs = connect::executer("SELECT `assignment`.`id` AS `assignment_id`,`assignment`.`title`,`assignment`.`file_name`,`assignment`.`start_date`,`assignment`.`end_date`,`subject`.`name` AS `subject_name`,`grade`.`name` AS `grade_name` FROM `assignment` INNER JOIN `subject_has_grade` ON `assignment`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` WHERE `subject_has_grade`.`id`='" . $teacher_details["subject_has_grade_id"] . "' AND `assignment`.`status_id`='1' AND LOWER(`assignment`.`title`) LIKE '%".$searchAssignment."%' ORDER BY `assignment`.`start_date` DESC;");


    while ($assignment_fetch = $assignment_rs->fetch_assoc()) {
    ?>
        <tr>


            <td><?php echo $assignment_fetch["title"]; ?></td>
            <td><a class="button is-danger is-light" download="" href="<?php echo "doc/" . $assignment_fetch["file_name"]; ?>">Download Assignment</a></td>
            <td><?php echo "Grade " . $assignment_fetch["grade_name"] . " " . $assignment_fetch["subject_name"]; ?></td>
            <td><?php echo $assignment_fetch["start_date"]; ?></td>
            <td id="end_date<?php echo $assignment_fetch['assignment_id']; ?>"><?php echo $assignment_fetch["end_date"]; ?></td>
            <td><button class="btn btn-primary" onclick="openDeadlineUpdateModal(<?php echo $assignment_fetch['assignment_id']; ?>);">Change Deadline</button></td>
            <td><button class="btn btn-danger" onclick="deleteAssignment(<?php echo $assignment_fetch['assignment_id']; ?>);">Delete</button></td>



        </tr>
    <?php
    }
    
}
?>