<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div style="height:auto;padding:50px 50px 50px 50px;background-color:#edeff1"> <br>
<center><img src="https://upload.wikimedia.org/wikipedia/commons/5/5f/Emblem_of_Sri_Lanka.svg" style="width:50px;"/><h1>Ministry of Education </h1></center><br>       <center>  <div style="width:500px;height:auto;margin-top:0px;padding-bottom:80px;font-size:14px;background-color:white;text-align:center">
<br><br><center>    <h2>You were invited as a student.</h2><br>
<br>
<span style="">Username : </span>
<span >Thisitha</span>
<br>
<span style="">Password : </span>
<span >thisitha#123</span>
<br>
<span style="">Verification Code : </span>
<span >Thisitha</span>
<br>
<br>
<span style="">First log in link : </span>
<a href="http://localhost/jiat_student_web_project/manage-administration" style="text-align:center;color:hsl(217, 71%, 53%)	;" >
Click to Log In</a>
<br>
<span style="">Link after first log in : </span>
<a href="http://localhost/jiat_student_web_project/manage-administration" style="text-align:center;color:hsl(217, 71%, 53%)	;" >
Click to Log In</a>
</center>
</div>
</center>
</div>
</body>
</html>