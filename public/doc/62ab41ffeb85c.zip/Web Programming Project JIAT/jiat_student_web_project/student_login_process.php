<?php
//The function bellow creates a new session if there's no session & uses the current session
session_start();

//Required the connection file with the database connection
require "connection.php";


//All three values taken as post since request was sent from cleint side as post
//addslashes function was used in case if the values has quotes
$username=addslashes($_POST["username"]);
$password=addslashes($_POST["password"]);
$remember=addslashes($_POST["remember"]);


//The empty function was not used here since it considers the value 0 also as empty

//If the values is empty or has only spaces this gets true
if($username==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$username))) == 0){

   echo "Please enter the username.";


}else if($password==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$password))) == 0){

    echo "Please enter the password.";
 
 
}else{


   $date=new DateTime();
   $timeZone= new DateTimeZone("Asia/Colombo");
   $date->setTimezone($timeZone);
   $current_date_time=$date->format("Y-m-d H:i:s");

    // Search for the student in the database
    $user_result=connect::executer("SELECT * FROM `student` LEFT JOIN `student_account_access_code` ON `student_account_access_code`.`student_id`=`student`.`id` WHERE `username`='".$username."' AND `password`='".$password."' AND `status_id`='1';");


     if($user_result->num_rows==1){//if student exsists


      $user_fetch=$user_result->fetch_assoc();//converts the result set to associative array

      $_SESSION["paying_student_id"]= $user_fetch["id"];
      $_SESSION["isAccassible"]=true;

      $student_grading_rs=connect::executer("SELECT * FROM `student_grading` WHERE `id`='".$user_fetch["student_grading_id"]."';");


 

    $student_grading_fetch=$student_grading_rs->fetch_assoc();

    if($user_fetch["code"]!=""||$user_fetch["code"]!=null){


       echo "Account not verified!";


    }else{



    $eronollment_pay_rs=connect::executer("SELECT * FROM `enrollment_payments` WHERE `student_id`='".$user_fetch["id"]."';");

    

    if($eronollment_pay_rs->num_rows==0){

     
         

      $start_date = new DateTime($student_grading_fetch["graded_date_time"]);
      $since_start = $start_date->diff(new DateTime($current_date_time));


      

      if($since_start->days<30){

           

  
         echo "success-payment-must";//if logging in success

         $_SESSION["isAccassible"]=true;
         
       



      }else{

         $_SESSION["isAccassible"]=false;

         echo "trial is over";


      }



                  

    }else{


 

  



     
         

      $start_date = new DateTime($student_grading_fetch["graded_date_time"]);
      $since_start = $start_date->diff(new DateTime($current_date_time));
 

 


      if($since_start->days<30){


         $en_pay_rs=connect::executer("SELECT * FROM `enrollment_payments` WHERE `student_id`='".$user_fetch["id"]."' ORDER BY `date_time` DESC LIMIT 1 OFFSET 0;");

         $en_pay_fetch= $en_pay_rs->fetch_assoc();


    

   

          $total_date_explode=explode("-",explode(" ",$en_pay_fetch["date_time"])[0]);

          $total_time_explode=explode(":",explode(" ",$en_pay_fetch["date_time"])[1]);

          $total_payment_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];

          $total_date_explode=explode("-",explode(" ",$student_grading_fetch["graded_date_time"])[0]);

          $total_time_explode=explode(":",explode(" ",$student_grading_fetch["graded_date_time"])[1]);

          $total_grade_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];

         
          if($total_payment_datetime_explode<$total_grade_datetime_explode){

     
                  

  
         echo "success-payment-must";//if logging in success
         $_SESSION["isAccassible"]=true;



          }else if($total_payment_datetime_explode>=$total_grade_datetime_explode){


            if($remember=="true"){//if remember checkbox is checked

         
               $user_code=uniqid();//first assign $user_code variable to a newly genarated user code
           
               $code_result=connect::executer("SELECT * FROM `student_code` WHERE `student_id`='".$user_fetch["id"]."';");//Search for the student code in the database
           
                if($code_result->num_rows==0){//if code not exsist
           
           
           
                  connect::executer("INSERT INTO `student_code`(`student_id`,`code`) VALUES ('".$user_fetch["id"]."','".$user_code."');");//insert a new code
           
           
           
           
              
           
           
           
               }else if($code_result->num_rows==1) {//if code exsist
           
                $user_code=$code_result->fetch_assoc()["code"];//assignes the $user_code variable to the exsisting code
           
           
               }
           
           
                    setcookie("remember_cookie_student",$user_code,time()+(60*60*24*365*1000)); //set a cookie with the unique code as the data        
           
           
               }else{//if the remember checkbox is not checked
           
                    
                   setcookie("remember_cookie_student","",time());
           
                
               }
           
                $_SESSION["student"]=$user_fetch;//assigns user details to the session named student
           
                  echo "success";//if logging in success
                  $_SESSION["isAccassible"]=true;

            
          }


          
         // echo $exploded_pay[0];


         
       



      }else{

         $en_pay_rs=connect::executer("SELECT * FROM `enrollment_payments` WHERE `student_id`='".$user_fetch["id"]."' ORDER BY `date_time` DESC LIMIT 1 OFFSET 0;");

         $en_pay_fetch= $en_pay_rs->fetch_assoc();



         $total_date_explode=explode("-",explode(" ",$en_pay_fetch["date_time"])[0]);

         $total_time_explode=explode(":",explode(" ",$en_pay_fetch["date_time"])[1]);

         $total_payment_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];

         $total_date_explode=explode("-",explode(" ",$student_grading_fetch["graded_date_time"])[0]);

         $total_time_explode=explode(":",explode(" ",$student_grading_fetch["graded_date_time"])[1]);

         $total_grade_datetime_explode=$total_date_explode[0].$total_date_explode[1].$total_date_explode[2].$total_time_explode[0].$total_time_explode[1].$total_time_explode[2];


         
         if($total_payment_datetime_explode<$total_grade_datetime_explode){

     
           
          
               //$_SESSION["student"]=$user_fetch;//assigns user details to the session named student
          
                 echo "trial is over";//if logging in success

                 $_SESSION["isAccassible"]=false;
        
        
        
                  }else if($total_payment_datetime_explode>=$total_grade_datetime_explode){
        
        
                    if($remember=="true"){//if remember checkbox is checked
        
                 
                       $user_code=uniqid();//first assign $user_code variable to a newly genarated user code
                   
                       $code_result=connect::executer("SELECT * FROM `student_code` WHERE `student_id`='".$user_fetch["id"]."';");//Search for the student code in the database
                   
                        if($code_result->num_rows==0){//if code not exsist
                   
                   
                   
                          connect::executer("INSERT INTO `student_code`(`student_id`,`code`) VALUES ('".$user_fetch["id"]."','".$user_code."');");//insert a new code
                   
                   
                   
                   
                      
                   
                   
                   
                       }else if($code_result->num_rows==1) {//if code exsist
                   
                        $user_code=$code_result->fetch_assoc()["code"];//assignes the $user_code variable to the exsisting code
                   
                   
                       }
                   
                   
                            setcookie("remember_cookie_student",$user_code,time()+(60*60*24*365*1000)); //set a cookie with the unique code as the data        
                   
                   
                       }else{//if the remember checkbox is not checked
                   
                            
                           setcookie("remember_cookie_student","",time());
                   
                        
                       }
                   
                        $_SESSION["student"]=$user_fetch;//assigns user details to the session named student
                   
                          echo "success";//if logging in success
                          $_SESSION["isAccassible"]=true;
        
                    
                  }
        

      


      }




    }


   


      

}

     }else{//if user not found

          echo "Account not found!";


     }




}
?>