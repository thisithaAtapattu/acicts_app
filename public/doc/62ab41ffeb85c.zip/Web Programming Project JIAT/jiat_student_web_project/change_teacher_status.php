<?php
session_start();
require "connection.php";
if(isset($_SESSION["admin"])){



  $teacherId=addslashes($_POST["teacherId"]);




    $teacher_rs=connect::executer("SELECT * FROM `teacher` WHERE `id`='".$teacherId."';");


    if($teacher_rs->num_rows==1){


        $teacher_fetch=$teacher_rs->fetch_assoc();


        if(connect::executer("SELECT * FROM `teacher_account_access_code` WHERE `teacher_id`='".$teacherId."';")->num_rows==0){

        

        if($teacher_fetch["status_id"]==1){

            connect::executer("UPDATE `teacher` SET `status_id`='2' WHERE `id`='".$teacherId."';");

            echo "Blocked";

        }else{

            connect::executer("UPDATE `teacher` SET `status_id`='1' WHERE `id`='".$teacherId."';");

            echo "Active";


        }

        }else{

           echo "This teacher is not verified.";

        }



    }else{


        echo "Teacher not found.";


    }

  

  


}



?>