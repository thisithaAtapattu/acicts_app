<?php
session_start();
require "connection.php";
if(isset($_SESSION["admin"])){



  $studentId=addslashes($_POST["studentId"]);




    $student_rs=connect::executer("SELECT * FROM `student` WHERE `id`='".$studentId."';");


    if($student_rs->num_rows==1){


        $student_fetch=$student_rs->fetch_assoc();


        if(connect::executer("SELECT * FROM `student_account_access_code` WHERE `student_id`='".$studentId."';")->num_rows==0){

        

        if($student_fetch["status_id"]==1){

            connect::executer("UPDATE `student` SET `status_id`='2' WHERE `id`='".$studentId."';");

            echo "Blocked";

        }else{

            connect::executer("UPDATE `student` SET `status_id`='1' WHERE `id`='".$studentId."';");

            echo "Active";


        }

        }else{

           echo "This student is not verified.";

        }



    }else{


        echo "Student not found.";


    }

  

  


}



?>