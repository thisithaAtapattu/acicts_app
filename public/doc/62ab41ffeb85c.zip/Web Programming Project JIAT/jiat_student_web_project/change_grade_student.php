<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["admin"])) { //checkes if the session is set to show the content

    $admin_details = $_SESSION["admin"]; //gets the admin details from the session

    //addslashes function was used in case if the values has quotes
    $studentId=addslashes($_POST["studentId"]);
    $gradeId=addslashes($_POST["gradeId"]);
    

    if(!empty($gradeId)){

    $student_rs=connect::executer("SELECT * FROM `student` WHERE `id`='".$studentId."';");
    $grade_rs=connect::executer("SELECT * FROM `grade` WHERE `id`='".$gradeId."';");
    

    if($student_rs->num_rows!=1){

        echo "Student not found!";
        

    }if($grade_rs->num_rows!=1){

        echo "Grade not found!";
        

    }else{

       

        $student_fetch=$student_rs->fetch_assoc();

        connect::executer("UPDATE `student_grading` SET `grade_id`='".$gradeId."' WHERE `id`='".$student_fetch["student_grading_id"]."';");

        $grading_rs=connect::executer("SELECT * FROM `student_grading` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` WHERE `student_grading`.`id`='".$student_fetch["student_grading_id"]."';");

        echo $grading_rs->fetch_assoc()["name"];



    }


    }else{

      echo "Please select a grade.";

    }

    

}
?>