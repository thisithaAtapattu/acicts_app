<?php
session_start();
require "connection.php";

if(isset($_SESSION["admin"])){

 $subject=addslashes($_POST["subject"]);
 $grade=addslashes($_POST["grade"]);

 if(empty($subject)){

      echo "Please select the subject.";


 }else if(empty($grade)){

    echo "Please select the grade.";


}else{

   $subject_rs=connect::executer("SELECT * FROM `subject` WHERE `id`='".$subject."';");
   $grade_rs=connect::executer("SELECT * FROM `grade` WHERE `id`='".$grade."';");


   if($subject_rs->num_rows!=1){

       echo "Invalid subject!";


   }else if($grade_rs->num_rows!=1){

      echo "Invalid grade!";


    
   }else{

     if(connect::executer("SELECT * FROM `subject_has_grade` WHERE `subject_id`='".$subject."' AND `grade_id`='".$grade."';")->num_rows==0){

     connect::executer("INSERT INTO `subject_has_grade`(`subject_id`,`grade_id`) VALUES ('".$subject."', '".$grade."');");

     echo "success";

    }else{

      echo "This mapping already exsists.";

    }
   }






}




}




?>