<?php
session_start();//The function bellow creates a new session if there's no session & gets the current session if there is

unset($_SESSION["admin"]);//unsets the values of the admin key of the associative array assigned to $_SESSION variable


?>