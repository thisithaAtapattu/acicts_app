<?php
//The function bellow creates a new session if there's no session & gets the current session if there is
session_start();

require "connection.php"; //Required the connection file with the database connection



if (!isset($_SESSION["student"])) { //To show the login content checks if the session is not set



?>
    <!DOCTYPE html>
    <html class="default-bg">

    <head>


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ministry of Education | Student Login</title>
        <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
        <link rel="stylesheet" href="bootstrap.css" />

        <link rel="stylesheet" href="style.css" /><!-- My Css File -->
        <link rel="stylesheet" href="font/bootstrap-icons.css">

        <link rel="stylesheet" href="bulma.css">


        <style>
            #PopupModel {
                width: 60%;
            }

            .modal {}

            .vertical-alignment-helper {
                display: table;
                height: 100%;
                width: 100%;
            }

            .vertical-align-center {
                /*/To center vertically*/
                display: table-cell;
                vertical-align: middle;
            }

            .modal-content {
                /*Bootstrap sets the size of the modal in the modal-dialog class, we need to inherit it*/
                width: inherit;
                height: inherit;
                /*To center horizontally*/

            }
        </style>


    </head>

    <body>



        <div class="container-fluid default-bg">

            <div class="row">



                <div class="col-12">


                    <div class="row">


                        <div class="col-12 col-lg-6 mt-5 offset-lg-3">



                            <div class="row  mt-5">



                                <!-- Login Card Start -->

                                <div class="card ">
                                    <div class="card-content text-center">
                                        <img src="img/education-illustration.svg">
                                        <h1 class="title mt-2">STUDENT LOGIN</h1>
                                        <?php


                                        //username and password variables
                                        $username = "";
                                        $password = "";


                                        if (isset($_COOKIE["remember_cookie_student"])) { //check if the remember cookie cookie is set





                                            $student_result = connect::executer("SELECT * FROM `student_code` INNER JOIN `student` ON `student_code`.`student_id`=`student`.`id` WHERE `student_code`.`code`='" . $_COOKIE["remember_cookie_student"] . "';"); //This JOIN query let's us get the student details and check if the code exsists at once


                                            if ($student_result->num_rows == 1) { //if code exsists in the database

                                                $student_fetch = $student_result->fetch_assoc(); //coverts the resulset from the JOIN query to an associative array

                                                //assigns $username & $password variables to the username & password taken by the database
                                                $username = $student_fetch["username"];
                                                $password = $student_fetch["password"];
                                            }
                                        }




                                        ?>
                                        <div class="content col-12  mt-3">
                                            <div class="field">
                                                <p class="control has-icons-left has-icons-right">
                                                    <input class="input" type="text" placeholder="Username" id="username" value="<?php echo $username; //The value of the $username variable is set as the value of the username text field
                                                                                                                                    ?>" />
                                                    <span class="icon is-small is-left">
                                                        <i class="bi bi-person-fill"></i>
                                                    </span>
                                                    <span class="icon is-small is-right">
                                                        <i class="fas fa-check"></i>
                                                    </span>
                                                </p>
                                            </div>
                                            <div class="field">
                                                <p class="control has-icons-left">
                                                    <input class="input" type="password" placeholder="Password" id="password" value="<?php echo $password; //The value of the $password variable is set as the value of the password text field
                                                                                                                                        ?>" />
                                                    <span class="icon is-small is-left">
                                                        <i class="bi bi-lock-fill"></i>
                                                    </span>
                                                </p>


                                            </div>

                                            <?php

                                            if (isset($_GET["login_status"]) && $_GET["login_status"] == "verification") {
                                            ?>
                                                <div class="field">
                                                    <p class="control has-icons-left">
                                                        <input class="input" type="text" placeholder="Verification Code" id="verification_code" />
                                                        <span class="icon is-small is-left">
                                                            <i class="bi bi-braces-asterisk"></i>
                                                        </span>
                                                    </p>


                                                </div>
                                            <?php



                                            }


                                            ?>

                                            <div class="col-12">
                                                <div class="row">

                                                    <div class=" col-6 d-inline">
                                                        <div class="form-check">


                                                            <input class="form-check-input " type="checkbox" value="" id="remember" <?php

                                                                                                                                    //The empty function was not used here since it considers the value 0 also as empty

                                                                                                                                    if ($username != "" && $password != "") { //checks if the $username and $password is not empty since only if the value is not empy the remember me option works


                                                                                                                                    ?>checked="" <?php
                                                                                                                                                }

                                                                                                                                                    ?> />

                                                            <label class="form-check-label  me-5" for="remember">
                                                                Remember me &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                                            </label>

                                                        </div>

                                                    </div>
                                                    <!-- <div class=" col-6 d-inline ">

                                                        <a href="#" class="link-dark text-decoration-underline" onclick="notDeveloped();">Forgot Password?</a>


                                                    </div> -->


                                                </div>


                                            </div>




                                            <div class="col-12 mt-sm-2">





                                                <?php

                                                if (isset($_GET["login_status"]) && $_GET["login_status"] == "verification") {
                                                ?>

                                                    <button class="button is-danger d-grid col-12" onclick="verifyLogInStudent();">Log in</button>
                                                <?php



                                                } else {

                                                ?>

                                                    <button class="button is-danger d-grid col-12" onclick="logInStudent();">Log in</button>

                                                <?php


                                                }


                                                ?>
                                            </div>

                                        </div>


                                    </div>

                                </div>

                                <!-- Login Card End -->
                            </div>

                        </div>
                        <!-- Button trigger modal -->
                        <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Launch demo modal
                        </button> -->

                        <!-- Modal -->


                        <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 10000;">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Pay Enrollment Fee of $1.39</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p class="text-danger fw-bold" id="payment_message_viewer">You're using the 1 month free trial version. Make a payment to keep your account activated throughout your new grade.</p>

                                        <div id="paypal-button-container" class="mt-5">




                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary" onclick="studentLogInFinal();" id="log_continue">Continue Login</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>



                </div>










            </div>


        </div>

        <script src="https://www.paypal.com/sdk/js?client-id=AWSzsonWWyjl0I0oGYFkaXn_Pb7hTOEbVHtdlRqD2kldNYIaUUX6jina6wJNioo2dmQtOdCm-bCii6h7&currency=USD"></script>

        <!-- My Javascript file -->
        <script src="script.js"></script>
        <!-- Sweetalreat Javascript File -->
        <script src="sweetalert.min.js"></script>
        <script src="bootstrap.bundle.js"></script>


        <script>
            //This function displays payment buttons on your web page.


            // paypal.Buttons({

            //     style: {
            //         layout: 'vertical',
            //         color: 'blue',
            //         shape: 'rect',
            //         label: 'paypal'
            //     }

            // })

            // paypal.Buttons({
            //     createSubscription: function(data, actions) {
            //         if (updatedSubscription && (status === 'ACTIVE' || status === 'SUSPENDED')) {
            //             return actions.subscription.revise(subscriptionId, {
            //                 'shipping_amount': {
            //                     'currency_code': 'USD',
            //                     'value': '10.00'
            //                 }
            //             });
            //         } else {
            //             return actions.subscription.create({
            //                 'plan_id': 'P-2UF78835G6983425GLSM44MA'
            //             });
            //         }
            //     },

            //     onApprove: function(data, actions) {
            //         alert('You have successfully created subscription ' + data.subscriptionID);
            //     }
            // }).render('#paypal-button-container');
        </script>




    </body>









    </html>
<?php

} else { //if the session is set
?>
    <script>
        window.location = "student";
    </script>
<?php
}

?>