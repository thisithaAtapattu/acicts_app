<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["admin"])) { //checkes if the session is set to show the content

    $admin_details = $_SESSION["admin"]; //gets the admin details from the session

    //addslashes function was used in case if the values has quotes
    $studentId=addslashes($_POST["studentId"]);

    $date=new DateTime();
    $timeZone= new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time=$date->format("Y-m-d H:i:s");


    $student_rs=connect::executer("SELECT *  FROM `student` INNER JOIN `student_grading` ON `student`.`student_grading_id`=`student_grading`.`id` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` WHERE `student`.`id`='".$studentId."';");

   $studentJson;

    if($student_rs->num_rows==1){

        $student_fetch=$student_rs->fetch_assoc();

        if($student_fetch["name"]!=13){

        $grade_rs=connect::executer("SELECT * FROM `grade` WHERE `name`='".($student_fetch["name"]+1)."';");

        $grade_fetch=$grade_rs->fetch_assoc();

      
         connect::executer("UPDATE `student_grading` SET `grade_id`='".$grade_fetch["id"]."',`graded_date_time`='".$current_date_time."' WHERE `id`='".$student_fetch["student_grading_id"]."';");

         $grading_rs=connect::executer("SELECT * FROM `student_grading` INNER JOIN `grade` ON `student_grading`.`grade_id`=`grade`.`id` WHERE `student_grading`.`id`='".$student_fetch["student_grading_id"]."';");

         echo $grading_rs->fetch_assoc()["name"];

    }else{

        echo "Grade 13 students can't be passed further.";

    }

    }else{

       echo "Student not found!";

    }
   


}
?>