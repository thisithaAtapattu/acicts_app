<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["admin"])) { //checkes if the session is set to show the content

    $admin_details = $_SESSION["admin"]; //gets the admin details from the session



    $date = new DateTime();
    $timeZone = new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time = $date->format("Y-m-d H:i:s");

    $current_year = $date->format("Y");

    $current_date = $date->format("Y-m-d");

?>
    <!DOCTYPE html>
    <html>

    <head>


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ministry of Education</title>
        <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
        <link rel="stylesheet" href="bootstrap.css" />

        <link rel="stylesheet" href="style.css" />
        <link rel="stylesheet" href="font/bootstrap-icons.css">

        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

        <link rel="stylesheet" href="bulma.css" />


    </head>

    <body>



        <div class="container-fluid ">

            <div class="row">

                <div class="col-12">

                    <div class="row">



                        <div class="col-md-4 pb-5" style="background-color: hsl(0, 0%, 96%)	;">

                            <!-- Profile section with logout -->

                            <div class="row ">









                                <div class="col-12 d-flex flex-column align-items-center mt-2">


                                    <div class="row  ">

                                        <?php

                                        $profile_pic_result = connect::executer("SELECT CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img` FROM `admin_profile_pic` INNER JOIN `image` ON `admin_profile_pic`.`image_id`=`image`.`id` INNER JOIN`image_type` ON  `image`.`image_type_id`=`image_type`.`id` WHERE `admin_profile_pic`.`admin_id`='" . addslashes($admin_details["id"]) . "';"); //searches for the profile picture in the database

                                        if ($profile_pic_result->num_rows == 1) { //if a profile picture exsists


                                            $profile_pic_fetch = $profile_pic_result->fetch_assoc(); //covert's the profile picture result set to an associative array

                                        ?>

                                            <img src="<?php echo "profiles/" . $profile_pic_fetch["profile_img"]; //shows the profile picture 
                                                        ?>" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php

                                        } else { //if a profile picture does not exsist
                                        ?>

                                            <!-- Shows the default profile picture -->
                                            <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php



                                        }
                                        ?>

                                    </div>




                                </div>


















                            </div>



                            <div class="row">


                                <div class="col-12 text-center">


                                    <div class="row">

                                        <p class=" fw-bold" id="name_viewer"><?php echo $admin_details["first_name"] . " " . $admin_details["last_name"] //display the first and last name of the user taken by the session; 
                                                                                ?></p>




                                        <div>

                                            <h6 class=" fw-bold has-text-link	" style="font-size:10px;">ADMIN</h6>


                                        </div>







                                    </div>




                                </div>


                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-5 offset-5 mt-1">


                                            <div class="row">

                                                <button class="btn btn-danger col-5" onclick="logOutAdmin();">Log out</button>

                                            </div>



                                        </div>





                                    </div>



                                </div>





                            </div>

                            <!-- Profile section with logout -->


                            <hr class="col-12 bg-dark" />

                            <!-- Navigation section -->

                            <div class="row px-5">


                                <div class="col-12 set-border-dash pt-2 pb-2" onclick="goToAmin();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-circle"></i> Update Profile</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToCheckResults();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-info"><i class="bi bi-newspaper"></i> Check Results</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageAmin();">


                                    <div class="row">

                                        <p class=" fw-bold  has-text-grey-lighter "><i class="bi bi-person-square"></i> Manage Administration</p>












                                    </div>




                                </div>



                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageStudents();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-lines-fill"></i> Manage Students</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageTeachers();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-workspace"></i> Manage Teachers</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageAcademicOfficers();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-video2"></i> Manage Academic Officers</p>












                                    </div>




                                </div>

                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToManageSyllabus();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-body-text"></i> Manage Syllabus</p>












                                    </div>




                                </div>










                            </div>


                            <!-- Navigation section -->




                        </div>



                        <!-- Assignment results section -->



                        <div class="col-md-8 ">

                            <div class="row edu-background-dashboard ms-2">




                            </div>

                            <div class="row">

                                <div class="col-md-5 mt-5  ">

                                    <div class="row px-3 px-md-0">

                                        <input type="text" class="form-control" placeholder="Search..." id="searchResults" onkeyup="searchResults();" />


                                    </div>



                                </div>


                            </div>

                            <div class=" row">

                                <div class="col-12 col-md-12 mt-5">





                                </div>


                                <div class="col-md-12 mt-5  ">







                                    <div class="col-12 mt-3">
                                        <div class="row overflow-scroll">


                                            <table class="table overflow-scroll">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Student First Name</th>
                                                        <th scope="col">Student Last Name</th>
                                                        <th scope="col">Student Email</th>
                                                        <th scope="col">Assignment Title</th>
                                                        <th scope="col">Subject Area</th>



                                                        <th scope="col">Start Date</th>
                                                        <th scope="col">End Date</th>
                                                        <th scope="col">Marks</th>



                                                    </tr>
                                                </thead>
                                                <tbody id="results_load_area">
                                                    <?php

                                                    $assignment_rs = connect::executer("SELECT `assignment_has_student`.`id` AS `assignment_has_student_id`,`assignment`.`title`,`assignment`.`file_name` AS `assignment_file_name`,`assignment`.`start_date`,`assignment`.`end_date`,`assignment_has_student`.`file_name` AS `student_file_name`,`student`.`first_name`,`student`.`last_name`,`subject`.`name` AS `subject_name`, `grade`.`name` AS `grade_name`,`student`.`email`,`assignment_marks`.`mark` FROM `assignment_has_student` INNER JOIN `assignment` ON `assignment_has_student`.`assignment_id`=`assignment`.`id` INNER JOIN `student` ON `assignment_has_student`.`student_id`=`student`.`id` INNER JOIN `subject_has_grade` ON `assignment`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` LEFT JOIN `assignment_marks` ON `assignment_marks`.`assignment_has_student_id`=`assignment_has_student`.`id` WHERE  `assignment`.`end_date`<'" . $current_date . "' AND `assignment_marks`.`status_id`='1' ORDER BY `assignment`.`start_date` DESC;");

                                                    while ($assignment_fetch = $assignment_rs->fetch_assoc()) {


                                                        if ($assignment_fetch["mark"] != "" && $assignment_fetch["mark"] != null) {
                                                    ?>
                                                            <tr>

                                                                <td><?php echo $assignment_fetch["first_name"]  ?></td>
                                                                <td><?php echo $assignment_fetch["last_name"]  ?></td>
                                                                <td><?php echo $assignment_fetch["email"]  ?></td>
                                                                <td><?php echo $assignment_fetch["title"]  ?></td>
                                                                <td><?php echo "Grade " . $assignment_fetch["grade_name"] . " " . $assignment_fetch["subject_name"]  ?></td>

                                                                <td><?php echo $assignment_fetch["start_date"]  ?></td>
                                                                <td><?php echo $assignment_fetch["end_date"]  ?></td>
                                                                <td><?php echo $assignment_fetch["mark"]  ?></td>



                                                            </tr>

                                                    <?php
                                                        }
                                                    }

                                                    ?>

                                                </tbody>
                                            </table>




                                        </div>




                                    </div>



                                </div>






                            </div>








                        </div>


                        <!-- Assignment results section -->









                    </div>


                </div>




            </div>








        </div>









        <script src="script.js"></script> <!-- My js file -->
        <script>
            checkStatusAdmin(); //this function checks the status of the admin and logs out the admin if the admin is blocked
        </script>
        <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script> <!-- JQuery js file -->
        <script src="jquery-3.6.0.min.js"></script> <!-- JQuery js file -->
        <script src="sweetalert.min.js"></script><!-- SweetAlert js file -->
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script><!-- Toastify JS file -->
    </body>









    </html>
<?php

} else { //if the session is not set


?>
    <script>
        window.location = "admin-login";
    </script>
<?php


}

?>