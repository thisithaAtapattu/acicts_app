<?php
//The function bellow creates a new session if there's no session & gets the current session if there is
session_start();

require "connection.php";//Required the connection file with the database connection



if(!isset($_SESSION["admin"])){//To show the login content checks if the session is not set



?>
<!DOCTYPE html>
<html class="default-bg">

<head>


    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Ministry of Education | Admin Login</title>
    <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
    <link rel="stylesheet" href="bootstrap.css" />

    <link rel="stylesheet" href="style.css" /><!-- My Css File -->
    <link rel="stylesheet" href="font/bootstrap-icons.css">

    <link rel="stylesheet" href="bulma.css">


</head>

<body>



    <div class="container-fluid default-bg">

        <div class="row">



            <div class="col-12">


                <div class="row">


                    <div class="col-12 col-lg-6 mt-5 offset-lg-3">



                        <div class="row  mt-5">



                            <!-- Login Card Start -->

                            <div class="card ">
                                <div class="card-content text-center">
                                    <img src="img/education-illustration.svg">
                                    <h1 class="title mt-2">ADMIN LOGIN</h1>
                                    <?php


                                    //username and password variables
                                    $username = "";
                                    $password = "";


                                    if (isset($_COOKIE["remember_cookie"])) { //check if the remember cookie cookie is set





                                        $admin_result = connect::executer("SELECT * FROM `admin_code` INNER JOIN `admin` ON `admin_code`.`admin_id`=`admin`.`id` WHERE `admin_code`.`code`='" . $_COOKIE["remember_cookie"] . "';"); //This JOIN query let's us get the admin details and check if the code exsists at once


                                        if ($admin_result->num_rows == 1) { //if code exsists in the database

                                            $admin_fetch = $admin_result->fetch_assoc(); //coverts the resulset from the JOIN query to an associative array

                                            //assigns $username & $password variables to the username & password taken by the database
                                            $username = $admin_fetch["username"];
                                            $password = $admin_fetch["password"];
                                        }
                                    }




                                    ?>
                                    <div class="content col-12  mt-3">
                                        <div class="field">
                                            <p class="control has-icons-left has-icons-right">
                                                <input class="input" type="text" placeholder="Username"  id="username" value="<?php echo $username; //The value of the $username variable is set as the value of the username text field
                                                                                                                                ?>" />
                                                <span class="icon is-small is-left">
                                                    <i class="bi bi-person-fill"></i>
                                                </span>
                                                <span class="icon is-small is-right">
                                                    <i class="fas fa-check"></i>
                                                </span>
                                            </p>
                                        </div>
                                        <div class="field">
                                            <p class="control has-icons-left">
                                                <input class="input" type="password" placeholder="Password"  id="password" value="<?php echo $password; //The value of the $password variable is set as the value of the password text field
                                                                                                                                    ?>" />
                                                <span class="icon is-small is-left">
                                                    <i class="bi bi-lock-fill"></i>
                                                </span>
                                            </p>


                                        </div>

                                        <div class="col-12">
                                            <div class="row">

                                                <div class=" col-6 d-inline">
                                                    <div class="form-check">


                                                        <input class="form-check-input " type="checkbox" value="" id="remember" <?php

                                                                                                                                //The empty function was not used here since it considers the value 0 also as empty

                                                                                                                                if ($username != "" && $password != "") { //checks if the $username and $password is not empty since only if the value is not empy the remember me option works


                                                                                                                                ?>checked="" <?php
                                                                                                                                            }

                                                                                                                                                ?> />

                                                        <label class="form-check-label  me-5" for="remember">
                                                            Remember me &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                                        </label>

                                                    </div>

                                                </div>
                                                <!-- <div class=" col-6 d-inline ">

                                                    <a href="#" class="link-dark text-decoration-underline" onclick="notDeveloped();">Forgot Password?</a>


                                                </div> -->


                                            </div>


                                        </div>




                                        <div class="col-12 mt-sm-2">





                                            <button class="button is-danger d-grid col-12" onclick="logInAdmin();">Log in</button>
                                        </div>

                                    </div>


                                </div>

                            </div>

                            <!-- Login Card End -->
                        </div>

                    </div>


                </div>



            </div>



        </div>


    </div>

    <!-- My Javascript file -->
    <script src="script.js"></script>
    <!-- Sweetalreat Javascript File -->
    <script src="sweetalert.min.js"></script>

</body>









</html>
<?php

}else{//if the session is set
?>
<script>window.location="admin";</script>
<?php
}

?>