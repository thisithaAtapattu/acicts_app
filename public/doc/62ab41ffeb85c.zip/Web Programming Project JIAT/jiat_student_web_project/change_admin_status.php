<?php
session_start();
require "connection.php";
if(isset($_SESSION["admin"])){

  $admin_details = $_SESSION["admin"];

  $adminId=addslashes($_POST["adminId"]);

  if($admin_details["id"]==$adminId){

      echo "You aren't allowed to change your own account's status.";


  }else{


    $admin_rs=connect::executer("SELECT * FROM `admin` WHERE `id`='".$adminId."';");


    if($admin_rs->num_rows==1){


        $admin_fetch=$admin_rs->fetch_assoc();

        

        if($admin_fetch["status_id"]==1){

            connect::executer("UPDATE `admin` SET `status_id`='2' WHERE `id`='".$adminId."';");

            echo "Blocked";

        }else{

            connect::executer("UPDATE `admin` SET `status_id`='1' WHERE `id`='".$adminId."';");

            echo "Active";


        }

        



    }else{


        echo "Admin not found.";


    }

    
  }

  

  


}



?>