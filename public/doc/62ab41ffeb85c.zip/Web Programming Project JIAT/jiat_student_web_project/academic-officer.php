<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["academic_officer"])) { //checkes if the session is set to show the content

    $academic_officer_details = $_SESSION["academic_officer"]; //gets the academic_officer details from the session

?>
    <!DOCTYPE html>
    <html>

    <head>


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ministry of Education</title>
        <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
        <link rel="stylesheet" href="bootstrap.css" />

        <link rel="stylesheet" href="style.css" /><!-- My Css File -->
        <link rel="stylesheet" href="font/bootstrap-icons.css">

        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

        <link rel="stylesheet" href="bulma.css" />


    </head>

    <body>



        <div class="container-fluid ">

            <div class="row">

                <div class="col-12">

                    <div class="row">



                        <div class="col-md-4 pb-5" style="background-color: hsl(0, 0%, 96%)	;">

                            <!-- Profile section with logout -->

                            <div class="row ">









                                <div class="col-12 d-flex flex-column align-items-center mt-2">


                                    <div class="row  ">

                                        <?php

                                        $profile_pic_result = connect::executer("SELECT CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img` FROM `academic_officer_profile_pic` INNER JOIN `image` ON `academic_officer_profile_pic`.`image_id`=`image`.`id` INNER JOIN`image_type` ON  `image`.`image_type_id`=`image_type`.`id` WHERE `academic_officer_profile_pic`.`academic_officer_id`='" . addslashes($academic_officer_details["id"]) . "';"); //searches for the profile picture in the database

                                        if ($profile_pic_result->num_rows == 1) { //if a profile picture exsists


                                            $profile_pic_fetch = $profile_pic_result->fetch_assoc(); //covert's the profile picture result set to an associative array

                                        ?>

                                            <img src="<?php echo "profiles/" . $profile_pic_fetch["profile_img"]; //shows the profile picture 
                                                        ?>" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php

                                        } else { //if a profile picture does not exsist
                                        ?>

                                            <!-- Shows the default profile picture -->
                                            <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php



                                        }
                                        ?>

                                    </div>




                                </div>













                                <div class="col-6 offset-3 mt-2">

                                    <div class="row">

                                        <input type="file" id="profile_pic" class="d-none" />

                                        <?php

                                        if ($profile_pic_result->num_rows == 0) { //if a profile picture exsists

                                        ?>

                                            <label class="button is-info d-grid" for="profile_pic" onclick="previewProfileAcademicOfficer();" id="profile_pic_selector_button">Upload Profile Picture</label>


                                        <?php
                                        } else if ($profile_pic_result->num_rows == 1) { //if a profile picture does not exsist

                                        ?>

                                            <label class="button is-info d-grid" for="profile_pic" onclick="previewProfileAcademicOfficer();" id="profile_pic_selector_button">Update Profile Picture</label>


                                        <?php



                                        }


                                        ?>


                                    </div>


                                </div>






                            </div>



                            <div class="row">


                                <div class="col-12 text-center">


                                    <div class="row">

                                        <p class=" fw-bold" id="name_viewer"><?php echo $academic_officer_details["first_name"] . " " . $academic_officer_details["last_name"] //display the first and last name of the user taken by the session; 
                                                                                ?></p>




                                        <div>

                                            <h6 class=" fw-bold has-text-link	" style="font-size:10px;">ACADEMIC OFFICER</h6>


                                        </div>







                                    </div>




                                </div>


                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-5 offset-5 mt-1">


                                            <div class="row">

                                                <button class="btn btn-danger col-5" onclick="logOutAcademicOfficer();">Log out</button>

                                            </div>



                                        </div>





                                    </div>



                                </div>





                            </div>

                            <!-- Profile section with logout -->


                            <hr class="col-12 bg-dark" />

                            <!-- Navigation section -->

                            <div class="row px-5">


                                <div class="col-12 set-border-dash pt-2 pb-2">


                                    <div class="row">

                                        <p class=" fw-bold has-text-info"><i class="bi bi-person-circle"></i> Update Profile</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToMarkManagement();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-newspaper"></i> Mark Management</p>












                                    </div>




                                </div>


                             



                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToAddStudents();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-lines-fill"></i> Add Students</p>












                                    </div>




                                </div>


                            









                            </div>


                            <!-- Navigation section -->




                        </div>



                        <!-- Update profile section -->

                        <div class="col-md-6 ">


                            <div class="row edu-background-dashboard ms-2">




                            </div>

                            <div class=" row">




                                <div class="offset-md-2 ">

                                    <div class="row">

                                        <h1 class="fs-1 fw-bold has-text-info text-center">Update Profile</h1>


                                    </div>



                                    <!-- All the details are taken through the session -->

                                    <div class="row mt-5 ms-md-3">



                                        <div class="col-6 ">



                                            <input class="input is-info mt-5" type="text" placeholder="First Name" value="<?php echo $academic_officer_details["first_name"]; ?>" id="first_name_update">







                                        </div>

                                        <div class="col-6 ">



                                            <input class="input is-info mt-5" type="text" placeholder="Last Name" value="<?php echo $academic_officer_details["last_name"]; ?>" id="last_name_update">









                                        </div>

                                        <div class="col-12">





                                            <input class="input is-info mt-5 d-grid" type="text" placeholder="Email" value="<?php echo $academic_officer_details["email"]; ?>" id="email_update">




                                        </div>


                                        <div class="col-12">





                                            <input class="input is-info mt-5 d-grid" type="text" placeholder="Username" value="<?php echo $academic_officer_details["username"]; ?>" id="username_update">




                                        </div>


                                        <div class="col-12">

                                            <button class="button is-info mt-5 d-grid col-12" onclick="update_profile_academic_officer();">Update Profile</button>


                                        </div>

                                    </div>








                                </div>








                            </div>








                        </div>




                        <!-- Update profile section -->





                    </div>


                </div>




            </div>








        </div>






        <!-- Toastify JS file -->


        <script src="script.js"></script> <!-- My js file -->
        <script>
            checkStatusAcademicOfficer(); //this function checks the status of the academic_officer and logs out the academic_officer if the academic_officer is blocked
        </script>
        <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script> <!-- JQuery js file -->
        <script src="jquery-3.6.0.min.js"></script> <!-- JQuery js file -->
        <script src="sweetalert.min.js"></script><!-- SweetAlert js file -->
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script><!-- Toastify JS file -->
    </body>









    </html>
<?php

} else { //if the session is not set


?>
    <script>
        window.location = "academic-officer-login";
    </script>
<?php


}

?>