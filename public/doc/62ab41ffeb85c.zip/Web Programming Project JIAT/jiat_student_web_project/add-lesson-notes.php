<?php
session_start(); //This function creates a new session if there's no session & gets the current session if there is

//Required the connection file with the database connection
require "connection.php";


if (isset($_SESSION["teacher"])) { //checkes if the session is set to show the content

    $teacher_details = $_SESSION["teacher"]; //gets the teacher details from the session

?>
    <!DOCTYPE html>
    <html>

    <head>


        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Ministry of Education</title>
        <link rel="icon" href="img/1200px-Emblem_of_Sri_Lanka.svg.png">
        <link rel="stylesheet" href="bootstrap.css" />

        <link rel="stylesheet" href="style.css" /><!-- My Css File -->
        <link rel="stylesheet" href="font/bootstrap-icons.css">

        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

        <link rel="stylesheet" href="bulma.css" />


    </head>

    <body>



        <div class="container-fluid ">

            <div class="row">

                <div class="col-12">

                    <div class="row">



                        <div class="col-md-4 pb-5" style="background-color: hsl(0, 0%, 96%)	;">

                            <!-- Profile section with logout -->

                            <div class="row ">









                                <div class="col-12 d-flex flex-column align-items-center mt-2">





                                    <div class="row ">

                                        <?php

                                        $profile_pic_result = connect::executer("SELECT CONCAT(`image`.`code`,'.',`image_type`.`type`) AS `profile_img` FROM `teacher_profile_pic` INNER JOIN `image` ON `teacher_profile_pic`.`image_id`=`image`.`id` INNER JOIN`image_type` ON  `image`.`image_type_id`=`image_type`.`id` WHERE `teacher_profile_pic`.`teacher_id`='" . addslashes($teacher_details["id"]) . "';"); //searches for the profile picture in the database

                                        if ($profile_pic_result->num_rows == 1) { //if a profile picture exsists


                                            $profile_pic_fetch = $profile_pic_result->fetch_assoc(); //covert's the profile picture result set to an associative array

                                        ?>

                                            <img src="<?php echo "profiles/" . $profile_pic_fetch["profile_img"]; //shows the profile picture 
                                                        ?>" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php

                                        } else { //if a profile picture does not exsist
                                        ?>

                                            <!-- Shows the default profile picture -->
                                            <img src="img/628298_anonym_avatar_default_head_person_icon.svg" class="rounded-circle" id="img_pro_prev" style="width: 150px;height: 130px;" />

                                        <?php



                                        }
                                        ?>

                                    </div>




                                </div>













                                <div class="col-6 offset-3 mt-2">

                                    <div class="row">

                                        <input type="file" id="profile_pic" class="d-none" />




                                    </div>


                                </div>






                            </div>



                            <div class="row">


                                <div class="col-12 text-center">


                                    <div class="row">

                                        <p class=" fw-bold" id="name_viewer"><?php echo $teacher_details["first_name"] . " " . $teacher_details["last_name"] //display the first and last name of the user taken by the session; 
                                                                                ?></p>




                                        <div>

                                            <h6 class=" fw-bold has-text-link	" style="font-size:10px;">TEACHER</h6>


                                        </div>







                                    </div>




                                </div>


                                <div class="col-12">

                                    <div class="row">

                                        <div class="col-5 offset-5 mt-1">


                                            <div class="row">

                                                <button class="btn btn-danger col-5" onclick="logOutTeacher();">Log out</button>

                                            </div>



                                        </div>





                                    </div>



                                </div>





                            </div>

                            <!-- Profile section with logout -->


                            <hr class="col-12 bg-dark" />

                            <!-- Navigation section -->

                            <div class="row px-5">


                                <div class="col-12 set-border-dash pt-2 pb-2" onclick="goToTeacher();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-person-circle"></i> Update Profile</p>












                                    </div>




                                </div>



                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToAddAssignmentMarksTeacher();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-newspaper"></i> Mark Management</p>












                                    </div>




                                </div>


                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1">


                                    <div class="row">

                                        <p class=" fw-bold  has-text-info"><i class="bi bi-book"></i></i> Add Lesson Notes</p>












                                    </div>




                                </div>







                                <div class="col-12  set-border-dash pt-2 pb-2 mt-1" onclick="goToAddAssignments();">


                                    <div class="row">

                                        <p class=" fw-bold has-text-grey-lighter"><i class="bi bi-newspaper"></i> Add Assignments</p>












                                    </div>




                                </div>












                            </div>


                            <!-- Navigation section -->




                        </div>



                        <!-- Add lesson note section -->

                        <div class="col-md-6 ">


                            <div class="row edu-background-dashboard ms-2">




                            </div>

                            <div class=" row">




                                <div class="offset-md-2 ">

                                    <div class="row">

                                        <h1 class="fs-1 fw-bold has-text-info text-center">Add Lesson Note</h1>


                                    </div>



                                    <!-- All the details are taken through the session -->

                                    <div class="row mt-5 ms-md-3">



                                        <div class="col-12 ">



                                            <input class="input is-info mt-5" type="text" placeholder="Title" id="title">







                                        </div>

                                        <div class="col-6 mt-5">



                                            <input type="file" id="file_chooser" class="d-none" onchange="showNameOnSelectorNoteUpload();" />
                                            <label class="button is-info is-light d-grid" for="file_chooser" id="file_btn">Select File</label>









                                        </div>






                                        <div class="col-6">

                                            <button class="button is-info mt-5 d-grid col-12" onclick="addLessonNote();">Add Lesson Note</button>


                                        </div>

                                    </div>








                                </div>








                            </div>








                        </div>


                        <div class="col-md-3 mt-5  ">

                            <div class="row px-3 px-md-0">

                                <input type="text" class="form-control" placeholder="Search..." id="searchLessonNote" onkeyup="searchLessonNote();" />


                            </div>



                        </div>




                        <div class="col-12 mt-3">
                            <div class="row overflow-scroll">


                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Title</th>
                                            <th scope="col">Download File</th>
                                            <th scope="col">Subject Area</th>
                                            <th scope="col">Date & Time Added</th>
                                            <th scope="col">Delete Lesson Note</th>
                                        </tr>
                                    </thead>
                                    <tbody id="lecture_note_load_area">

                                        <?php

                                        $lesson_note_rs = connect::executer("SELECT `lesson_note`.`id` AS `lesson_note_id`,`lesson_note`.`title`,`lesson_note`.`file_name`,`lesson_note`.`date_time_added`,`subject`.`name` AS `subject_name`,`grade`.`name` AS `grade_name` FROM `lesson_note` INNER JOIN `subject_has_grade` ON `lesson_note`.`subject_has_grade_id`=`subject_has_grade`.`id` INNER JOIN `subject` ON `subject_has_grade`.`subject_id`=`subject`.`id` INNER JOIN `grade` ON `subject_has_grade`.`grade_id`=`grade`.`id` WHERE `subject_has_grade`.`id`='" . $teacher_details["subject_has_grade_id"] . "'  ORDER BY `lesson_note`.`date_time_added` DESC;");


                                        while ($lesson_note_fetch = $lesson_note_rs->fetch_assoc()) {
                                        ?>
                                            <tr>


                                                <td><?php echo $lesson_note_fetch["title"]; ?></td>
                                                <td><a class="button is-danger is-light" download="" href="<?php echo "doc/" . $lesson_note_fetch["file_name"]; ?>">Download Note</a></td>
                                                <td><?php echo "Grade " . $lesson_note_fetch["grade_name"] . " " . $lesson_note_fetch["subject_name"]; ?></td>
                                                <td><?php echo $lesson_note_fetch["date_time_added"]; ?></td>
                                                <td><button class="btn btn-danger" onclick="deleteLessonNote(<?php echo $lesson_note_fetch['lesson_note_id']; ?>);">Delete</button></td>




                                            </tr>
                                        <?php
                                        }
                                        ?>

                                    </tbody>
                                </table>




                            </div>




                        </div>




                    </div>


                </div>




            </div>








        </div>






        <!-- Toastify JS file -->


        <script src="script.js"></script> <!-- My js file -->
        <script>
            checkStatusTeacher(); //this function checks the status of the teacher and logs out the teacher if the teacher is blocked
        </script>
        <script src="https://code.jquery.com/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script> <!-- JQuery js file -->
        <script src="jquery-3.6.0.min.js"></script> <!-- JQuery js file -->
        <script src="sweetalert.min.js"></script><!-- SweetAlert js file -->
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script><!-- Toastify JS file -->
    </body>









    </html>
<?php

} else { //if the session is not set


?>
    <script>
        window.location = "teacher-login";
    </script>
<?php


}

?>