<?php
session_start();
require "connection.php";


if(isset($_SESSION["teacher"])){

    $date=new DateTime();
    $timeZone= new DateTimeZone("Asia/Colombo");
    $date->setTimezone($timeZone);
    $current_date_time=$date->format("Y-m-d H:i:s");
    
    $current_year=$date->format("Y");

    $teacher_details=$_SESSION["teacher"];

    $title=addslashes($_POST["title"]);


    if($title==""||strlen(trim(preg_replace('/\xc2\xa0/',' ',$title))) == 0){

        echo "Please enter the note title.";

    }else{


    if(isset($_FILES["file_chooser"])){
   
  
       $file=$_FILES["file_chooser"];
   
       $file_name=$file["name"];
   
       $exploded_file_name=explode(".",$file_name);
   
       if($exploded_file_name[sizeof( $exploded_file_name)-1]=="pdf"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="docx"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="zip"||$exploded_file_name[sizeof( $exploded_file_name)-1]=="pptx"){


         $file_name_upload=uniqid().".".$exploded_file_name[sizeof( $exploded_file_name)-1];

         move_uploaded_file($file["tmp_name"],"doc/".$file_name_upload);


         if(connect::executer("SELECT * FROM `lesson_note` WHERE `title`='".$title."' AND `date_time_added` LIKE '".$current_year."%';")->num_rows==0){

            

            connect::executer("INSERT INTO `lesson_note`(`title`,`file_name`,`date_time_added`,`subject_has_grade_id`) VALUES ('".$title."','".addslashes($file_name_upload)."','".$current_date_time."','".$teacher_details["subject_has_grade_id"]."');");

            echo "success";


         }else{

            echo "A lesson note with this title already exsists.";


         }
         

         
          



       }else{


           echo "The file must be a pdf file, zip file, docx file, or a pptx file.";
         


       }

    }else{

      echo "Please select a file.";
    

    }
  }
}

?>